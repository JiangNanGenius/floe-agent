#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Fetch the exact TIC-80 v1.4.1 Web-build source depot.

This is a preparation-time network step.  It is the only script in the kit that
uses the network; a prepared depot is self-contained and every later stage
(assemble/check/rebuild/relink) works without fetching anything.

Inputs:
  SOURCE-PINS.json          exact upstream tag/commit, submodule URLs+commits
  the retained upstream main source archive (exact bytes, hash checked)

Outputs (under --depot):
  upstream/TIC-80-b3dbd59-source.tar.gz (+ .sha256)
  submodules/<path>__<short>.tar.gz
  ARCHIVES.json             URL, commit, bytes, SHA-256 for every archive
  SHA256SUMS                plain checksum list

Exit status is non-zero on any missing archive, bad hash, or unsafe archive.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import shutil
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DEFAULT_PINS = ROOT / "SOURCE-PINS.json"
DEFAULT_DEPOT = Path(
    "/Volumes/TECLAST-512/IOS AI AGENT/Local/Artifacts/"
    "game-predevelopment-expanded/tic80-mpl-closure/source-depot"
)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_download(url: str, dest: Path, attempts: int = 3) -> int:
    dest.parent.mkdir(parents=True, exist_ok=True)
    last_error: Exception | None = None
    for attempt in range(1, attempts + 1):
        tmp = dest.with_suffix(dest.suffix + f".part-{os.getpid()}")
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "floe-tic80-source-fetch/1",
                    "Accept": "application/x-gzip",
                },
            )
            with urllib.request.urlopen(req, timeout=90) as response:
                status = getattr(response, "status", 200)
                if status != 200:
                    raise RuntimeError(f"HTTP {status} for {url}")
                with tmp.open("wb") as out:
                    shutil.copyfileobj(response, out, 1024 * 1024)
            if tmp.stat().st_size == 0:
                raise RuntimeError(f"empty response for {url}")
            with tarfile.open(tmp, "r:gz") as tf:
                members = tf.getmembers()
                if not members:
                    raise RuntimeError(f"empty tar for {url}")
                for member in members:
                    name = member.name
                    if name.startswith("/") or ".." in name.split("/"):
                        raise RuntimeError(f"unsafe tar member {name!r} in {url}")
                    if member.issym() or member.islnk():
                        base = Path(name).parent
                        target = Path(os.path.normpath(str(base / member.linkname)))
                        if target.is_absolute() or str(target).startswith(".."):
                            raise RuntimeError(
                                f"tar link escapes archive root: {name} -> {member.linkname}"
                            )
                    if member.isdev():
                        raise RuntimeError(f"device node in {url}: {name}")
            os.replace(tmp, dest)
            return dest.stat().st_size
        except Exception as exc:  # noqa: BLE001 - clear failure is the point
            last_error = exc
            try:
                tmp.unlink()
            except FileNotFoundError:
                pass
            if attempt < attempts:
                time.sleep(2 * attempt)
    raise RuntimeError(f"download failed after {attempts} attempts: {url}: {last_error}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pins", type=Path, default=DEFAULT_PINS)
    parser.add_argument("--depot", type=Path, default=DEFAULT_DEPOT)
    parser.add_argument(
        "--main-source",
        type=Path,
        default=None,
        help="retained exact TIC-80 archive; defaults to the path in SOURCE-PINS.json",
    )
    parser.add_argument("--jobs", type=int, default=6)
    parser.add_argument(
        "--verify-only",
        action="store_true",
        help="verify the existing depot against ARCHIVES.json; never touch the network",
    )
    parser.add_argument(
        "--allow-partial",
        action="store_true",
        help="download what is missing but do not fail when a submodule is unreachable (records it)",
    )
    args = parser.parse_args()

    pins = json.loads(args.pins.read_text())
    depot = args.depot
    depot.mkdir(parents=True, exist_ok=True)
    upstream_dir = depot / "upstream"
    sub_dir = depot / "submodules"
    upstream_dir.mkdir(exist_ok=True)
    sub_dir.mkdir(exist_ok=True)

    records: dict[str, dict] = {}
    archives_path = depot / "ARCHIVES.json"
    if archives_path.exists():
        records = json.loads(archives_path.read_text()).get("archives", {})

    main_source = Path(args.main_source) if args.main_source else Path(
        "/Volumes/TECLAST-512/IOS AI AGENT/"
        + pins["upstream"]["sourceReceipt"]
    )
    main_dest = upstream_dir / pins["upstream"]["archive"]
    expected_main = pins["upstream"]["sha256"]
    main_key = "upstream"

    if args.verify_only:
        failures: list[str] = []
        if not main_dest.exists():
            failures.append(f"missing {main_dest}")
        elif sha256_file(main_dest) != expected_main:
            failures.append(f"hash mismatch {main_dest}")
        for sub in pins["submodules"]:
            name = sub["path"].replace("/", "__") + "-" + sub["commit"][:7] + ".tar.gz"
            dest = sub_dir / name
            record = records.get(sub["path"])
            if not dest.exists():
                failures.append(f"missing {dest}")
                continue
            if record and sha256_file(dest) != record["sha256"]:
                failures.append(f"hash mismatch {dest}")
        if failures:
            print("FAIL: depot verification")
            for failure in failures:
                print(" -", failure)
            return 1
        print(f"OK: {len(pins['submodules'])} submodule archives + upstream verified")
        return 0

    if main_dest.exists():
        if sha256_file(main_dest) != expected_main:
            raise SystemExit(f"existing main archive hash mismatch: {main_dest}")
    else:
        if not main_source.exists():
            raise SystemExit(f"missing retained main source archive: {main_source}")
        if sha256_file(main_source) != expected_main:
            raise SystemExit(f"retained main source archive hash mismatch: {main_source}")
        shutil.copy2(main_source, main_dest)
    (upstream_dir / (pins["upstream"]["archive"] + ".sha256")).write_text(
        f"{expected_main}  {pins['upstream']['archive']}\n"
    )
    records[main_key] = {
        "kind": "upstream-main",
        "name": pins["upstream"]["name"],
        "tag": pins["upstream"]["tag"],
        "commit": pins["upstream"]["commit"],
        "url": "https://github.com/nesbox/TIC-80/archive/"
        + pins["upstream"]["commit"]
        + ".tar.gz",
        "archive": pins["upstream"]["archive"],
        "relativePath": f"upstream/{pins['upstream']['archive']}",
        "bytes": main_dest.stat().st_size,
        "sha256": expected_main,
    }

    def job(sub: dict) -> tuple[str, dict, str | None]:
        path = sub["path"]
        commit = sub["commit"]
        repo = sub["url"].removesuffix(".git").split("github.com/")[-1]
        url = f"https://codeload.github.com/{repo}/tar.gz/{commit}"
        name = path.replace("/", "__") + "-" + commit[:7] + ".tar.gz"
        dest = sub_dir / name
        record = {
            "kind": "submodule",
            "path": path,
            "url": sub["url"],
            "commit": commit,
            "archive": name,
            "relativePath": f"submodules/{name}",
            "downloadURL": url,
        }
        try:
            if dest.exists():
                digest = sha256_file(dest)
                if records.get(path, {}).get("sha256") not in (None, digest):
                    raise RuntimeError(
                        f"on-disk archive {dest} does not match recorded SHA-256"
                    )
            else:
                atomic_download(url, dest)
                digest = sha256_file(dest)
            record["bytes"] = dest.stat().st_size
            record["sha256"] = digest
            return path, record, None
        except Exception as exc:  # noqa: BLE001
            return path, record, str(exc)

    failures: list[str] = []
    if records:
        # Keep already recorded archives stable across runs; only fetch what is
        # actually absent so a local hash is never silently re-pinned.
        pass
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        for path, record, error in pool.map(job, pins["submodules"]):
            if error:
                failures.append(f"{path}: {error}")
                print(f"FAIL {path}: {error}", file=sys.stderr)
            else:
                records[path] = record
                print(f"OK   {path} {record['sha256']}")

    if failures and not args.allow_partial:
        print("FAIL: depot incomplete", file=sys.stderr)
        return 1

    payload = {
        "format": "floe-tic80-source-archives",
        "version": 1,
        "pins": str(args.pins),
        "upstream": pins["upstream"],
        "toolchain": pins.get("toolchain", {}),
        "archives": records,
        "complete": not failures,
        "missing": failures,
    }
    archives_path.write_text(json.dumps(payload, indent=2) + "\n")
    lines = []
    for key in sorted(records):
        record = records[key]
        if "sha256" in record:
            lines.append(f"{record['sha256']}  {record['relativePath']}")
    (depot / "SHA256SUMS").write_text("\n".join(lines) + "\n")
    print(f"wrote {archives_path} ({len(records)} archives)")
    return 0 if not failures else (0 if args.allow_partial else 1)


if __name__ == "__main__":
    raise SystemExit(main())
