#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Create an isolated TIC-80 build tree for one controlled variant.

The assembled source tree is never modified.  Each variant gets a fresh copy
under the internal CodexBuild scratch (never inside a Git work tree), and
every patch is dry-run first and
applied with --fuzz=0 so a drifted source fails instead of silently changing
the meaning of the patch.

Variants:
  baseline      0001 release identity only (no runtime-code change)
  relink        0001 + 0002 visible version marker + 0003 blip_buf marker
  audio-relink  0001 + 0003 + optional audio gain patch (reserved; not used by
                the default comparison)
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RESOURCE_ROOT = Path(os.environ.get("TIC80_RESOURCE_ROOT", str(
    ROOT / "Resources" if (ROOT / "Resources").is_dir() else
    ROOT.parents[3] / "Local/Artifacts/game-predevelopment-expanded/tic80-mpl-closure")))
SOURCE_TREE = Path(os.environ.get("TIC80_SOURCE_TREE", str(RESOURCE_ROOT / "source-tree/tic80-1.4.1")))
WORK_ROOT = Path(os.environ.get("TIC80_SCRATCH_ROOT", str(Path.home() /
    "Library/Caches/CodexBuild/Floe/0dd039b5b74b/xcode27.2/game-tic80-mpl"))) / "work"
PATCHES = {
    "0001": ROOT / "patches/0001-release-identity-1.4.1.patch",
    "0002": ROOT / "patches/0002-relink-version-marker.patch",
    "0003": ROOT / "patches/0003-blip-buf-relink-marker.patch",
    "0004": ROOT / "patches/0004-omit-uncleared-embedded-demos.patch",
    "0005": ROOT / "patches/0005-gravity-source-archive-build.patch",
}
VARIANTS = {
    "baseline": ["0001", "0004", "0005"],
    "relink": ["0001", "0002", "0003", "0004", "0005"],
    "audio-relink": ["0001", "0002", "0003", "0004", "0005"],
}
PATCHED_FILES = {
    "0005": ["cmake/gravity.cmake"],
    "0001": ["cmake/version.cmake"],
    "0002": ["cmake/version.cmake"],
    "0003": ["vendor/blip-buf/blip_buf.c"],
    "0004": ['src/api/gravity.c', 'src/api/janet.c', 'src/api/js.c', 'src/api/lua.c', 'src/api/miniscript.cpp', 'src/api/moonscript.c', 'src/api/mruby.c', 'src/api/python.c', 'src/api/scheme.c', 'src/api/squirrel.c', 'src/api/wasm.c', 'src/api/wren.c', 'src/api/yue.cpp', 'src/studio/screens/console.c'],
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def run(cmd: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, check=False)


def tree_digest(root: Path) -> str:
    entries: list[tuple[str, bytes]] = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames.sort()
        for name in list(dirnames):
            path = Path(dirpath) / name
            if path.is_symlink():
                rel = path.relative_to(root).as_posix()
                entries.append((rel, b"l\0" + os.readlink(path).encode()))
                dirnames.remove(name)
        for name in filenames:
            path = Path(dirpath) / name
            rel = path.relative_to(root).as_posix()
            if path.is_symlink():
                entries.append((rel, b"l\0" + os.readlink(path).encode()))
            else:
                entries.append((rel, b"f\0" + sha256_file(path).encode()))
    h = hashlib.sha256()
    for rel, payload in sorted(entries):
        h.update(rel.encode())
        h.update(b"\0")
        h.update(payload)
        h.update(b"\n")
    return h.hexdigest()


def verify_source_tree() -> None:
    manifest = SOURCE_TREE.parent / "SOURCE-MANIFEST.json"
    if not manifest.exists():
        raise SystemExit(f"missing source manifest: {manifest}")
    expected = json.loads(manifest.read_text())
    actual = tree_digest(SOURCE_TREE)
    if actual != expected["treeSHA256"]:
        raise SystemExit(
            f"assembled source tree does not match its manifest: {actual} != "
            f"{expected['treeSHA256']}"
        )
    for required in [
        "vendor/blip-buf/blip_buf.c",
        "cmake/version.cmake",
        "CMakeLists.txt",
    ]:
        if not (SOURCE_TREE / required).is_file():
            raise SystemExit(f"missing required source: {required}")
    print(f"source tree verified: {actual}")


def prepare(variant: str, force: bool) -> Path:
    if variant not in VARIANTS:
        raise SystemExit(f"unknown variant: {variant}")
    verify_source_tree()
    dest = WORK_ROOT / variant / "tic80-src"
    if dest.exists():
        if not force:
            raise SystemExit(f"build tree already exists (use --force): {dest}")
        shutil.rmtree(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(SOURCE_TREE, dest, symlinks=True)
    git_check = run(["git", "-C", str(dest), "rev-parse", "--show-toplevel"])
    if git_check.returncode == 0:
        raise SystemExit(
            "build tree is inside a Git work tree ("
            + git_check.stdout.strip()
            + "); use the internal CodexBuild scratch outside Git so TIC-80's "
            "version.cmake does not pick up Floe's git metadata"
        )

    applied: list[dict] = []
    for key in VARIANTS[variant]:
        patch = PATCHES[key]
        if not patch.is_file():
            raise SystemExit(f"missing patch: {patch}")
        dry = run(["patch", "-p1", "--dry-run", "--forward", "--fuzz=0", "-i", str(patch)], cwd=dest)
        if dry.returncode != 0:
            raise SystemExit(f"patch dry-run failed ({key}):\n{dry.stdout}\n{dry.stderr}")
        result = run(
            ["patch", "-p1", "--forward", "--fuzz=0", "--no-backup-if-mismatch", "-i", str(patch)],
            cwd=dest,
        )
        if result.returncode != 0:
            raise SystemExit(f"patch failed ({key}):\n{result.stdout}\n{result.stderr}")
        applied.append({"key": key, "path": str(patch), "sha256": sha256_file(patch)})
        print(f"applied {key}: {patch.name}")

    receipt = {
        "format": "floe-tic80-build-tree",
        "version": 1,
        "variant": variant,
        "sourceTree": str(SOURCE_TREE),
        "buildTree": str(dest),
        "patches": applied,
        "patchedFiles": {
            rel: sha256_file(dest / rel)
            for key in VARIANTS[variant]
            for rel in PATCHED_FILES[key]
        },
        "treeSHA256": tree_digest(dest),
    }
    receipt_path = dest.parent / "BUILD-TREE.json"
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
    print(f"build tree: {dest}")
    print(f"receipt: {receipt_path}")
    print(f"tree SHA-256: {receipt['treeSHA256']}")
    return dest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variant", choices=sorted(VARIANTS), required=True)
    parser.add_argument("--force", action="store_true")
    parser.add_argument(
        "--work-root",
        type=Path,
        default=None,
        help="build-tree root; defaults to the artifact build/work directory",
    )
    args = parser.parse_args()
    global WORK_ROOT
    if args.work_root is not None:
        WORK_ROOT = args.work_root
    prepare(args.variant, args.force)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
