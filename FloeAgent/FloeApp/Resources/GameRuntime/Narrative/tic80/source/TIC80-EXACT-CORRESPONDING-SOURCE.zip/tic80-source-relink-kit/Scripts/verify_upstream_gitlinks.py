#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Verify the pinned submodule commits against the upstream Git trees.

Preparation-time network check only.  It reads the public GitHub tree API for
the exact TIC-80 commit and the nested pocketpy commit, compares every gitlink
(mode 160000) with SOURCE-PINS.json, and writes evidence.  It does not fetch
source archives and does not touch the build.

This is the check that a hand-maintained pin list cannot replace: the archive
contains empty gitlink directories, so the commit ids must be read from the
upstream tree.
"""

from __future__ import annotations

import argparse
import json
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DEFAULT_OUT = ROOT / "evidence/SUBMODULE-PIN-VERIFICATION.json"
TIC80 = "b3dbd597eecfe6742f64001c2fe5ba6c1afe55d9"
POCKETPY = "979addecf9cb180c59c16ac605ba75441ece5af6"


def get_json(url: str) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": "floe-tic80-pin-check/1"})
    with urllib.request.urlopen(req, timeout=60) as response:
        return json.load(response)


def gitlinks(tree: dict) -> dict[str, str]:
    return {entry["path"]: entry["sha"] for entry in tree.get("tree", []) if entry.get("mode") == "160000"}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    pins = json.loads((ROOT / "SOURCE-PINS.json").read_text())

    top = gitlinks(get_json(f"https://api.github.com/repos/nesbox/TIC-80/git/trees/{TIC80}?recursive=1"))
    checks = []
    for sub in pins["submodules"]:
        if sub["path"].count("/") > 1:
            continue
        actual = top.get(sub["path"])
        checks.append(
            {
                "path": sub["path"],
                "pinned": sub["commit"],
                "upstream": actual,
                "ok": actual == sub["commit"],
            }
        )

    nested = gitlinks(get_json(f"https://api.github.com/repos/pocketpy/pocketpy/git/trees/{POCKETPY}?recursive=1"))
    for sub in pins["submodules"]:
        if sub["path"].count("/") <= 1:
            continue
        relative = sub["path"].split("vendor/pocketpy/", 1)[1]
        actual = nested.get(relative)
        checks.append(
            {
                "path": sub["path"],
                "pinned": sub["commit"],
                "upstream": actual,
                "ok": actual == sub["commit"],
            }
        )

    quickjs = gitlinks(
        get_json(
            "https://api.github.com/repos/quickjs-ng/quickjs/git/trees/"
            "6d46d07d04041b40f4f49eaa7fdebe44c314c699"
        )
    )
    test262 = quickjs.get("test262")
    excluded_ok = any(
        item.get("path") == "vendor/quickjs/test262" and item.get("commit") == test262
        for item in pins.get("excluded", [])
    )

    failed = [c for c in checks if not c["ok"]]
    payload = {
        "format": "floe-tic80-submodule-pin-verification",
        "version": 1,
        "kind": "public GitHub tree API check; no source archive downloaded",
        "tic80Commit": TIC80,
        "api": f"https://api.github.com/repos/nesbox/TIC-80/git/trees/{TIC80}?recursive=1",
        "topLevelGitlinks": len([c for c in checks if c["path"].count("/") == 1]),
        "nestedPocketpyGitlinks": len([c for c in checks if c["path"].count("/") > 1]),
        "checks": checks,
        "mismatches": failed,
        "quickjsTest262": {"commit": test262, "excludedWithReason": excluded_ok},
        "ok": not failed and excluded_ok,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2) + "\n")
    print(f"{len(checks) - len(failed)}/{len(checks)} pinned gitlinks match; "
          f"test262 exclusion={excluded_ok}; ok={payload['ok']}")
    return 0 if payload["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
