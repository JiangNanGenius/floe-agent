#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Write the human source inventory and the machine SourceReady receipt."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
ART = Path(
    "/Volumes/TECLAST-512/IOS AI AGENT/Local/Artifacts/"
    "game-predevelopment-expanded/tic80-mpl-closure"
)
TREE = ART / "source-tree/tic80-1.4.1"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    pins = json.loads((ROOT / "SOURCE-PINS.json").read_text())
    archives = json.loads((ART / "source-depot/ARCHIVES.json").read_text())
    manifest = json.loads((TREE.parent / "SOURCE-MANIFEST.json").read_text())
    link = json.loads((ROOT / "manifests/WEB-BUILD-LINK-MAP.json").read_text())
    assets = json.loads((ROOT / "manifests/EMBEDDED-ASSET-REVIEW.json").read_text())
    kit_check_path = ROOT / "evidence/KIT-CHECK.json"
    kit_check = json.loads(kit_check_path.read_text()) if kit_check_path.exists() else None

    sub_rows = []
    for sub in pins["submodules"]:
        record = archives["archives"].get(sub["path"], {})
        sub_rows.append(
            {
                "path": sub["path"],
                "url": sub["url"],
                "commit": sub["commit"],
                "archive": record.get("archive"),
                "bytes": record.get("bytes"),
                "sha256": record.get("sha256"),
                "nested": sub["path"].count("/") > 1,
                "note": sub.get("note"),
            }
        )

    lines = [
        "# TIC-80 v1.4.1 Web source inventory",
        "",
        "This inventory is generated from the exact pinned archives and the assembled tree.",
        "It is a source/provenance record, not a legal opinion.",
        "",
        "## Upstream",
        "",
        f"- Tag: `{pins['upstream']['tag']}`",
        f"- Commit: `{pins['upstream']['commit']}`",
        f"- Archive: `{pins['upstream']['archive']}`",
        f"- SHA-256: `{pins['upstream']['sha256']}`",
        "- Retained copy: `Local/Artifacts/game-predevelopment-expanded/narrative/resources-mpl-1/tic80/source/TIC-80-b3dbd59-source.tar.gz`",
        "",
        "## Assembled tree",
        "",
        f"- Path: `{TREE}`",
        f"- Files: {manifest['fileCount']}",
        f"- Bytes: {manifest['totalBytes']}",
        f"- Tree SHA-256: `{manifest['treeSHA256']}`",
        f"- File manifest SHA-256: `{sha256_file(TREE.parent / 'SOURCE-MANIFEST.json')}`",
        "",
        "## Submodule archives (31)",
        "",
        "| Path | Commit | Archive | Bytes | SHA-256 |",
        "| --- | --- | --- | ---: | --- |",
    ]
    for row in sub_rows:
        lines.append(
            f"| `{row['path']}` | `{row['commit'][:12]}` | `{row['archive']}` | "
            f"{row['bytes']} | `{row['sha256']}` |"
        )
    lines += [
        "",
        "Nested pocketpy submodules are included although the Web build leaves their features OFF.",
        "QuickJS `test262` is excluded: it is a test corpus with `update = none`, not linked and not needed",
        "to reconstruct the runtime. The dmath `musl` submodule is also excluded: PocketPy determinism is OFF,",
        "so dmath and its musl submodule are not compiled. The exact exclusions are in `SOURCE-PINS.json`.",
        "",
        "## Web build selection",
        "",
        "Linked: " + ", ".join(f"`{x}`" for x in link["linkedIds"]),
        "",
        "Present but not linked: " + ", ".join(f"`{x}`" for x in link["notLinkedIds"]),
        "",
        "The GPL text in `src/system/baremetalpi/` belongs to the baremetal Pi platform and is not",
        "compiled into the Sokol/Emscripten Web runtime. pForth is OFF. SDL2 is not selected.",
        "",
        "## Embedded data review",
        "",
        f"- `build/assets` entries reviewed: {len(assets['assets'])}",
        f"- Embedded in the universal Web build: {assets['embeddedCount']}",
        "- Community/mark demos with no explicit license statement: "
        + ", ".join(
            f"`{a['asset']}`" for a in assets["assets"] if a.get("licenseStatus") == "no-explicit-license"
        ),
        "",
        "These are upstream data, not Floe content and not relicensed. A no-community/mark-demo",
        "build remains a Root decision; this kit does not silently alter them.",
        "",
        "## Relink materials",
        "",
        "- `patches/0001-release-identity-1.4.1.patch` — source-archive build identity",
        "- `patches/0002-relink-version-marker.patch` — visible `-floe-relink1` version",
        "- `patches/0003-blip-buf-relink-marker.patch` — inert marker in blip_buf",
        "- `fixtures/floe-relink-check.tic` — original MIT cartridge",
        "- `Scripts/build_tic80_web.sh` — baseline/relink build",
        "- `Scripts/relink_compare.sh` — controlled comparison and receipt",
        "",
        "## Source-only check status",
        "",
    ]
    if kit_check:
        lines.append(
            f"- `{kit_check['passed']}/{kit_check['checks']}` checks passed, "
            f"{kit_check['failed']} failed. Kind: {kit_check['kind']}."
        )
    else:
        lines.append("- `KIT-CHECK.json` not present.")
    lines += [
        "- Native build, browser load and iPad acceptance are **not** part of this status.",
        "",
    ]
    (ROOT / "SOURCE-INVENTORY.md").write_text("\n".join(lines))

    shipped_js = Path(
        "/Volumes/TECLAST-512/IOS AI AGENT/Local/Artifacts/game-predevelopment-expanded/"
        "narrative/resources-mpl-1/tic80/tic80.js"
    )
    shipped_wasm = Path(
        "/Volumes/TECLAST-512/IOS AI AGENT/Local/Artifacts/game-predevelopment-expanded/"
        "narrative/resources-mpl-1/tic80/tic80js.wasm"
    )
    ready = {
        "format": "floe-tic80-source-ready",
        "version": 1,
        "kind": "source/license/build-kit checkpoint; not native or relink proof",
        "nativeHold": "NATIVE-HOLD.json was active at this checkpoint; no emcc/clang/browser/Simulator/VM run was performed.",
        "upstream": pins["upstream"],
        "toolchain": json.loads((ROOT / "TOOLCHAIN.json").read_text()),
        "archives": {
            "count": len(archives["archives"]),
            "totalBytes": sum(r["bytes"] for r in archives["archives"].values()),
            "records": archives["archives"],
            "depot": str(ART / "source-depot"),
        },
        "assembledTree": {
            "path": str(TREE),
            "fileCount": manifest["fileCount"],
            "totalBytes": manifest["totalBytes"],
            "treeSHA256": manifest["treeSHA256"],
            "manifest": str(TREE.parent / "SOURCE-MANIFEST.json"),
        },
        "submodules": sub_rows,
        "exclusions": pins.get("excluded", []),
        "buildSelection": {
            "linked": link["linkedIds"],
            "notLinked": link["notLinkedIds"],
            "gplLinked": link["licenseSummary"]["gplLinked"],
            "lgplLinked": link["licenseSummary"]["lgplLinked"],
        },
        "embeddedAssets": {
            "review": str(ROOT / "manifests/EMBEDDED-ASSET-REVIEW.json"),
            "count": len(assets["assets"]),
            "communityNoExplicitLicense": [
                a["asset"] for a in assets["assets"] if a.get("licenseStatus") == "no-explicit-license"
            ],
        },
        "relink": {
            "status": "prepared-not-executed",
            "patches": [
                {"path": "patches/0001-release-identity-1.4.1.patch", "sha256": sha256_file(ROOT / "patches/0001-release-identity-1.4.1.patch")},
                {"path": "patches/0002-relink-version-marker.patch", "sha256": sha256_file(ROOT / "patches/0002-relink-version-marker.patch")},
                {"path": "patches/0003-blip-buf-relink-marker.patch", "sha256": sha256_file(ROOT / "patches/0003-blip-buf-relink-marker.patch")},
            ],
            "fixture": {
                "path": "fixtures/floe-relink-check.tic",
                "sha256": sha256_file(ROOT / "fixtures/floe-relink-check.tic"),
                "bytes": (ROOT / "fixtures/floe-relink-check.tic").stat().st_size,
            },
            "shippedBaseline": {
                "js": {"path": str(shipped_js), "sha256": sha256_file(shipped_js), "bytes": shipped_js.stat().st_size},
                "wasm": {"path": str(shipped_wasm), "sha256": sha256_file(shipped_wasm), "bytes": shipped_wasm.stat().st_size},
            },
            "comparisonScript": "Scripts/relink_compare.sh",
            "buildScript": "Scripts/build_tic80_web.sh",
            "expectedOutputs": [
                "build/out/baseline/upstream/index.html",
                "build/out/baseline/floe-resource/index.html",
                "build/out/relink/upstream/index.html",
                "build/out/relink/floe-resource/index.html",
                "evidence/RELINK-RECEIPT.json",
            ],
            "missing": "The native build and the controlled relink output hashes are not produced under NATIVE-HOLD.",
        },
        "checks": {
            "kitCheck": str(kit_check_path),
            "passed": kit_check["passed"] if kit_check else None,
            "failed": kit_check["failed"] if kit_check else None,
        },
        "doNotRepeat": [
            "Do not re-download or re-pin the source archives; the depot is complete and hash-verified.",
            "Do not treat the source-only checks as native, WebKit, audio or iPad acceptance.",
            "Do not replace the App's default TIC-80 resources before Root accepts a new runtime profile.",
            "Do not run the native stage outside native_check.py or while NATIVE-HOLD.json is present.",
        ],
    }
    (ROOT / "SOURCE-READY.json").write_text(json.dumps(ready, indent=2) + "\n")
    print(f"wrote SOURCE-INVENTORY.md and SOURCE-READY.json ({len(sub_rows)} submodules)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
