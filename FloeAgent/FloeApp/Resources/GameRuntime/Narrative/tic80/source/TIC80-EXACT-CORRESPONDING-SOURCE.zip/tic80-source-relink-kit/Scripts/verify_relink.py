#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Verify the controlled baseline/modified LGPL relink comparison.

This is an artifact check, not a runtime execution.  It fails closed if the
modified library was not actually linked (marker missing), if the baseline
already contains the marker, if the two engine hashes are equal, if the version
banner is wrong, or if the Floe loader does not name the packaged wasm file.

Usage:
  verify_relink.py --baseline build/out/baseline --relink build/out/relink \
      [--shipped-js ... --shipped-wasm ...] [--out evidence/RELINK-RECEIPT.json]
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

MARKER = b"FLOE-BLIP-RELINK-MARKER-v1"
BASELINE_BANNER = b"1.4.1 (b3dbd59)"
RELINK_BANNER = b"1.4.1-floe-relink1 (b3dbd59)"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_package(root: Path) -> dict:
    manifest_path = root / "RUNTIME-MANIFEST.json"
    if not manifest_path.is_file():
        raise SystemExit(f"missing package manifest: {manifest_path}")
    manifest = json.loads(manifest_path.read_text())
    profile_path = root / "runtime-profile.json"
    if not profile_path.is_file():
        raise SystemExit(f"missing runtime profile: {profile_path}")
    profile = json.loads(profile_path.read_text())
    js = root / "floe-resource/tic80.js"
    wasm = root / "floe-resource/tic80js.wasm"
    for path in (js, wasm):
        if not path.is_file():
            raise SystemExit(f"missing package file: {path}")
    return {"root": root, "manifest": manifest, "profile": profile, "js": js, "wasm": wasm}


def check(name: str, ok: bool, detail: str, checks: list[dict]) -> None:
    checks.append({"name": name, "ok": bool(ok), "detail": detail})


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--relink", type=Path, required=True)
    parser.add_argument("--shipped-js", type=Path, default=None)
    parser.add_argument("--shipped-wasm", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    base = load_package(args.baseline)
    rel = load_package(args.relink)
    checks: list[dict] = []

    for label, package in [("baseline", base), ("relink", rel)]:
        manifest_ok = all(
            (package["root"] / entry["path"]).is_file()
            and sha256_file(package["root"] / entry["path"]) == entry["sha256"]
            for entry in package["manifest"]["files"]
        )
        check(f"{label} manifest hashes", manifest_ok, f"{package['root']}", checks)

    base_wasm = base["wasm"].read_bytes()
    rel_wasm = rel["wasm"].read_bytes()
    base_js = base["js"].read_bytes()
    rel_js = rel["js"].read_bytes()

    check("baseline is real wasm", base_wasm[:4] == b"\x00asm", base["wasm"].as_posix(), checks)
    check("relink is real wasm", rel_wasm[:4] == b"\x00asm", rel["wasm"].as_posix(), checks)
    check("baseline marker absent", MARKER not in base_wasm, "no FLOE-BLIP-RELINK-MARKER-v1", checks)
    check("relink marker present", MARKER in rel_wasm, "FLOE-BLIP-RELINK-MARKER-v1 found", checks)
    check("engine bytes differ", base_wasm != rel_wasm,
          f"{sha256_file(base['wasm'])} != {sha256_file(rel['wasm'])}", checks)
    check("loader bytes differ", base_js != rel_js,
          f"{sha256_file(base['js'])} != {sha256_file(rel['js'])}", checks)
    check("baseline banner", BASELINE_BANNER in base_wasm, BASELINE_BANNER.decode(), checks)
    check("relink banner", RELINK_BANNER in rel_wasm, RELINK_BANNER.decode(), checks)
    for label, js, wasm in [("baseline", base_js, base_wasm), ("relink", rel_js, rel_wasm)]:
        check(f"{label} editors marker", b"SPRITE EDITOR" in wasm, "SPRITE EDITOR", checks)
        check(f"{label} sokol layer", b"Unable to initialize SDL Video" not in wasm,
              "no SDL Video marker", checks)
        check(f"{label} loader names tic80js.wasm", js.count(b'locateFile("tic80js.wasm")') == 1,
              "exactly one locateFile(\"tic80js.wasm\")", checks)

    fixtures = []
    for package in (base, rel):
        fixture = package["root"] / "floe-resource/cart.tic"
        fixtures.append(fixture if fixture.is_file() else None)
    check("fixture present in both packages", all(f is not None for f in fixtures),
          ", ".join(str(f) for f in fixtures), checks)
    if all(f is not None for f in fixtures):
        check("fixture bytes identical", sha256_file(fixtures[0]) == sha256_file(fixtures[1]),
              sha256_file(fixtures[0]), checks)

    shipped = None
    if args.shipped_js and args.shipped_wasm:
        shipped = {
            "js": str(args.shipped_js),
            "wasm": str(args.shipped_wasm),
            "jsSHA256": sha256_file(args.shipped_js),
            "wasmSHA256": sha256_file(args.shipped_wasm),
        }
        baseline_js_hash = sha256_file(base["js"])
        baseline_wasm_hash = sha256_file(base["wasm"])
        # Informational only: a rebuild is not claimed byte-identical to the
        # shipped pair because the original compiler version is unknown.
        shipped["baselineLoaderMatches"] = shipped["jsSHA256"] == baseline_js_hash
        shipped["baselineWasmMatches"] = shipped["wasmSHA256"] == baseline_wasm_hash
        check(
            "shipped baseline loader comparison (informational)",
            True,
            f"match={shipped['baselineLoaderMatches']} shipped={shipped['jsSHA256']} rebuilt={baseline_js_hash}",
            checks,
        )
        check(
            "shipped baseline wasm comparison (informational)",
            True,
            f"match={shipped['baselineWasmMatches']} shipped={shipped['wasmSHA256']} rebuilt={baseline_wasm_hash}",
            checks,
        )

    failures = [c for c in checks if not c["ok"]]
    receipt = {
        "format": "floe-tic80-relink-receipt",
        "version": 1,
        "kind": "artifact-check; not runtime/UI proof",
        "passed": len(checks) - len(failures),
        "failed": len(failures),
        "ok": not failures,
        "checks": checks,
        "hashes": {
            "baselineJS": sha256_file(base["js"]),
            "baselineWASM": sha256_file(base["wasm"]),
            "relinkJS": sha256_file(rel["js"]),
            "relinkWASM": sha256_file(rel["wasm"]),
            "fixture": sha256_file(fixtures[0]) if fixtures[0] else None,
        },
        "shippedBaseline": shipped,
        "caveat": "A passing receipt proves the rebuilt bytes contain the modified blip_buf and differ from the baseline. Root must still load both packages in the canonical WebKit host/iPad to accept behavior; this script does not execute a browser, emscripten runtime or audio path.",
    }
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))
    return 0 if receipt["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
