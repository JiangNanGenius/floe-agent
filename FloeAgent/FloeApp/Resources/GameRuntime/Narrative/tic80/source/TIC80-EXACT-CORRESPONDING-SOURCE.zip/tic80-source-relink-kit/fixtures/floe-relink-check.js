// script: js
// title: Floe TIC-80 relink check
// author: Floe contributors
// desc: original MIT fixture for rebuilt-runtime comparison
// license: MIT
var t = 0;
function TIC() {
  t++;
  cls(0);
  rectb(0, 0, 240, 136, 12);
  rectb(2, 2, 236, 132, 5);
  print("FLOE RELINK CHECK", 38, 56, 12, false, 1, false);
  print("RUNTIME OK", 82, 72, 6, false, 1, false);
  print(t % 60 < 30 ? ">" : "<", 116, 90, 14, false, 1, false);
}
