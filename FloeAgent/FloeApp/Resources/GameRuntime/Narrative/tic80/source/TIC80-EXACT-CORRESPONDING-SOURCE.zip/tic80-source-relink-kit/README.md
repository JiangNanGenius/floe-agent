# TIC-80 exact-source rebuild and relink kit

Original source files retain their licenses; Floe helper scripts are MPL-2.0.
The 32 archives contain TIC-80 v1.4.1 and all 31 exact nested submodule sources.
No downloaded game, RTP or commercial engine license is supplied.

1. Run `python3 Scripts/assemble_source.py --assemble` in this directory. This
   verifies all archive hashes and assembles the complete source tree offline.
2. Install/activate the exact public tools in `TOOLCHAIN.json`, including emsdk
   6.0.13. The toolchain recipe is explicit; the original binary compiler
   identity and byte-identical reproduction are not claimed.
3. Run `bash Scripts/relink_compare.sh --jobs 6`. Both baseline and the actual
   modified blip_buf variant build from those sources. Outputs go under
   `Resources/build/out/`; the receipt goes under `evidence/`.
4. Inspect `evidence/RELINK-RECEIPT.json`, then load both floe-resource folders
   with the included original MIT cartridge in a WebKit host. Root acceptance
   is separate from source packing or a compiler return code.

`TIC80_RESOURCE_ROOT`, `TIC80_SOURCE_TREE`, `TIC80_ARTIFACT_ROOT` and
`TIC80_SCRATCH_ROOT` may select explicit local paths. Shared/native scheduling
is a development-host concern; a live parent NATIVE-HOLD.json still fences
native builds in the Floe workspace.

Read notices/ and manifests/WEB-BUILD-LINK-MAP.json. The full source archive
also contains components not linked into this Web build. Do not describe all
source, all user games or the complete combined binary as MIT or MPL alone.
The embedded upstream demo provenance review is retained; its own licensing
review and runtime distribution acceptance are separate from source assembly.
