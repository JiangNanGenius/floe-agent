#!/usr/bin/env bash
# SPDX-License-Identifier: MPL-2.0
#
# One controlled LGPL relink comparison:
#   1. rebuild the untouched baseline source,
#   2. rebuild the same source with the blip_buf marker patch,
#   3. package both runtime shapes,
#   4. verify the marker/hash/version/loader invariants and write a receipt.
#
# Native stage only.  Refuses to run while NATIVE-HOLD.json is present.  The
# actual Root load/compare remains a human WebKit/iPad step after this script.

set -euo pipefail

KIT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_ROOT="$(cd "$KIT_ROOT/../../../.." && pwd)"
HOLD="$KIT_ROOT/../NATIVE-HOLD.json"
if [[ -d "$KIT_ROOT/Resources" ]]; then DEFAULT_RESOURCES="$KIT_ROOT/Resources";
else DEFAULT_RESOURCES="$REPO_ROOT/Local/Artifacts/game-predevelopment-expanded/tic80-mpl-closure"; fi
export TIC80_RESOURCE_ROOT="${TIC80_RESOURCE_ROOT:-$DEFAULT_RESOURCES}"
BUILD_ROOT="${TIC80_ARTIFACT_ROOT:-${TIC80_RESOURCE_ROOT}/build}"
if [[ -d "$TIC80_RESOURCE_ROOT/shipped" ]]; then SHIPPED_ROOT="$TIC80_RESOURCE_ROOT/shipped";
else SHIPPED_ROOT="$REPO_ROOT/Local/Artifacts/game-predevelopment-expanded/narrative/resources-mpl-1/tic80"; fi
SHIPPED_JS="$SHIPPED_ROOT/tic80.js"
SHIPPED_WASM="$SHIPPED_ROOT/tic80js.wasm"
JOBS=6
SKIP_BUILD=0
OUT="$KIT_ROOT/evidence/RELINK-RECEIPT.json"

usage() { sed -n '2,18p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; }

while (($#)); do
    case "$1" in
        --jobs) JOBS="${2:?}"; shift 2 ;;
        --skip-build) SKIP_BUILD=1; shift ;;
        --out) OUT="${2:?}"; shift 2 ;;
        --shipped-js) SHIPPED_JS="${2:?}"; shift 2 ;;
        --shipped-wasm) SHIPPED_WASM="${2:?}"; shift 2 ;;
        -h|--help) usage; exit 0 ;;
        *) echo "unknown argument: $1" >&2; exit 2 ;;
    esac
done

fail() { echo "FAIL: $*" >&2; exit 1; }
note() { echo "==> $*"; }

if [[ "$SKIP_BUILD" == 0 && -f "$HOLD" ]]; then
    fail "NATIVE-HOLD.json is present ($HOLD); the native relink stage is not authorized. Wait for Root's explicit release and remove/rename the hold before running this comparison."
fi

if [[ "$SKIP_BUILD" == 0 ]]; then
    note "building baseline"
    "$KIT_ROOT/Scripts/build_tic80_web.sh" --variant baseline --jobs "$JOBS"
    note "building relink marker variant"
    "$KIT_ROOT/Scripts/build_tic80_web.sh" --variant relink --jobs "$JOBS"
else
    note "using existing packages (--skip-build)"
fi

BASELINE="$BUILD_ROOT/out/baseline"
RELINK="$BUILD_ROOT/out/relink"
[[ -f "$BASELINE/RUNTIME-MANIFEST.json" ]] || fail "missing baseline package: $BASELINE"
[[ -f "$RELINK/RUNTIME-MANIFEST.json" ]] || fail "missing relink package: $RELINK"

ARGS=(--baseline "$BASELINE" --relink "$RELINK" --out "$OUT")
if [[ -f "$SHIPPED_JS" && -f "$SHIPPED_WASM" ]]; then
    ARGS+=(--shipped-js "$SHIPPED_JS" --shipped-wasm "$SHIPPED_WASM")
fi
note "verifying relink artifacts"
python3 "$KIT_ROOT/Scripts/verify_relink.py" "${ARGS[@]}"

note "receipt: $OUT"
note "Root load order: baseline/upstream/index.html or floe-resource/index.html, then the relink package with the same cart. The relink variant must show the '-floe-relink1' version banner."
