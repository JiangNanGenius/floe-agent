#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Prove the assembled tree's files are the archive bytes, not a manifest echo.

`assemble_source.py --check` proves the tree matches its generated manifest.
This script independently opens every source archive, hashes each file member
and compares it with the assembled tree at the archive's real destination path.
It also checks symlink targets and that every tree file is covered by exactly
one archive.  Read-only; no network, no build.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import tarfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
ART = Path(
    "/Volumes/TECLAST-512/IOS AI AGENT/Local/Artifacts/"
    "game-predevelopment-expanded/tic80-mpl-closure"
)
TREE = ART / "source-tree/tic80-1.4.1"
DEPOT = ART / "source-depot"


def sha256_stream(stream) -> tuple[str, int]:
    h = hashlib.sha256()
    size = 0
    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
        h.update(chunk)
        size += len(chunk)
    return h.hexdigest(), size


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / "evidence/SOURCE-PROVENANCE.json")
    args = parser.parse_args()
    archives = json.loads((DEPOT / "ARCHIVES.json").read_text())
    covered: dict[str, str] = {}
    failures: list[str] = []
    checks = 0
    for key, record in sorted(archives["archives"].items()):
        archive = DEPOT / record["relativePath"]
        if not archive.is_file():
            failures.append(f"missing archive: {archive}")
            continue
        base = "" if record["kind"] == "upstream-main" else record["path"] + "/"
        with tarfile.open(archive, "r:gz") as tf:
            members = tf.getmembers()
            tops = {m.name.split("/", 1)[0] for m in members}
            if len(tops) != 1:
                failures.append(f"{key}: unexpected top-level entries {sorted(tops)}")
                continue
            top = tops.pop()
            for member in members:
                if not member.isfile() and not member.issym():
                    continue
                rel = member.name[len(top) + 1 :] if member.name != top else ""
                if not rel:
                    continue
                dest_rel = base + rel
                dest = TREE / dest_rel
                checks += 1
                if member.issym():
                    if not dest.is_symlink() or os.readlink(dest) != member.linkname:
                        failures.append(f"{dest_rel}: symlink mismatch")
                    covered[dest_rel] = key
                    continue
                if not dest.is_file() or dest.is_symlink():
                    failures.append(f"{dest_rel}: missing regular file")
                    continue
                source = tf.extractfile(member)
                if source is None:
                    failures.append(f"{dest_rel}: unreadable member")
                    continue
                digest, size = sha256_stream(source)
                if size != member.size:
                    failures.append(f"{dest_rel}: size {size} != archive {member.size}")
                if digest != sha256_file(dest):
                    failures.append(f"{dest_rel}: content hash mismatch")
                covered[dest_rel] = key

    tree_files = {}
    for dirpath, dirnames, filenames in os.walk(TREE, followlinks=False):
        for name in list(dirnames):
            path = Path(dirpath) / name
            if path.is_symlink():
                tree_files[path.relative_to(TREE).as_posix()] = path
                dirnames.remove(name)
        for name in filenames:
            path = Path(dirpath) / name
            tree_files[path.relative_to(TREE).as_posix()] = path
    uncovered = sorted(set(tree_files) - set(covered))
    extra = sorted(set(covered) - set(tree_files))
    if uncovered:
        failures.append(f"{len(uncovered)} tree files not covered by any archive; first: {uncovered[:5]}")
    if extra:
        failures.append(f"{len(extra)} archive members missing from tree; first: {extra[:5]}")

    manifest = json.loads((TREE.parent / "SOURCE-MANIFEST.json").read_text())
    payload = {
        "format": "floe-tic80-source-provenance",
        "version": 1,
        "kind": "read-only archive-to-tree byte comparison",
        "archives": len(archives["archives"]),
        "archiveMembersChecked": checks,
        "treeFiles": len(tree_files),
        "coveredTreeFiles": len(covered),
        "uncovered": uncovered[:20],
        "extra": extra[:20],
        "failures": failures[:50],
        "ok": not failures,
        "treeSHA256": manifest["treeSHA256"],
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({k: payload[k] for k in [
        "archives", "archiveMembersChecked", "treeFiles", "coveredTreeFiles", "ok"
    ]}, indent=2))
    for failure in failures[:20]:
        print("FAIL:", failure)
    return 0 if payload["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
