#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Package an independently relocatable, exact-source TIC-80 rebuild kit.

No engine/compiler execution. Existing source archives are verified, not
downloaded. Output contains all nested source archives and the actual build,
patch, notice and relink scripts, with a per-file integrity inventory.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

KIT = Path(__file__).resolve().parents[1]
REPO = KIT.parents[3]
RESOURCES = REPO / 'Local/Artifacts/game-predevelopment-expanded/tic80-mpl-closure'

def digest(file):
    h = hashlib.sha256()
    with file.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    args.output = args.output.resolve()
    if args.output.exists(): raise SystemExit('Preserve existing output; choose a fresh directory')
    args.output.mkdir(parents=True)
    folder = args.output / 'tic80-source-relink-kit'
    folder.mkdir()
    for name in ['Scripts', 'patches', 'notices', 'manifests', 'fixtures']:
        shutil.copytree(KIT / name, folder / name, ignore=shutil.ignore_patterns('__pycache__', '.DS_Store'))
    shutil.copy2(KIT / 'TOOLCHAIN.json', folder / 'TOOLCHAIN.json')
    depot = RESOURCES / 'source-depot'
    records = json.loads((depot / 'ARCHIVES.json').read_text())
    expected = records['archives']
    target = folder / 'Resources/source-depot'
    target.mkdir(parents=True)
    shutil.copy2(depot / 'ARCHIVES.json', target / 'ARCHIVES.json')
    for record in expected.values():
        rel = record['relativePath']
        source = depot / rel
        assert source.stat().st_size == record['bytes'] and digest(source) == record['sha256'], rel
        dest = target / rel; dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)
    shipped = folder / 'Resources/shipped'; shipped.mkdir()
    for name in ['tic80.js', 'tic80js.wasm', 'LICENSE.tic80.txt']:
        shutil.copy2(REPO / 'Local/Artifacts/game-predevelopment-expanded/narrative/resources-mpl-1/tic80' / name, shipped / name)
    (folder / 'README.md').write_text('''# TIC-80 exact-source rebuild and relink kit

Original source files retain their licenses; Floe helper scripts are MPL-2.0.
The 32 archives contain TIC-80 v1.4.1 and all 31 exact nested submodule sources.
No downloaded game, RTP or commercial engine license is supplied.

1. Run `python3 Scripts/assemble_source.py --assemble` in this directory. This
   verifies all archive hashes and assembles the complete source tree offline.
2. Install/activate the exact public tools in `TOOLCHAIN.json`, including emsdk
   6.0.13. The toolchain recipe is explicit; the original binary compiler
   identity and byte-identical reproduction are not claimed.
3. Run `bash Scripts/relink_compare.sh --jobs 6`. Both baseline and the actual
   modified blip_buf variant build from those sources. Outputs go under
   `Resources/build/out/`; the receipt goes under `evidence/`.
4. Inspect `evidence/RELINK-RECEIPT.json`, then load both floe-resource folders
   with the included original MIT cartridge in a WebKit host. Root acceptance
   is separate from source packing or a compiler return code.

`TIC80_RESOURCE_ROOT`, `TIC80_SOURCE_TREE`, `TIC80_ARTIFACT_ROOT` and
`TIC80_SCRATCH_ROOT` may select explicit local paths. Shared/native scheduling
is a development-host concern; a live parent NATIVE-HOLD.json still fences
native builds in the Floe workspace.

Read notices/ and manifests/WEB-BUILD-LINK-MAP.json. The full source archive
also contains components not linked into this Web build. Do not describe all
source, all user games or the complete combined binary as MIT or MPL alone.
The embedded upstream demo provenance review is retained; its own licensing
review and runtime distribution acceptance are separate from source assembly.
''')
    (folder / 'evidence').mkdir()
    # Prove the relocated archive depot is readable without the original path.
    run = subprocess.run([sys.executable, str(folder / 'Scripts/assemble_source.py'), '--verify-archives'],
                         cwd=folder, capture_output=True, text=True)
    assert run.returncode == 0, run.stderr + run.stdout
    files = {}
    for file in sorted(folder.rglob('*')):
        assert not file.is_symlink(), file
        if file.is_file(): files[file.relative_to(folder).as_posix()] = {'sha256': digest(file), 'bytes': file.stat().st_size}
    manifest = {'format': 'floe-tic80-source-companion', 'version': 1,
                'sourceArchives': len(expected), 'files': files,
                'sourceAssemblyVerified': False, 'relocatedDepotVerified': True,
                'nativeRebuildVerified': False, 'appStoreApprovalClaimed': False}
    (folder / 'COMPANION-MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
    archive = args.output / 'tic80-complete-source-relink.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=1) as z:
        for file in sorted(folder.rglob('*')):
            if file.is_file(): z.write(file, 'tic80-source-relink-kit/' + file.relative_to(folder).as_posix())
    receipt = {'bundle': str(archive), 'bytes': archive.stat().st_size, 'sha256': digest(archive),
               'sourceArchives': len(expected), 'fileCount': len(files) + 1,
               'relocatedSourceDepotCheck': run.stdout.strip(), 'nativeRebuildVerified': False}
    (args.output / 'SOURCE-COMPANION-RECEIPT.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))

if __name__ == '__main__': main()
