#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Create the original Floe TIC-80 relink-check cartridge.

The cartridge is Floe-authored MIT content.  It is deliberately tiny, uses no
third-party game data, and prints a moving marker so a human can see that the
rebuilt runtime is actually executing a cartridge.  The blip_buf relink marker
is proved separately by the wasm bytes and the version banner because this
fixture does not depend on the audio path.

Chunk encoding matches src/cart.c / the existing FloeGameNarrativeKit TICCart:
a 32-bit little-endian header (type:5, bank:3, size:16) followed by payload.
"""

from __future__ import annotations

import argparse
import hashlib
import struct
from pathlib import Path

CODE = """// script: js
// title: Floe TIC-80 relink check
// author: Floe contributors
// desc: original MIT fixture for rebuilt-runtime comparison
// license: MIT
var t = 0;
function TIC() {
  t++;
  cls(0);
  rectb(0, 0, 240, 136, 12);
  rectb(2, 2, 236, 132, 5);
  print("FLOE RELINK CHECK", 38, 56, 12, false, 1, false);
  print("RUNTIME OK", 82, 72, 6, false, 1, false);
  print(t % 60 < 30 ? ">" : "<", 116, 90, 14, false, 1, false);
}
"""

DEFAULT_CHUNK = 17
CODE_CHUNK = 5
LANGUAGE_CHUNK = 20
JS = 12
BANK = 65536


def chunk(kind: int, bank: int, data: bytes) -> bytes:
    if len(data) > BANK:
        raise ValueError("chunk too large")
    size = 0 if (len(data) == BANK and kind in (CODE_CHUNK, 19)) else len(data)
    header = struct.pack("<I", kind | ((bank & 7) << 5) | (size << 8))
    return header + data


def build() -> bytes:
    return (
        chunk(DEFAULT_CHUNK, 0, b"")
        + chunk(CODE_CHUNK, 0, CODE.encode("utf-8"))
        + chunk(LANGUAGE_CHUNK, 0, bytes([JS]))
    )


def parse(data: bytes) -> list[tuple[int, int, bytes]]:
    out = []
    index = 0
    while index + 4 <= len(data):
        raw = struct.unpack_from("<I", data, index)[0]
        index += 4
        kind = raw & 0x1F
        bank = (raw >> 5) & 7
        size = (raw >> 8) & 0xFFFF
        if size == 0 and kind in (CODE_CHUNK, 19):
            size = BANK
        payload = data[index : index + size]
        if len(payload) != size:
            raise ValueError("truncated chunk")
        index += size
        out.append((kind, bank, payload))
    if index != len(data):
        raise ValueError("trailing bytes")
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    data = build()
    chunks = parse(data)
    if [c[0] for c in chunks] != [DEFAULT_CHUNK, CODE_CHUNK, LANGUAGE_CHUNK]:
        raise SystemExit("fixture self-check failed: unexpected chunk sequence")
    if chunks[2][2] != bytes([JS]):
        raise SystemExit("fixture self-check failed: language is not JS")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_bytes(data)
    digest = hashlib.sha256(data).hexdigest()
    args.out.with_suffix(args.out.suffix + ".sha256").write_text(
        f"{digest}  {args.out.name}\n"
    )
    args.out.with_suffix(".js").write_text(CODE)
    print(f"wrote {args.out} ({len(data)} bytes) sha256 {digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
