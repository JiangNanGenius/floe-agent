#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Read-only source/package checks for the TIC-80 MPL/LGPL closure kit.

This is intentionally a source-only check.  It does not run emcc, a browser,
an engine, a simulator or a native test.  It verifies the depot, the assembled
tree, the patches, the manifests, the notices, the fixture and (if present) the
packaged runtime hashes.

Exit status is non-zero on any failed check.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
ART = Path(
    "/Volumes/TECLAST-512/IOS AI AGENT/Local/Artifacts/"
    "game-predevelopment-expanded/tic80-mpl-closure"
)
TREE = ART / "source-tree/tic80-1.4.1"
DEPOT = ART / "source-depot"

CHECKS: list[dict] = []


def check(name: str, ok: bool, detail: str) -> None:
    CHECKS.append({"name": name, "ok": bool(ok), "detail": detail})


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text())
    except Exception as exc:  # noqa: BLE001
        check(f"json parse {path.name}", False, str(exc))
        return {}


def tree_digest(root: Path) -> str:
    entries = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames.sort()
        for name in list(dirnames):
            path = Path(dirpath) / name
            if path.is_symlink():
                rel = path.relative_to(root).as_posix()
                entries.append((rel, b"l\0" + os.readlink(path).encode()))
                dirnames.remove(name)
        for name in filenames:
            path = Path(dirpath) / name
            rel = path.relative_to(root).as_posix()
            if path.is_symlink():
                entries.append((rel, b"l\0" + os.readlink(path).encode()))
            else:
                entries.append((rel, b"f\0" + sha256_file(path).encode()))
    h = hashlib.sha256()
    for rel, payload in sorted(entries):
        h.update(rel.encode())
        h.update(b"\0")
        h.update(payload)
        h.update(b"\n")
    return h.hexdigest()


def check_depot() -> None:
    pins = load_json(ROOT / "SOURCE-PINS.json")
    archives = load_json(DEPOT / "ARCHIVES.json")
    if not pins or not archives:
        return
    subs = pins.get("submodules", [])
    check("source pins count", len(subs) == 31, f"{len(subs)} submodules (28 top-level + 3 nested)")
    check("archives complete", archives.get("complete") is True, str(archives.get("missing")))
    check("archive count", len(archives.get("archives", {})) == 32, f"{len(archives.get('archives', {}))} archives")
    for key, record in archives.get("archives", {}).items():
        path = DEPOT / record["relativePath"]
        if not path.is_file():
            check(f"archive exists {key}", False, str(path))
            continue
        check(
            f"archive hash {key}",
            sha256_file(path) == record["sha256"] and path.stat().st_size == record["bytes"],
            record["sha256"][:16],
        )
    main = archives.get("archives", {}).get("upstream", {})
    check(
        "upstream archive hash",
        main.get("sha256") == pins.get("upstream", {}).get("sha256"),
        main.get("sha256", ""),
    )
    for sub in subs:
        path = TREE / sub["path"]
        check(f"submodule path populated {sub['path']}", path.is_dir() and any(path.iterdir()), sub["commit"][:12])


def check_tree() -> None:
    manifest_path = TREE.parent / "SOURCE-MANIFEST.json"
    manifest = load_json(manifest_path)
    if not manifest:
        return
    check("source tree exists", TREE.is_dir(), str(TREE))
    digest = tree_digest(TREE)
    check("source tree manifest digest", digest == manifest.get("treeSHA256"), f"{digest} vs {manifest.get('treeSHA256')}")
    check("source tree file count", manifest.get("fileCount") == len(manifest.get("files", {})), str(manifest.get("fileCount")))
    for required in [
        "CMakeLists.txt",
        "cmake/version.cmake",
        "cmake/blipbuf.cmake",
        "build/mruby/tic_default.rb",
        "build/html/prejs.js",
        "src/core/sound.c",
        "vendor/blip-buf/blip_buf.c",
        "vendor/lua/lua.h",
        "vendor/mruby/include/mruby.h",
        "vendor/quickjs/quickjs.h",
    ]:
        check(f"required source {required}", (TREE / required).is_file(), required)


def check_patches() -> None:
    patches = sorted((ROOT / "patches").glob("*.patch"))
    check("patch count", len(patches) == 3, f"{len(patches)} patches")
    with tempfile.TemporaryDirectory(prefix="tic80-patch-check-") as tmp:
        tmp = Path(tmp)
        (tmp / "cmake").mkdir()
        (tmp / "vendor/blip-buf").mkdir(parents=True)
        shutil.copy2(TREE / "cmake/version.cmake", tmp / "cmake/version.cmake")
        shutil.copy2(TREE / "vendor/blip-buf/blip_buf.c", tmp / "vendor/blip-buf/blip_buf.c")

        def apply(patch: Path, dry: bool = False) -> subprocess.CompletedProcess:
            cmd = ["patch", "-p1", "--forward", "--fuzz=0", "-i", str(patch)]
            if dry:
                cmd.insert(2, "--dry-run")
            return subprocess.run(cmd, cwd=tmp, capture_output=True, text=True, check=False)

        p1 = ROOT / "patches/0001-release-identity-1.4.1.patch"
        p2 = ROOT / "patches/0002-relink-version-marker.patch"
        p3 = ROOT / "patches/0003-blip-buf-relink-marker.patch"
        result = apply(p1)
        check("patch 0001 applies", result.returncode == 0, result.stderr.strip() or result.stdout.strip())
        result = apply(p2, dry=True)
        check("patch 0002 dry-run after 0001", result.returncode == 0, result.stderr.strip() or result.stdout.strip())
        result = apply(p3, dry=True)
        check("patch 0003 dry-run on pristine blip_buf", result.returncode == 0, result.stderr.strip() or result.stdout.strip())
        result = apply(p3)
        check("patch 0003 applies", result.returncode == 0, result.stderr.strip() or result.stdout.strip())
        version = (tmp / "cmake/version.cmake").read_text()
        blip = (tmp / "vendor/blip-buf/blip_buf.c").read_text()
        check("patched release revision", 'set(VERSION_REVISION 1)' in version, "")
        check("patched hash", 'set(VERSION_HASH "b3dbd59")' in version, "")
        check("patched blip marker", "FLOE-BLIP-RELINK-MARKER-v1" in blip, "")


def check_manifests() -> None:
    for name in ["WEB-BUILD-LINK-MAP.json", "LICENSE-INDEX.json", "EMBEDDED-ASSET-REVIEW.json"]:
        path = ROOT / "manifests" / name
        check(f"manifest exists {name}", path.is_file(), str(path))
    link = load_json(ROOT / "manifests/WEB-BUILD-LINK-MAP.json")
    if link:
        by_id = {c["id"]: c for c in link.get("components", [])}
        check("blip_buf linked", by_id.get("blip-buf", {}).get("linked") is True, "LGPL consumer is linked")
        check("no GPL linked", link.get("licenseSummary", {}).get("gplLinked") == [], str(link.get("licenseSummary", {}).get("gplLinked")))
        check("Circle not linked", by_id.get("circle", {}).get("linked") is False, "baremetal GPL boundary")
        check("pForth not linked", by_id.get("pforth", {}).get("linked") is False, "BUILD_WITH_FORTH=OFF")
        check("SDL2 not linked", by_id.get("sdl2", {}).get("linked") is False, "Sokol build")
        check("linked component count", len(by_id) == 39, str(len(by_id)))
    lic = load_json(ROOT / "manifests/LICENSE-INDEX.json")
    if lic:
        check("license index non-empty", len(lic.get("licenseFiles", [])) >= 40, str(len(lic.get("licenseFiles", []))))
        for entry in lic.get("licenseFiles", []):
            path = TREE / entry["path"]
            if entry["path"].startswith("notices/"):
                path = ROOT / entry["path"]
            check(f"license file {entry['path']}", path.is_file() and sha256_file(path) == entry["sha256"], entry["path"])
    assets = load_json(ROOT / "manifests/EMBEDDED-ASSET-REVIEW.json")
    if assets:
        check("embedded asset count", len(assets.get("assets", [])) == 42, str(len(assets.get("assets", []))))
        unclear = [a for a in assets.get("assets", []) if a.get("licenseStatus") == "no-explicit-license"]
        check("no-explicit-license demo review present", len(unclear) >= 20, f"{len(unclear)} community/mark demos without an explicit grant")


def check_notices_toolchain() -> None:
    notices = ROOT / "notices/THIRD-PARTY-NOTICES-WEB.md"
    check("third-party notice exists", notices.is_file(), str(notices))
    if notices.is_file():
        text = notices.read_text()
        for needle in [
            "LGPL-2.1-or-later",
            "No GPL text is linked",
            "community demo",
            "not a legal opinion",
            "Emscripten",
        ]:
            check(f"notice contains {needle}", needle in text, needle)
    tool = load_json(ROOT / "TOOLCHAIN.json")
    if tool:
        check("emsdk pin", tool.get("emsdk", {}).get("version") == "6.0.13", tool.get("emsdk", {}).get("version", ""))
        lic = ROOT / "notices/EMSCRIPTEN-LICENSE.txt"
        check("Emscripten license hash", lic.is_file() and sha256_file(lic) == tool.get("emsdk", {}).get("licenseSHA256"), tool.get("emsdk", {}).get("licenseSHA256", ""))


def check_fixture() -> None:
    fixture = ROOT / "fixtures/floe-relink-check.tic"
    sidecar = ROOT / "fixtures/floe-relink-check.tic.sha256"
    check("fixture exists", fixture.is_file(), str(fixture))
    if not fixture.is_file():
        return
    digest = sha256_file(fixture)
    if sidecar.is_file():
        check("fixture sidecar", sidecar.read_text().split()[0] == digest, digest)
    data = fixture.read_bytes()
    chunks = []
    index = 0
    while index + 4 <= len(data):
        raw = struct.unpack_from("<I", data, index)[0]
        index += 4
        kind = raw & 0x1F
        size = (raw >> 8) & 0xFFFF
        payload = data[index : index + size]
        if len(payload) != size:
            check("fixture chunk truncation", False, f"chunk {kind}")
            return
        index += size
        chunks.append((kind, payload))
    check("fixture parses exactly", index == len(data), f"{len(chunks)} chunks")
    check("fixture chunk order", [c[0] for c in chunks] == [17, 5, 20], str([c[0] for c in chunks]))
    check("fixture JS language", len(chunks) == 3 and chunks[2][1] == b"\x0c", "language 12")
    check("fixture visible marker", len(chunks) == 3 and b"FLOE RELINK CHECK" in chunks[1][1], "")


def check_scripts() -> None:
    shell_scripts = sorted((ROOT / "Scripts").glob("*.sh"))
    py_scripts = sorted((ROOT / "Scripts").glob("*.py"))
    check("shell script count", len(shell_scripts) >= 2, str(len(shell_scripts)))
    for script in shell_scripts:
        result = subprocess.run(["bash", "-n", str(script)], capture_output=True, text=True, check=False)
        check(f"bash syntax {script.name}", result.returncode == 0, result.stderr.strip())
        text = script.read_text()
        check(f"strict shell {script.name}", "set -euo pipefail" in text, "")
        if script.name != "relink_compare.sh":
            check(f"no network in build {script.name}", "curl " not in text and "wget " not in text, "")
    check("relink compares hold", "NATIVE-HOLD.json" in (ROOT / "Scripts/relink_compare.sh").read_text(), "")
    for script in py_scripts:
        try:
            compile(script.read_text(), str(script), "exec")
            ok, detail = True, ""
        except SyntaxError as exc:
            ok, detail = False, str(exc)
        check(f"python syntax {script.name}", ok, detail)


def check_package_if_present() -> None:
    for variant in ["baseline", "relink"]:
        root = ART / "build/out" / variant
        manifest_path = root / "RUNTIME-MANIFEST.json"
        if not manifest_path.is_file():
            continue
        manifest = load_json(manifest_path)
        ok = True
        for entry in manifest.get("files", []):
            path = root / entry["path"]
            if not path.is_file() or sha256_file(path) != entry["sha256"]:
                ok = False
                break
        check(f"runtime package {variant}", ok, str(root))
        profile = load_json(root / "runtime-profile.json")
        if profile:
            check(f"runtime profile marker {variant}", profile.get("blipRelinkMarker") is (variant == "relink"), str(profile.get("blipRelinkMarker")))


def check_evidence_and_profile() -> None:
    for name in ["README.md", "RELINK.md", "SOURCE-INVENTORY.md", "SOURCE-READY.json", "HANDOFF.json", "CHECKPOINT.json"]:
        check(f"document exists {name}", (ROOT / name).is_file(), name)
    shipped = load_json(ROOT / "evidence/SHIPPED-BASELINE.json")
    if shipped:
        base = Path("/Volumes/TECLAST-512/IOS AI AGENT/Local/Artifacts/game-predevelopment-expanded/narrative/resources-mpl-1/tic80")
        check("shipped baseline js hash", sha256_file(base / "tic80.js") == shipped.get("files", {}).get("tic80.js", {}).get("sha256"), shipped.get("files", {}).get("tic80.js", {}).get("sha256", ""))
        check("shipped baseline wasm hash", sha256_file(base / "tic80js.wasm") == shipped.get("files", {}).get("tic80js.wasm", {}).get("sha256"), shipped.get("files", {}).get("tic80js.wasm", {}).get("sha256", ""))
    pins = load_json(ROOT / "evidence/SUBMODULE-PIN-VERIFICATION.json")
    if pins:
        check("pin verification ok", pins.get("ok") is True, f"{pins.get('topLevelGitlinks')} top + {pins.get('nestedPocketpyGitlinks')} nested")
        check("pin verification mismatches", pins.get("mismatches") == [], str(pins.get("mismatches")))
    profile = load_json(ROOT / "profile/floe-tic80-1.4.1-relink1.json")
    if profile:
        check("profile is prepared not built", profile.get("status") == "prepared-not-built", profile.get("status", ""))
        check("profile hashes unset", profile.get("hashes", {}).get("jsSHA256") is None and profile.get("hashes", {}).get("wasmSHA256") is None, "null means not built")
        check("profile default resources unchanged", profile.get("rootAdoption", {}).get("defaultResourcesUnchanged") is True, "")
    check("GPL text retained", (ROOT / "notices/LICENSES/GPL-3.0-or-later.txt").is_file(), "")
    ready = load_json(ROOT / "SOURCE-READY.json")
    if ready:
        check("source ready tree hash", ready.get("assembledTree", {}).get("treeSHA256") == "94a0b8521a9b63e58c676c1b8c63313cf3dd2eb0822265cc8865ec9840e1794a", "")
        check("source ready archive count", ready.get("archives", {}).get("count") == 32, str(ready.get("archives", {}).get("count")))
        check("source ready relink status", ready.get("relink", {}).get("status") == "prepared-not-executed", ready.get("relink", {}).get("status", ""))
    provenance = load_json(ROOT / "evidence/SOURCE-PROVENANCE.json")
    if provenance:
        check("source provenance ok", provenance.get("ok") is True, f"{provenance.get('coveredTreeFiles')}/{provenance.get('treeFiles')} files covered")
        check("source provenance coverage", provenance.get("archiveMembersChecked") == provenance.get("treeFiles") == 9820, f"{provenance.get('archiveMembersChecked')} members, {provenance.get('treeFiles')} tree files")
    precondition = load_json(ROOT / "evidence/NATIVE-PRECONDITION.json")
    if precondition:
        check("native precondition recorded", precondition.get("exitCode") == 3 and "nativeHold" in precondition, str(precondition.get("exitCode")))
        check("native precondition no-build claim", "native build" in precondition.get("notClaimed", []), str(precondition.get("notClaimed", [])))
    handoff = load_json(ROOT / "HANDOFF.json")
    if handoff:
        check("handoff ownership released", handoff.get("sourceOwnershipReleased") is True, str(handoff.get("sourceOwnershipReleased")))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / "evidence/KIT-CHECK.json")
    args = parser.parse_args()

    check_depot()
    check_tree()
    check_patches()
    check_manifests()
    check_notices_toolchain()
    check_fixture()
    check_scripts()
    check_evidence_and_profile()
    check_package_if_present()

    failures = [c for c in CHECKS if not c["ok"]]
    payload = {
        "format": "floe-tic80-kit-check",
        "kind": "source-only; no native/browser/engine execution",
        "checks": len(CHECKS),
        "passed": len(CHECKS) - len(failures),
        "failed": len(failures),
        "ok": not failures,
        "results": CHECKS,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2) + "\n")
    for check_item in CHECKS:
        if not check_item["ok"]:
            print(f"FAIL {check_item['name']}: {check_item['detail']}")
    print(f"{payload['passed']}/{payload['checks']} checks passed; failed={payload['failed']}")
    print(f"written: {args.out}")
    return 0 if payload["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
