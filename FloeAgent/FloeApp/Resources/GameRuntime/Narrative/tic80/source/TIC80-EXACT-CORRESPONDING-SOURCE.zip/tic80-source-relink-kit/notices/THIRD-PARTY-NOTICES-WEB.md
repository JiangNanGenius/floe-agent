# TIC-80 1.4.1 Web runtime — third-party notices

This notice accompanies a rebuilt TIC-80 universal Web player assembled from
the exact TIC-80 v1.4.1 source (`b3dbd597eecfe6742f64001c2fe5ba6c1afe55d9`)
and the pinned submodule sources in the Floe source depot.

It is a source/build inventory, not a legal opinion, not an App Store
clearance, and not a statement that every upstream file is covered by the
top-level MIT license. Third-party components keep their own terms. The
original license files and notices are preserved in the source tree; the full
texts for the linked runtime are reproduced below.

## Build this notice describes

- Emscripten universal Web player, `BUILD_WITH_ALL=ON`, `BUILD_TOUCH_INPUT=ON`,
  `BUILD_EDITORS=ON`, `BUILD_SURF=ON`, `BUILD_STATIC=ON`, `BUILD_WITH_ZLIB=ON`.
- Sokol Web system layer (`BUILD_SOKOL=ON`, `BUILD_SDL=OFF`).
- `BUILD_WITH_FORTH=OFF` (pForth is OFF even in a build-all configuration).
- Artifacts: `tic80.js` (loader/runtime JS) and `tic80.wasm` (engine). Floe's
  resource shape renames the engine to `tic80js.wasm` and rewrites the loader's
  `locateFile()` reference; the bytes of the engine are unchanged by that
  rename.

## Components linked into the universal Web player

| Component | Version / source pin | License | Copyright / notice |
| --- | --- | --- | --- |
| TIC-80 engine | v1.4.1 `b3dbd59` | MIT | Copyright (c) 2017 Vadim Grigoruk |
| blip_buf | `330226d9b55ecbeea644e17b5e0f096a165ca07e` | **LGPL-2.1-or-later** | Copyright (C) 2003-2009 Shay Green |
| Lua | `75ea9ccbea7c4886f30da147fb67b693b2624c26` | MIT | Copyright (C) 1994-2025 Lua.org, PUC-Rio |
| LPeg | `80ec9f932aa01d445e86c699523265359055e1bd` | MIT | Copyright (c) 2007-2023 Lua.org, PUC-Rio |
| MoonScript | `17179283012b392bff972ad66231d73bfeec6e90` | MIT | Copyright (c) 2014 Leaf Corcoran |
| YueScript | `4e3770ec50faf0b38c9bb4639191e4079df17155` | MIT | Copyright (c) 2017-2026 Li Jin |
| Fennel | vendored in TIC-80 `b3dbd59` | MIT | Copyright (c) 2016-2024 Calvin Rose and contributors |
| s7 Scheme | vendored in TIC-80 `b3dbd59` | 0BSD | Copyright (c) Bill Schottstaedt |
| Squirrel | `c02bf2dfd599a0b99b814d486512a3ee934667f1` | MIT | Copyright (c) 2003-2022 Alberto Demichelis |
| Wren | `4a18fc489f9ea3d253b20dd40f4cdad0d6bb40eb` | MIT | Copyright (c) 2013-2021 Robert Nystrom and Wren Contributors |
| mruby | `831da26b9021de0369d17b71b5667e2941a1a32d` | MIT | Copyright (c) 2010- mruby developers |
| QuickJS-ng | `6d46d07d04041b40f4f49eaa7fdebe44c314c699` | MIT | Copyright (c) 2017-2026 Fabrice Bellard; 2017-2024 Charlie Gordon; 2023-2026 Ben Noordhuis; 2023-2026 Saúl Ibarra Corretgé |
| pocketpy | `979addecf9cb180c59c16ac605ba75441ece5af6` | MIT | Copyright (c) 2026 blueloveTH |
| wasm3 | `139076a98b8321b67f850a844f558b5e91b5ac83` | MIT | Copyright (c) 2019 Steven Massey, Volodymyr Shymanskyy |
| Janet | `e1963cdfe0148f83601907727e00bd672d798115` | MIT | Copyright (c) 2026 Calvin Rose and contributors |
| Gravity | `07ebb9730761ee89a2b19873f5f6bf205574535c` | MIT | Copyright (c) 2017 Marco Bambini |
| MiniScript 2 | `a5a546a9960430aab31eb713f65bfe4a46b37c05` | MIT | Copyright (c) 2025 JoeStrout |
| libpng | `ed217e3e601d8e462f7fd1e04bed43ac42212429` | libpng-2.0 | Copyright (c) 1995-2024 The PNG Reference Library Authors; Cosmin Truta; Glenn Randers-Pehrson; Andreas Dilger; Guy Eric Schalnat, Group 42, Inc. |
| zlib | `51b7f2abdade71cd9bb0e7a373ef2610ec6f9daf` | Zlib | Copyright (C) 1995-2022 Jean-loup Gailly and Mark Adler |
| giflib | `1aa11b06d0025eda77b56aec8254130654d4397b` | MIT | Copyright (c) 1997 Eric S. Raymond |
| kuba--/zip (miniz) | `296ff2421b6bdb82575dd943fb8b5d7d5d443903` | MIT | Copyright (c) Kuba Podgórski |
| jsmn | `25647e692c7906b96ffd2b05ca54c097948e879c` | MIT | Copyright (c) 2010 Serge A. Zaitsev |
| argparse | `0d5f5d0745df14a3f373f7eed85bf524714f4524` | MIT | Copyright (c) 2012-2013 Yecheng Fu |
| sokol | `2e75443dbd4940b5aa8d76a8e479f8e4b270b9a3` | Zlib | Copyright (c) 2018 Andre Weissflog |
| Clay | `e6cc36941ab2af5d81107617039d6f527a1c660b` | Zlib | Copyright (c) 2024 Nic Barker |
| KISS FFT | in TIC-80 `b3dbd59` | BSD-3-Clause | Copyright (c) 2003-2010 Mark Borgerding |
| msf_gif | in TIC-80 `b3dbd59` | MIT OR Unlicense | Copyright (c) 2025 Miles Fogle |
| RetroArch common headers | in TIC-80 `b3dbd59` | MIT | Copyright (C) 2010-2020 The RetroArch team |
| Emscripten generated runtime JS | toolchain 6.0.13 | MIT OR NCSA | Copyright (c) 2010-2024 Emscripten authors |

`vendor/miniscript2_extras/keyboard.cpp` is the TIC-80 host's dummy keyboard
adapter for the MiniScript2 demo host. It has no separate license file in the
exact tree and is treated as part of the MiniScript 2 source distribution;
this is a provenance statement, not a broader grant for the demo cartridges
discussed below.

## Present in the source archive but NOT linked in this Web build

These components are retained because they are part of the exact upstream
v1.4.1 source and its pinned submodules. They are **not compiled into the
universal Web player** in the configuration above.

| Component | Why not linked |
| --- | --- |
| Circle / baremetal Pi files (`src/system/baremetalpi`) | GPL-3.0-or-later text is present for the baremetal Pi platform only. The Emscripten Web build never compiles these files. **No GPL text is linked into this Web runtime.** |
| pForth (`vendor/pforth`) | `BUILD_WITH_FORTH=OFF`; the source marks pForth unsafe because it has no memory sandbox. |
| SDL2 (`vendor/sdl2`) | The Web build selects Sokol; `BUILD_SDL=OFF` and the vendor SDL2 tree is not added. |
| SDL_gpu (`vendor/sdl-gpu`) | `BUILD_SDLGPU=OFF`. |
| naett (`vendor/naett`) | `cmake/naett.cmake` forces `USE_NAETT FALSE` for Emscripten. |
| dirent / dlfcn-win32 | Windows-only helpers. |
| miniaudio (`src/ext/miniaudio.h`) | The Sokol Web audio path does not include miniaudio. The notice is preserved but it is not claimed as linked. |
| pocketpy nested submodules (dmath, lz4, c-periphery) | Their PocketPy features are OFF in this build; included for a complete recursive source depot. |
| QuickJS test262 | Test-only corpus, `update=none`; excluded from the depot and not linked. |

## Embedded upstream demo cartridges

The universal player embeds data from `build/assets/*.tic.dat` through the
language API translation units (`src/api/lua.c`, `js.c`, `mruby.c`, etc.).
Some are templates that self-declare MIT in their `demos/` header; some are
TIC-80 studio assets; some are community demo cartridges whose headers name an
author but contain no explicit license grant; some are upstream mark carts with
no separate source file or explicit grant in the exact v1.4.1 tree.

They are original upstream data. Floe does not relicense them, does not claim
they are MIT merely because TIC-80's top-level LICENSE is MIT, and does not
present them as Floe-created content. The exact per-asset review, hashes,
authors, `licenseStatus` and build inclusion is in
`EMBEDDED-ASSET-REVIEW.json` in the kit's `manifests/` directory. A
distribution that must avoid unclear community-demo terms should use a
no-community-demo build or replace those embedded carts; this kit does not
silently make that change.

## Full license texts

The following texts are reproduced from the exact source tree or the pinned
toolchain. Component-specific copyright lines are in the table above.

### TIC-80 MIT

See `TIC-80-MIT.txt` in this directory.

### blip_buf LGPL-2.1-or-later

See `LICENSES/LGPL-2.1-or-later.txt` in this directory. The upstream
`vendor/blip-buf/license.txt` is the same LGPL-2.1 text; the blip_buf source
also carries the LGPL notice in each source file.

### MIT

See `LICENSES/MIT.txt`.

### 0BSD

See `LICENSES/0BSD.txt`.

### Zlib

See `LICENSES/Zlib.txt`.

### libpng-2.0

See `LICENSES/libpng-2.0.txt`.

### BSD-3-Clause (KISS FFT)

See `LICENSES/BSD-3-Clause.txt`.

### Unlicense

See `LICENSES/Unlicense.txt`.

### Emscripten (MIT OR NCSA)

See `EMSCRIPTEN-LICENSE.txt`.

## Source availability and LGPL route

The complete corresponding source for the universal Web player is the
assembled source tree plus the source depot described by the kit's
`SOURCE-PINS.json`, `ARCHIVES.json`, `SOURCE-MANIFEST.json` and `RELINK.md`.
The depot includes the exact TIC-80 archive, every pinned submodule archive,
the build generators (`build/mruby/*`, `build/html/*`, `build/assets/*`) and
the complete original license files.

For the LGPL-2.1-or-later blip_buf component, the kit provides a complete
consumer source tree, the exact upstream blip_buf source, full rebuild scripts
and a controlled baseline/modified build comparison. The modified source and
the full Web program are rebuilt from source; no reverse-engineering
restriction, no hidden download and no future written-offer promise is added.
This engineering record is not itself a legal written offer. A distributor of
a binary must accompany it with the source in the manner the LGPL requires.

---

The Floe-authored arrangement and commentary in this notice are MPL-2.0.
The quoted third-party license texts and component notices retain their own
terms; nothing here relicenses a third-party component.
