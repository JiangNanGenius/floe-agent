#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Assemble and verify the self-contained TIC-80 v1.4.1 Web source tree.

The depot holds only exact commit-addressed source archives (see
ARCHIVES.json).  This script extracts them without ever following a path out of
the destination, checks the recorded SHA-256 of every archive, overlays the
pinned submodules at their real paths, and writes a file-level manifest.

Offline by construction: it never downloads anything.

Usage:
  assemble_source.py --assemble
  assemble_source.py --check
  assemble_source.py --verify-archives
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import stat
import sys
import tarfile
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RESOURCE_ROOT = Path(os.environ.get("TIC80_RESOURCE_ROOT", str(
    ROOT / "Resources" if (ROOT / "Resources").is_dir() else
    ROOT.parents[3] / "Local/Artifacts/game-predevelopment-expanded/tic80-mpl-closure")))
DEFAULT_DEPOT = Path(os.environ.get("TIC80_SOURCE_DEPOT", str(RESOURCE_ROOT / "source-depot")))
DEFAULT_TREE = Path(os.environ.get("TIC80_SOURCE_TREE", str(RESOURCE_ROOT / "source-tree/tic80-1.4.1")))
REQUIRED_PATHS = [
    "CMakeLists.txt",
    "cmake/wasm.cmake",
    "cmake/sokol.cmake",
    "cmake/core.cmake",
    "cmake/blipbuf.cmake",
    "cmake/mruby.cmake",
    "cmake/quickjs.cmake",
    "cmake/pocketpy.cmake",
    "build/mruby/tic_default.rb",
    "build/mruby/tic.gembox",
    "build/html/prejs.js",
    "build/html/index.html",
    "src/system/sokol/sokol_impl.c",
    "src/system/sokol/main.c",
    "src/core/sound.c",
    "vendor/blip-buf/blip_buf.c",
    "vendor/blip-buf/blip_buf.h",
    "vendor/lua/lua.h",
    "vendor/mruby/include/mruby.h",
    "vendor/quickjs/quickjs.h",
    "vendor/wasm3/source/wasm3.h",
]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_extract(archive: Path, destination: Path) -> str:
    """Extract one archive, stripping its single top-level directory.

    Returns the stripped directory name.  Rejects absolute paths, traversal,
    links that resolve outside the archive root, device nodes and setuid bits.
    """
    destination = destination.resolve()
    with tarfile.open(archive, "r:gz") as tf:
        members = tf.getmembers()
        if not members:
            raise RuntimeError(f"empty archive: {archive}")
        tops = {m.name.split("/", 1)[0] for m in members}
        if len(tops) != 1:
            raise RuntimeError(f"archive has more than one top-level entry: {archive}: {sorted(tops)}")
        top = tops.pop()
        for member in members:
            name = member.name
            if name.startswith("/") or "\\" in name or ".." in name.split("/"):
                raise RuntimeError(f"unsafe path in {archive}: {name!r}")
            if member.isdev():
                raise RuntimeError(f"device node in {archive}: {name}")
            if member.mode & 0o6000:
                raise RuntimeError(f"setuid/setgid mode in {archive}: {name}")
            if member.islnk():
                raise RuntimeError(f"hard link in {archive}: {name} -> {member.linkname}")
            if member.issym():
                base = Path(name).parent
                target = Path(os.path.normpath(str(base / member.linkname)))
                if target.is_absolute() or str(target).startswith(".."):
                    raise RuntimeError(
                        f"symlink escapes archive root in {archive}: {name} -> {member.linkname}"
                    )
            if name == top:
                continue
            rel = Path(name).relative_to(top)
            out = (destination / rel).resolve()
            if not (str(out) == str(destination) or str(out).startswith(str(destination) + os.sep)):
                raise RuntimeError(f"path escapes destination in {archive}: {name}")
            if member.isdir():
                out.mkdir(parents=True, exist_ok=True)
                os.chmod(out, 0o755)
            elif member.isfile():
                out.parent.mkdir(parents=True, exist_ok=True)
                source = tf.extractfile(member)
                if source is None:
                    raise RuntimeError(f"unreadable member in {archive}: {name}")
                with out.open("wb") as fh:
                    shutil.copyfileobj(source, fh, 1024 * 1024)
                os.chmod(out, 0o644)
            elif member.issym():
                out.parent.mkdir(parents=True, exist_ok=True)
                if out.exists() or out.is_symlink():
                    out.unlink()
                os.symlink(member.linkname, out)
            else:
                raise RuntimeError(f"unsupported tar member type in {archive}: {name}")
    return top


def file_manifest(root: Path) -> dict[str, dict]:
    entries: dict[str, dict] = {}
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames.sort()
        # os.walk puts a symlink to a directory in dirnames.  It must be
        # recorded, but not followed: following it would duplicate the target
        # tree and could leave the root.
        for name in list(dirnames):
            path = Path(dirpath) / name
            if path.is_symlink():
                rel = path.relative_to(root).as_posix()
                target = os.readlink(path)
                resolved = (path.parent / target).resolve()
                if not (str(resolved) == str(root.resolve()) or str(resolved).startswith(str(root.resolve()) + os.sep)):
                    raise RuntimeError(f"assembled symlink escapes tree: {rel} -> {target}")
                entries[rel] = {"type": "symlink", "target": target}
                dirnames.remove(name)
        for name in sorted(filenames):
            path = Path(dirpath) / name
            rel = path.relative_to(root).as_posix()
            if path.is_symlink():
                target = os.readlink(path)
                resolved = (path.parent / target).resolve()
                if not str(resolved).startswith(str(root.resolve()) + os.sep):
                    raise RuntimeError(f"assembled symlink escapes tree: {rel} -> {target}")
                entries[rel] = {"type": "symlink", "target": target}
            elif path.is_file():
                entries[rel] = {
                    "type": "file",
                    "bytes": path.stat().st_size,
                    "sha256": sha256_file(path),
                }
            else:
                raise RuntimeError(f"unsupported file type in assembled tree: {rel}")
    return entries


def tree_digest(entries: dict[str, dict]) -> str:
    h = hashlib.sha256()
    for rel in sorted(entries):
        entry = entries[rel]
        h.update(rel.encode("utf-8"))
        h.update(b"\0")
        if entry["type"] == "file":
            h.update(b"f\0" + entry["sha256"].encode("ascii"))
        else:
            h.update(b"l\0" + entry["target"].encode("utf-8"))
        h.update(b"\n")
    return h.hexdigest()


def load_archives(depot: Path) -> dict:
    path = depot / "ARCHIVES.json"
    if not path.exists():
        raise SystemExit(f"missing {path}; run fetch_sources.py first")
    payload = json.loads(path.read_text())
    if not payload.get("complete"):
        raise SystemExit("ARCHIVES.json is marked incomplete; refusing to assemble")
    return payload


def verify_archives(depot: Path, payload: dict) -> None:
    missing = []
    for key, record in payload["archives"].items():
        relative = record.get("relativePath")
        if not relative:
            raise SystemExit(f"archive record without relativePath: {key}")
        path = depot / relative
        if not path.exists():
            missing.append(str(path))
            continue
        actual = sha256_file(path)
        if actual != record["sha256"]:
            raise SystemExit(f"archive hash mismatch: {path}: {actual} != {record['sha256']}")
        if path.stat().st_size != record["bytes"]:
            raise SystemExit(f"archive size mismatch: {path}")
    if missing:
        raise SystemExit("missing archives:\n" + "\n".join(missing))
    print(f"archives verified: {len(payload['archives'])}")


def check_tree(tree: Path, manifest_path: Path) -> int:
    manifest = json.loads(manifest_path.read_text())
    expected = manifest["files"]
    actual = file_manifest(tree)
    problems: list[str] = []
    for rel in sorted(set(expected) | set(actual)):
        if rel not in actual:
            problems.append(f"missing: {rel}")
            continue
        if rel not in expected:
            problems.append(f"unexpected: {rel}")
            continue
        if expected[rel] != actual[rel]:
            problems.append(f"changed: {rel}")
    if problems:
        print(f"FAIL: source tree does not match manifest ({len(problems)} differences)")
        for problem in problems[:200]:
            print(" -", problem)
        return 1
    digest = tree_digest(actual)
    if digest != manifest["treeSHA256"]:
        print(f"FAIL: tree digest {digest} != {manifest['treeSHA256']}")
        return 1
    print(f"OK: {manifest['fileCount']} entries, tree SHA-256 {digest}")
    return 0


def assemble(depot: Path, tree: Path, payload: dict) -> int:
    verify_archives(depot, payload)
    parent = tree.parent
    parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=".assemble-", dir=parent))
    try:
        main_record = payload["archives"]["upstream"]
        main_archive = depot / main_record["relativePath"]
        top = safe_extract(main_archive, staging)
        print(f"main source: {top}")

        for key, record in sorted(payload["archives"].items()):
            if record["kind"] != "submodule":
                continue
            dest = staging / record["path"]
            if dest.exists() or dest.is_symlink():
                if dest.is_dir() and not dest.is_symlink():
                    shutil.rmtree(dest)
                else:
                    dest.unlink()
            dest.mkdir(parents=True, exist_ok=True)
            safe_extract(depot / record["relativePath"], dest)
            print(f"submodule: {record['path']} @ {record['commit']}")

        # The source archive leaves gitlink directories empty.  Every one of
        # them must now contain real source; an empty overlay is a failed
        # assembly, not a usable tree.
        for record in payload["archives"].values():
            if record["kind"] != "submodule":
                continue
            dest = staging / record["path"]
            if not dest.is_dir() or not any(dest.iterdir()):
                raise SystemExit(f"submodule path is empty after assembly: {record['path']}")

        for required in REQUIRED_PATHS:
            path = staging / required
            if not path.is_file():
                raise SystemExit(f"required Web-build input missing: {required}")

        entries = file_manifest(staging)
        manifest = {
            "format": "floe-tic80-source-tree",
            "version": 1,
            "upstream": payload["upstream"],
            "toolchain": payload.get("toolchain", {}),
            "root": tree.name,
            "fileCount": len(entries),
            "totalBytes": sum(e.get("bytes", 0) for e in entries.values()),
            "treeSHA256": tree_digest(entries),
            "files": entries,
        }
        manifest_path = tree.parent / "SOURCE-MANIFEST.json"
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")

        if tree.exists():
            shutil.rmtree(tree)
        os.replace(staging, tree)
        staging = None
        print(f"assembled {tree}")
        print(f"entries: {manifest['fileCount']}, bytes: {manifest['totalBytes']}")
        print(f"tree SHA-256: {manifest['treeSHA256']}")
        print(f"manifest: {manifest_path}")
        return 0
    finally:
        if staging is not None and staging.exists():
            shutil.rmtree(staging, ignore_errors=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--depot", type=Path, default=DEFAULT_DEPOT)
    parser.add_argument("--tree", type=Path, default=DEFAULT_TREE)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--assemble", action="store_true")
    group.add_argument("--check", action="store_true")
    group.add_argument("--verify-archives", action="store_true")
    args = parser.parse_args()

    payload = load_archives(args.depot)
    if args.verify_archives:
        verify_archives(args.depot, payload)
        return 0
    manifest_path = args.tree.parent / "SOURCE-MANIFEST.json"
    if args.check:
        if not args.tree.exists() or not manifest_path.exists():
            print(f"FAIL: assembled tree or manifest missing: {args.tree}")
            return 2
        return check_tree(args.tree, manifest_path)
    return assemble(args.depot, args.tree, payload)


if __name__ == "__main__":
    raise SystemExit(main())
