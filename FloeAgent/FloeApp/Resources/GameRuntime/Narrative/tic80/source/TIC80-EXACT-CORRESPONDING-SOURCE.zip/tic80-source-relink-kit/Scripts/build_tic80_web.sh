#!/usr/bin/env bash
# SPDX-License-Identifier: MPL-2.0
#
# Rebuild the TIC-80 1.4.1 universal Web player from the exact assembled source.
# This script is the native stage and MUST NOT be run while NATIVE-HOLD.json is
# active.  It never downloads source: the depot must already be prepared and
# source-verified.  A compiler/version mismatch fails closed unless the caller
# explicitly records the mismatch with --allow-toolchain-mismatch.
#
# Usage:
#   build_tic80_web.sh --variant baseline|relink [--jobs 6] [--check-only]
#   build_tic80_web.sh --variant relink --allow-toolchain-mismatch

set -euo pipefail

KIT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_ROOT="$(cd "$KIT_ROOT/../../../.." && pwd)"
if [[ -d "$KIT_ROOT/Resources" ]]; then DEFAULT_RESOURCES="$KIT_ROOT/Resources";
else DEFAULT_RESOURCES="$REPO_ROOT/Local/Artifacts/game-predevelopment-expanded/tic80-mpl-closure"; fi
export TIC80_RESOURCE_ROOT="${TIC80_RESOURCE_ROOT:-$DEFAULT_RESOURCES}"
TREE="${TIC80_SOURCE_TREE:-${TIC80_RESOURCE_ROOT}/source-tree/tic80-1.4.1}"
BUILD_ROOT="${TIC80_ARTIFACT_ROOT:-${TIC80_RESOURCE_ROOT}/build}"
# Regenerable native scratch belongs on the internal SSD.  Only packages and
# receipts are exported to the artifact scope.
SCRATCH_ROOT="${TIC80_SCRATCH_ROOT:-${HOME}/Library/Caches/CodexBuild/Floe/0dd039b5b74b/xcode27.2/game-tic80-mpl}"
VARIANT="baseline"
JOBS=6
CHECK_ONLY=0
ALLOW_MISMATCH=0
FRESH=0
EXPECTED_EMSDK="6.0.13"
EXPECTED_CMAKE="4.3.4"
EXPECTED_NINJA="1.13.2"
EXPECTED_RUBY="2.6.10"
EXPECTED_RAKE="12.3.3"

usage() {
    sed -n '2,20p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
}

while (($#)); do
    case "$1" in
        --variant) VARIANT="${2:?}"; shift 2 ;;
        --jobs) JOBS="${2:?}"; shift 2 ;;
        --check-only) CHECK_ONLY=1; shift ;;
        --allow-toolchain-mismatch) ALLOW_MISMATCH=1; shift ;;
        --fresh) FRESH=1; shift ;;
        -h|--help) usage; exit 0 ;;
        *) echo "unknown argument: $1" >&2; exit 2 ;;
    esac
done

case "$VARIANT" in
    baseline|relink) ;;
    *) echo "variant must be baseline or relink: $VARIANT" >&2; exit 2 ;;
esac
[[ "$JOBS" =~ ^[1-9][0-9]*$ ]] || { echo "jobs must be a positive integer" >&2; exit 2; }
[[ "$JOBS" -le 6 ]] || { echo "jobs above 6 is outside the documented memory envelope" >&2; exit 2; }

fail() { echo "FAIL: $*" >&2; exit 1; }
note() { echo "==> $*"; }
if [[ "$CHECK_ONLY" != 1 && -f "$KIT_ROOT/../NATIVE-HOLD.json" ]]; then
    fail "Main native HOLD is active; no build started"
fi

note "TIC-80 Web source/rebuild kit"
note "variant: $VARIANT"
[[ -f "$TREE/CMakeLists.txt" ]] || fail "assembled source tree missing: $TREE"
[[ -f "$TREE/../SOURCE-MANIFEST.json" ]] || fail "source manifest missing"

# Source tree and depot are checked before any toolchain is touched.
python3 "$KIT_ROOT/Scripts/assemble_source.py" --check >/dev/null
python3 "$KIT_ROOT/Scripts/assemble_source.py" --verify-archives >/dev/null
note "source tree + archives verified"

BUILD_TREE="$SCRATCH_ROOT/work/$VARIANT/tic80-src"
if [[ ! -f "$SCRATCH_ROOT/work/$VARIANT/BUILD-TREE.json" || "$FRESH" == 1 ]]; then
    python3 "$KIT_ROOT/Scripts/prepare_build_tree.py" --variant "$VARIANT" --work-root "$SCRATCH_ROOT/work" --force
fi
[[ -d "$BUILD_TREE" ]] || fail "build tree missing: $BUILD_TREE"
if git -C "$BUILD_TREE" rev-parse --show-toplevel >/dev/null 2>&1; then
    fail "build tree is inside a Git work tree ($(git -C "$BUILD_TREE" rev-parse --show-toplevel)); use the internal CodexBuild scratch"
fi

for tool in cmake ninja ruby rake python3; do
    command -v "$tool" >/dev/null 2>&1 || fail "missing required tool: $tool"
done
if ! command -v emcc >/dev/null 2>&1; then
    if [[ "$CHECK_ONLY" == 1 ]]; then
        echo "Precondition result: source/build tree ready; emcc not on PATH (emsdk $EXPECTED_EMSDK not active)." >&2
        exit 3
    fi
    fail "emcc not on PATH; activate the pinned emsdk $EXPECTED_EMSDK (see TOOLCHAIN.json)"
fi
command -v emcmake >/dev/null 2>&1 || fail "emcmake not on PATH"

CMAKE_VERSION="$(cmake --version | head -1 | awk '{print $3}')"
NINJA_VERSION="$(ninja --version | tr -d '[:space:]')"
RUBY_VERSION="$(ruby -e 'print RUBY_VERSION')"
RAKE_VERSION="$(rake --version | awk '{print $3}' | tr -d '[:space:]')"
TOOLCHAIN_MISMATCH=""

check_exact() {
    local name="$1" expected="$2" actual="$3"
    if [[ "$actual" != "$expected" ]]; then
        if [[ "$ALLOW_MISMATCH" == 1 ]]; then
            TOOLCHAIN_MISMATCH+="${name}: expected ${expected}, got ${actual}; "
            echo "WARN: $name version mismatch ($actual != $expected); continuing because --allow-toolchain-mismatch was given" >&2
        else
            fail "$name version mismatch: expected $expected, got $actual (use --allow-toolchain-mismatch only for a recorded environment exception)"
        fi
    fi
}

check_exact cmake "$EXPECTED_CMAKE" "$CMAKE_VERSION"
check_exact ninja "$EXPECTED_NINJA" "$NINJA_VERSION"
check_exact ruby "$EXPECTED_RUBY" "$RUBY_VERSION"
check_exact rake "$EXPECTED_RAKE" "$RAKE_VERSION"

if [[ "$CHECK_ONLY" == 1 ]]; then
    echo "Precondition result: ready (toolchain checks skipped guard-by-guard; no build executed)."
    exit 0
fi

EMCC_VERSION="$(emcc --version | head -1 | sed -E 's/.* ([0-9]+\.[0-9]+\.[0-9]+).*/\1/')"
[[ "$EMCC_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || fail "could not parse emcc version"
check_exact emcc "$EXPECTED_EMSDK" "$EMCC_VERSION"
note "toolchain: emcc $EMCC_VERSION, cmake $CMAKE_VERSION, ninja $NINJA_VERSION, ruby $RUBY_VERSION, rake $RAKE_VERSION"

CMAKE_BUILD="$SCRATCH_ROOT/cmake/$VARIANT"
OUT_DIR="$BUILD_ROOT/out/$VARIANT"
if [[ "$FRESH" == 1 && -d "$CMAKE_BUILD" ]]; then
    mv "$CMAKE_BUILD" "${CMAKE_BUILD}.previous-$(date -u +%Y%m%dT%H%M%SZ)-$$"
fi
mkdir -p "$CMAKE_BUILD"

CMAKE_ARGS=(
    -S "$BUILD_TREE"
    -B "$CMAKE_BUILD"
    -G Ninja
    -DCMAKE_BUILD_TYPE=Release
    -DBUILD_WITH_ALL=ON
    -DBUILD_TOUCH_INPUT=ON
    -DBUILD_EDITORS=ON
    -DBUILD_SURF=ON
    -DBUILD_STATIC=ON
    -DBUILD_WITH_ZLIB=ON
    -DBUILD_SDL=OFF
    -DBUILD_SOKOL=ON
    -DBUILD_SDLGPU=OFF
    -DBUILD_TOOLS=OFF
    -DBUILD_PRO=OFF
    -DBUILD_WITH_FORTH=OFF
    -DBUILD_PLAYER=OFF
    -DBUILD_LIBRETRO=OFF
    -DPREFER_SYSTEM_LIBRARIES=OFF
    -DPREFER_SYSTEM_SDL2=OFF
    -DCMAKE_POLICY_VERSION_MINIMUM=3.5
    -DTIC80_TARGET=tic80
)

note "configuring with emcmake"
emcmake cmake "${CMAKE_ARGS[@]}"
note "building with $JOBS jobs"
cmake --build "$CMAKE_BUILD" --parallel "$JOBS"

for artifact in "$CMAKE_BUILD/bin/tic80.js" "$CMAKE_BUILD/bin/tic80.wasm"; do
    [[ -f "$artifact" ]] || fail "expected artifact missing: $artifact"
done
# Preserve the exact successful link before packaging/version checks. A later
# failure must retain usable raw binaries and the source/build-tree receipt.
RAW_DIR="$BUILD_ROOT/raw/$VARIANT"
if [[ -d "$RAW_DIR" ]]; then
    mv "$RAW_DIR" "${RAW_DIR}.previous-$(date -u +%Y%m%dT%H%M%SZ)-$$"
fi
mkdir -p "$RAW_DIR"
cp "$CMAKE_BUILD/bin/tic80.js" "$CMAKE_BUILD/bin/tic80.wasm" "$RAW_DIR/"
cp "$SCRATCH_ROOT/work/$VARIANT/BUILD-TREE.json" "$RAW_DIR/BUILD-TREE.json"
python3 - "$RAW_DIR" <<'PY'
from pathlib import Path
import hashlib, json, sys
root = Path(sys.argv[1])
files = {p.name: {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
         for p in root.iterdir() if p.is_file()}
(root / 'RAW-PRODUCTS.json').write_text(json.dumps({'linked': True, 'packagingVerified': False, 'files': files}, indent=2) + '\n')
PY
cp "$BUILD_TREE/build/html/index.html" "$CMAKE_BUILD/bin/index.html"

note "packaging runtime and notices"
if [[ -d "$OUT_DIR" ]]; then
    mv "$OUT_DIR" "${OUT_DIR}.previous-$(date -u +%Y%m%dT%H%M%SZ)-$$"
fi
python3 "$KIT_ROOT/Scripts/package_runtime.py" \
    --build-dir "$CMAKE_BUILD" \
    --tree "$BUILD_TREE" \
    --kit-root "$KIT_ROOT" \
    --variant "$VARIANT" \
    --out "$OUT_DIR"

python3 - "$CMAKE_BUILD" "$OUT_DIR" "$VARIANT" "$EMCC_VERSION" "$CMAKE_VERSION" "$NINJA_VERSION" "$RUBY_VERSION" "$RAKE_VERSION" "$TOOLCHAIN_MISMATCH" <<'PY'
import hashlib, json, sys
from pathlib import Path
build, out, variant, emcc, cmake, ninja, ruby, rake, mismatch = sys.argv[1:]
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()
build = Path(build); out = Path(out)
record = {
    'format': 'floe-tic80-web-build-receipt',
    'version': 1,
    'variant': variant,
    'toolchain': {'emcc': emcc, 'cmake': cmake, 'ninja': ninja, 'ruby': ruby, 'rake': rake},
    'toolchainMismatch': mismatch or None,
    'artifacts': {
        'tic80.js': {'bytes': (build/'bin/tic80.js').stat().st_size, 'sha256': sha(build/'bin/tic80.js')},
        'tic80.wasm': {'bytes': (build/'bin/tic80.wasm').stat().st_size, 'sha256': sha(build/'bin/tic80.wasm')},
    },
    'package': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(out.rglob('*')) if p.is_file()},
}
(out / 'BUILD-RECEIPT.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record['artifacts'], indent=2))
PY

note "build + package complete: $OUT_DIR"
