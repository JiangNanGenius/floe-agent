#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Build the Web-build link/dependency and license indexes.

Everything here is derived from the assembled exact source tree.  The output
is deliberately explicit about what is linked into the universal Web player and
what is present in the source archive but not selected by the Emscripten build.
It does not give a legal opinion and it does not turn an upstream notice into a
blanket clearance.

Outputs (under --out):
  WEB-BUILD-LINK-MAP.json
  LICENSE-INDEX.json
  EMBEDDED-ASSET-REVIEW.json
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DEFAULT_TREE = Path(
    "/Volumes/TECLAST-512/IOS AI AGENT/Local/Artifacts/"
    "game-predevelopment-expanded/tic80-mpl-closure/source-tree/tic80-1.4.1"
)
DEFAULT_OUT = ROOT / "manifests"

# linked: True = compiled/linked into the universal Emscripten player under the
# exact flags; False = present in the source archive but not selected.
COMPONENTS = [
    {
        "id": "tic80",
        "name": "TIC-80 engine",
        "path": ".",
        "version": "1.4.1 (b3dbd59)",
        "license": "MIT",
        "licenseFiles": ["LICENSE"],
        "linked": True,
        "targets": ["tic80core", "tic80studio", "tic80"],
        "evidence": ["CMakeLists.txt", "cmake/core.cmake", "cmake/studio.cmake", "cmake/sokol.cmake"],
        "notes": "Top-level TIC-80 code; the tag archive's LICENSE is MIT. The engine also contains per-file third-party notices listed separately.",
    },
    {
        "id": "blip-buf",
        "name": "blip_buf",
        "path": "vendor/blip-buf",
        "version": "330226d9b55ecbeea644e17b5e0f096a165ca07e",
        "license": "LGPL-2.1-or-later",
        "licenseFiles": ["vendor/blip-buf/license.txt", "vendor/blip-buf/blip_buf.txt"],
        "linked": True,
        "targets": ["blipbuf", "tic80core"],
        "evidence": ["cmake/blipbuf.cmake", "cmake/core.cmake", "src/core/sound.c"],
        "notes": "The one LGPL library linked into the Web engine. CMake links the static blipbuf target into tic80core; src/core/sound.c calls blip_new/blip_add_delta/blip_end_frame/blip_read_samples. The relink route in this kit replaces this source and rebuilds the full Web program.",
    },
    {
        "id": "lua",
        "name": "Lua",
        "path": "vendor/lua",
        "version": "75ea9ccbea7c4886f30da147fb67b693b2624c26",
        "license": "MIT",
        "licenseFiles": ["LICENSES/MIT.txt"],
        "linked": True,
        "targets": ["luaapi", "lua"],
        "evidence": ["cmake/lua.cmake", "src/api/luaapi.c"],
        "notes": "No LICENSE file in the lua submodule; the MIT grant is in the upstream file headers and the TIC-80 LICENSES/MIT.txt is the bundled text. Copyright (C) 1994-2025 Lua.org, PUC-Rio.",
    },
    {
        "id": "lpeg",
        "name": "LPeg",
        "path": "vendor/lpeg",
        "version": "80ec9f932aa01d445e86c699523265359055e1bd",
        "license": "MIT",
        "licenseFiles": ["LICENSES/MIT.txt"],
        "linked": True,
        "targets": ["lpeg", "moon"],
        "evidence": ["cmake/moon.cmake", "src/api/moonscript.c"],
        "notes": "No LICENSE file in the LPeg submodule; upstream headers carry the MIT grant. Copyright (c) 2007-2023 Lua.org, PUC-Rio.",
    },
    {
        "id": "moonscript",
        "name": "MoonScript",
        "path": "vendor/moonscript",
        "version": "17179283012b392bff972ad66231d73bfeec6e90",
        "license": "MIT",
        "licenseFiles": ["vendor/moonscript/LICENSE"],
        "linked": True,
        "targets": ["moon"],
        "evidence": ["cmake/moon.cmake"],
        "notes": "Compiled into the Lua-derived MoonScript runtime.",
    },
    {
        "id": "yuescript",
        "name": "YueScript",
        "path": "vendor/yuescript",
        "version": "4e3770ec50faf0b38c9bb4639191e4079df17155",
        "license": "MIT",
        "licenseFiles": ["vendor/yuescript/LICENSE"],
        "linked": True,
        "targets": ["yuescript"],
        "evidence": ["cmake/yue.cmake"],
        "notes": "Compiled into the YueScript runtime.",
    },
    {
        "id": "fennel",
        "name": "Fennel",
        "path": "vendor/fennel",
        "version": "vendored in TIC-80 b3dbd59 (not a gitlink)",
        "license": "MIT",
        "licenseFiles": ["LICENSES/MIT.txt"],
        "linked": True,
        "targets": ["fennel"],
        "evidence": ["cmake/fennel.cmake"],
        "notes": "Vendored fennel.lua/fennel.h; MIT text in LICENSES/MIT.txt. Copyright (c) 2016-2024 Calvin Rose and contributors.",
    },
    {
        "id": "s7",
        "name": "s7 Scheme",
        "path": "vendor/s7",
        "version": "vendored in TIC-80 b3dbd59 (not a gitlink)",
        "license": "0BSD",
        "licenseFiles": ["LICENSES/0BSD.txt"],
        "linked": True,
        "targets": ["scheme"],
        "evidence": ["cmake/scheme.cmake"],
        "notes": "Vendored s7.c/s7.h; 0BSD text bundled by TIC-80. Copyright (c) Bill Schottstaedt.",
    },
    {
        "id": "squirrel",
        "name": "Squirrel",
        "path": "vendor/squirrel",
        "version": "c02bf2dfd599a0b99b814d486512a3ee934667f1",
        "license": "MIT",
        "licenseFiles": ["vendor/squirrel/COPYRIGHT"],
        "linked": True,
        "targets": ["squirrel"],
        "evidence": ["cmake/squirrel.cmake"],
        "notes": "Compiled into the Squirrel runtime.",
    },
    {
        "id": "wren",
        "name": "Wren",
        "path": "vendor/wren",
        "version": "4a18fc489f9ea3d253b20dd40f4cdad0d6bb40eb",
        "license": "MIT",
        "licenseFiles": ["vendor/wren/LICENSE"],
        "linked": True,
        "targets": ["wren"],
        "evidence": ["cmake/wren.cmake"],
        "notes": "Compiled into the Wren runtime.",
    },
    {
        "id": "mruby",
        "name": "mruby",
        "path": "vendor/mruby",
        "version": "831da26b9021de0369d17b71b5667e2941a1a32d",
        "license": "MIT",
        "licenseFiles": ["vendor/mruby/LICENSE"],
        "linked": True,
        "targets": ["ruby", "mruby_vendor"],
        "evidence": ["cmake/mruby.cmake", "build/mruby/tic_default.rb", "build/mruby/tic.gembox"],
        "notes": "Built by rake into libmruby.a and linked into the Ruby runtime. The build uses the vendored gems in build/mruby/tic.gembox; no network gem install is part of the recipe.",
    },
    {
        "id": "quickjs-ng",
        "name": "QuickJS-ng",
        "path": "vendor/quickjs",
        "version": "6d46d07d04041b40f4f49eaa7fdebe44c314c699",
        "license": "MIT",
        "licenseFiles": ["vendor/quickjs/LICENSE"],
        "linked": True,
        "targets": ["quickjs", "js"],
        "evidence": ["cmake/quickjs.cmake"],
        "notes": "Compiled into the JS runtime. The upstream test262 gitlink is excluded from the depot: it is a test corpus, update=none, and is not linked.",
    },
    {
        "id": "pocketpy",
        "name": "pocketpy",
        "path": "vendor/pocketpy",
        "version": "979addecf9cb180c59c16ac605ba75441ece5af6",
        "license": "MIT",
        "licenseFiles": ["vendor/pocketpy/LICENSE"],
        "linked": True,
        "targets": ["pocketpy", "python"],
        "evidence": ["cmake/pocketpy.cmake"],
        "notes": "Compiled into the Python runtime. Nested pocketpy submodules (dmath, lz4, c-periphery) are present in the source depot for completeness but their features are OFF in this build.",
    },
    {
        "id": "wasm3",
        "name": "wasm3",
        "path": "vendor/wasm3",
        "version": "139076a98b8321b67f850a844f558b5e91b5ac83",
        "license": "MIT",
        "licenseFiles": ["vendor/wasm3/LICENSE"],
        "linked": True,
        "targets": ["wasm"],
        "evidence": ["cmake/wasm.cmake"],
        "notes": "Compiled into the WASM runtime.",
    },
    {
        "id": "janet",
        "name": "Janet",
        "path": "vendor/janet",
        "version": "e1963cdfe0148f83601907727e00bd672d798115",
        "license": "MIT",
        "licenseFiles": ["vendor/janet/LICENSE"],
        "linked": True,
        "targets": ["janet"],
        "evidence": ["cmake/janet.cmake"],
        "notes": "The build generates build/c/janet.c with the vendored amalgamation script; the generated file is a build output, not a separately licensed component.",
    },
    {
        "id": "gravity",
        "name": "Gravity",
        "path": "vendor/gravity",
        "version": "07ebb9730761ee89a2b19873f5f6bf205574535c",
        "license": "MIT",
        "licenseFiles": ["vendor/gravity/LICENSE"],
        "linked": True,
        "targets": ["gravity"],
        "evidence": ["cmake/gravity.cmake"],
        "notes": "Compiled into the Gravity runtime.",
    },
    {
        "id": "miniscript2",
        "name": "MiniScript 2",
        "path": "vendor/miniscript2",
        "version": "a5a546a9960430aab31eb713f65bfe4a46b37c05",
        "license": "MIT",
        "licenseFiles": ["vendor/miniscript2/LICENSE"],
        "linked": True,
        "targets": ["libminiscript", "miniscript"],
        "evidence": ["cmake/miniscript.cmake", "vendor/miniscript2_extras/keyboard.cpp"],
        "notes": "Compiled into the MiniScript runtime. vendor/miniscript2_extras/keyboard.cpp has no separate license file; it is the TIC-80 host's dummy keyboard adapter for the MiniScript2 demo host and is treated as part of the MiniScript2 source distribution. Do not infer a broader grant for the embedded demo cartridges.",
    },
    {
        "id": "libpng",
        "name": "libpng",
        "path": "vendor/libpng",
        "version": "ed217e3e601d8e462f7fd1e04bed43ac42212429",
        "license": "libpng-2.0",
        "licenseFiles": ["vendor/libpng/LICENSE", "LICENSES/libpng-2.0.txt"],
        "linked": True,
        "targets": ["png", "tic80core"],
        "evidence": ["cmake/png.cmake"],
        "notes": "Compiled into the core PNG code.",
    },
    {
        "id": "zlib",
        "name": "zlib",
        "path": "vendor/zlib",
        "version": "51b7f2abdade71cd9bb0e7a373ef2610ec6f9daf",
        "license": "Zlib",
        "licenseFiles": ["vendor/zlib/LICENSE", "LICENSES/Zlib.txt"],
        "linked": True,
        "targets": ["zlib", "tic80core"],
        "evidence": ["cmake/zlib.cmake"],
        "notes": "Compiled into the core.",
    },
    {
        "id": "giflib",
        "name": "giflib",
        "path": "vendor/giflib",
        "version": "1aa11b06d0025eda77b56aec8254130654d4397b",
        "license": "MIT",
        "licenseFiles": ["vendor/giflib/COPYING", "LICENSES/MIT.txt"],
        "linked": True,
        "targets": ["giflib", "tic80core"],
        "evidence": ["cmake/gif.cmake", "cmake/core.cmake"],
        "notes": "Compiled into the core GIF support.",
    },
    {
        "id": "zip",
        "name": "kuba--/zip (miniz)",
        "path": "vendor/zip",
        "version": "296ff2421b6bdb82575dd943fb8b5d7d5d443903",
        "license": "MIT",
        "licenseFiles": ["vendor/zip/LICENSE.txt", "LICENSES/MIT.txt"],
        "linked": True,
        "targets": ["zip", "tic80studio"],
        "evidence": ["cmake/zip.cmake", "cmake/studio.cmake"],
        "notes": "Compiled into the studio/core ZIP path.",
    },
    {
        "id": "jsmn",
        "name": "jsmn",
        "path": "vendor/jsmn",
        "version": "25647e692c7906b96ffd2b05ca54c097948e879c",
        "license": "MIT",
        "licenseFiles": ["vendor/jsmn/LICENSE", "LICENSES/MIT.txt"],
        "linked": True,
        "targets": ["tic80studio"],
        "evidence": ["cmake/studio.cmake", "src/ext/json.c"],
        "notes": "Header-only JSON parser included by src/ext/json.c.",
    },
    {
        "id": "argparse",
        "name": "argparse",
        "path": "vendor/argparse",
        "version": "0d5f5d0745df14a3f373f7eed85bf524714f4524",
        "license": "MIT",
        "licenseFiles": ["vendor/argparse/LICENSE", "LICENSES/MIT.txt"],
        "linked": True,
        "targets": ["argparse", "tic80studio"],
        "evidence": ["cmake/argparse.cmake", "cmake/studio.cmake", "src/studio/studio.c"],
        "notes": "Compiled into the studio CLI option parser.",
    },
    {
        "id": "sokol",
        "name": "sokol",
        "path": "vendor/sokol",
        "version": "2e75443dbd4940b5aa8d76a8e479f8e4b270b9a3",
        "license": "Zlib",
        "licenseFiles": ["vendor/sokol/LICENSE"],
        "linked": True,
        "targets": ["sokol", "tic80"],
        "evidence": ["cmake/sokol.cmake", "src/system/sokol/sokol_impl.c"],
        "notes": "The Web system layer; SOKOL_GLES3 and the Sokol app/audio/WebGL2 backends.",
    },
    {
        "id": "clay",
        "name": "Clay",
        "path": "vendor/clay",
        "version": "e6cc36941ab2af5d81107617039d6f527a1c660b",
        "license": "Zlib",
        "licenseFiles": ["vendor/clay/LICENSE.md"],
        "linked": True,
        "targets": ["tic80"],
        "evidence": ["cmake/sokol.cmake", "src/system/sokol/controls.c"],
        "notes": "Header-only layout library compiled into the touch-controls translation unit (BUILD_TOUCH_INPUT=ON).",
    },
    {
        "id": "kiss-fft",
        "name": "KISS FFT",
        "path": "src/ext",
        "version": "in TIC-80 b3dbd59",
        "license": "BSD-3-Clause",
        "licenseFiles": ["LICENSES/BSD-3-Clause.txt"],
        "linked": True,
        "targets": ["tic80core"],
        "evidence": ["cmake/core.cmake", "src/ext/kiss_fft.c", "src/ext/kiss_fftr.c"],
        "notes": "Compiled into the core FFT/VQT path. Copyright (c) 2003-2010 Mark Borgerding.",
    },
    {
        "id": "msf-gif",
        "name": "msf_gif",
        "path": "src/ext/msf_gif.h",
        "version": "in TIC-80 b3dbd59",
        "license": "MIT OR Unlicense",
        "licenseFiles": ["LICENSES/MIT.txt", "LICENSES/Unlicense.txt"],
        "linked": True,
        "targets": ["tic80studio"],
        "evidence": ["src/studio/studio.c", "src/ext/msf_gif.h"],
        "notes": "Single-header GIF encoder compiled into the studio. Copyright (c) 2025 Miles Fogle.",
    },
    {
        "id": "retroarch-headers",
        "name": "RetroArch common headers",
        "path": "include",
        "version": "in TIC-80 b3dbd59",
        "license": "MIT",
        "licenseFiles": ["LICENSES/MIT.txt"],
        "linked": True,
        "targets": ["tic80core", "tic80studio"],
        "evidence": ["include/retro_inline.h", "include/retro_endianness.h", "include/tic80.h"],
        "notes": "Header-only MIT code included by core/studio public headers.",
    },
    {
        "id": "emscripten",
        "name": "Emscripten generated JS runtime",
        "path": "(toolchain runtime, not in source tree)",
        "version": "6.0.13",
        "license": "MIT OR NCSA",
        "licenseFiles": ["notices/EMSCRIPTEN-LICENSE.txt"],
        "linked": True,
        "targets": ["tic80.js"],
        "evidence": ["build/tic80.js", "cmake/sokol.cmake link flags"],
        "notes": "Generated loader code is part of tic80.js. Toolchain is not distributed as source in this kit; license text is included. The original binary's compiler version is not known; 6.0.13 is the pinned clean-rebuild toolchain.",
    },
    # Not linked in this Web configuration.
    {
        "id": "circle",
        "name": "Circle / baremetal Pi",
        "path": "src/system/baremetalpi",
        "version": "in TIC-80 b3dbd59",
        "license": "GPL-3.0-or-later",
        "licenseFiles": ["LICENSES/GPL-3.0-or-later.txt"],
        "linked": False,
        "targets": [],
        "evidence": ["src/system/baremetalpi/", "CMakeLists.txt (BAREMETALPI platform)"],
        "notes": "GPL text is present for the baremetal Pi platform only. The Web/Emscripten build never compiles src/system/baremetalpi; do not describe this GPL text as linked into the Web runtime.",
    },
    {
        "id": "pforth",
        "name": "pForth",
        "path": "vendor/pforth",
        "version": "3e637b5ac6ad665f851f31e33ad4c44caf4e25ab",
        "license": "0BSD-like permissive (see license.txt)",
        "licenseFiles": ["vendor/pforth/license.txt"],
        "linked": False,
        "targets": [],
        "evidence": ["cmake/forth.cmake"],
        "notes": "BUILD_WITH_FORTH is OFF even with BUILD_WITH_ALL=ON (the source marks it unsafe because pForth has no memory sandbox). Present in the depot for completeness; not compiled into the Web player.",
    },
    {
        "id": "sdl2",
        "name": "SDL2",
        "path": "vendor/sdl2",
        "version": "5d249570393f7a37e037abf22cd6012a4cc56a71",
        "license": "Zlib",
        "licenseFiles": ["vendor/sdl2/LICENSE.txt"],
        "linked": False,
        "targets": [],
        "evidence": ["CMakeLists.txt (BUILD_SOKOL default for Emscripten)", "cmake/sdl.cmake"],
        "notes": "The Web build selects Sokol; the vendor SDL2 tree is not added by the Web configuration. Emscripten's SDL2 port is not used because BUILD_SDL is off.",
    },
    {
        "id": "sdl-gpu",
        "name": "SDL_gpu",
        "path": "vendor/sdl-gpu",
        "version": "592a512994c6a90dde9f94820e76e95e599012da",
        "license": "MIT",
        "licenseFiles": ["vendor/sdl-gpu/LICENSE.txt"],
        "linked": False,
        "targets": [],
        "evidence": ["CMakeLists.txt (BUILD_SDLGPU=OFF)"],
        "notes": "BUILD_SDLGPU is OFF; the source is retained only because the upstream archive pins it.",
    },
    {
        "id": "naett",
        "name": "naett",
        "path": "vendor/naett",
        "version": "5f695cfa9fcbf30668a4d3ac4b4abf1cd89a1302",
        "license": "MIT",
        "licenseFiles": ["vendor/naett/LICENSE"],
        "linked": False,
        "targets": [],
        "evidence": ["cmake/naett.cmake (EMSCRIPTEN forces USE_NAETT FALSE)"],
        "notes": "Explicitly disabled for Emscripten.",
    },
    {
        "id": "dirent",
        "name": "dirent",
        "path": "vendor/dirent",
        "version": "c885633e126a3a949ec0497273ec13e2c03e862c",
        "license": "MIT",
        "licenseFiles": ["vendor/dirent/LICENSE"],
        "linked": False,
        "targets": [],
        "evidence": ["cmake/core.cmake (WIN32 only)"],
        "notes": "Windows-only helper; not part of the Web build.",
    },
    {
        "id": "dlfcn",
        "name": "dlfcn-win32",
        "path": "vendor/dlfcn",
        "version": "048bff80f2bd00bb651bcc3357cb6f76e3d76fd5",
        "license": "MIT",
        "licenseFiles": ["vendor/dlfcn/COPYING"],
        "linked": False,
        "targets": [],
        "evidence": ["cmake/core.cmake (WIN32 only)"],
        "notes": "Windows-only helper; not part of the Web build.",
    },
    {
        "id": "miniaudio",
        "name": "miniaudio",
        "path": "src/ext/miniaudio.h",
        "version": "in TIC-80 b3dbd59",
        "license": "MIT-0 OR Unlicense",
        "licenseFiles": ["notices/LICENSES/miniaudio-MIT-0-or-Unlicense.txt"],
        "linked": False,
        "targets": [],
        "evidence": ["src/ext/miniaudio.h", "no include in src/system/sokol"],
        "notes": "The Sokol Web audio backend does not include miniaudio; the header remains in the source archive and the notice is preserved. Do not list it as linked without a source check.",
    },
    {
        "id": "pocketpy-nested",
        "name": "pocketpy nested submodules (dmath, lz4, c-periphery)",
        "path": "vendor/pocketpy/3rd",
        "version": "pinned in SOURCE-PINS.json",
        "license": "MIT / BSD-2-Clause (see each submodule)",
        "licenseFiles": [
            "vendor/pocketpy/3rd/dmath/dmath/LICENSE",
            "vendor/pocketpy/3rd/lz4/lz4/LICENSE",
            "vendor/pocketpy/3rd/periphery/c-periphery/LICENSE",
        ],
        "linked": False,
        "targets": [],
        "evidence": ["vendor/pocketpy/CMakeOptions.txt (all module options OFF)"],
        "notes": "Included for a complete recursive source depot; their features are OFF in the TIC-80 Web build.",
    },
    {
        "id": "quickjs-test262",
        "name": "QuickJS test262 corpus",
        "path": "vendor/quickjs/test262",
        "version": "5ef1e5723be95296f36afb0386676fed0205869c",
        "license": "test corpus licenses (not reviewed)",
        "licenseFiles": [],
        "linked": False,
        "targets": [],
        "evidence": ["vendor/quickjs/.gitmodules (update=none)"],
        "notes": "Excluded from the source depot and the build. Test-only corpus; not needed to reconstruct the runtime and not linked.",
    },
]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def license_entry(tree: Path, rel: str) -> dict:
    path = tree / rel
    if rel.startswith("notices/"):
        path = ROOT / rel
    if not path.is_file():
        raise SystemExit(f"declared license file missing: {rel}")
    return {"path": rel, "bytes": path.stat().st_size, "sha256": sha256_file(path)}


def review_embedded_assets(tree: Path) -> dict:
    api_dir = tree / "src/api"
    includes: dict[str, list[str]] = {}
    pattern = re.compile(r'#include "\.\./build/assets/([^"]+)"')
    for source in sorted(api_dir.glob("*.c")) + sorted(api_dir.glob("*.cpp")):
        text = source.read_text(errors="replace")
        for name in pattern.findall(text):
            includes.setdefault(name, []).append(source.relative_to(tree).as_posix())
    # Studio files embed config/cart images outside the per-language API files.
    for source in [tree / "src/studio/config.c", tree / "src/studio/rom.c"]:
        text = source.read_text(errors="replace")
        for name in pattern.findall(text):
            includes.setdefault(name, []).append(source.relative_to(tree).as_posix())

    by_base: dict[str, Path] = {}
    for demo in sorted((tree / "demos").glob("*")):
        if demo.is_file():
            by_base.setdefault(demo.name.split(".", 1)[0], demo)
        elif demo.is_dir():
            by_base.setdefault(demo.name, demo)

    assets = []
    for path in sorted((tree / "build/assets").glob("*")):
        if not path.is_file():
            continue
        name = path.name
        base = name.split(".", 1)[0].replace(".tic", "")
        source = by_base.get(base)
        meta: dict[str, str] = {}
        if source is not None:
            for line in source.read_text(errors="replace").splitlines()[:12]:
                match = re.match(r"\s*(?:--|#|//|;;)\s*([a-z]+):\s*(.*)", line)
                if match:
                    meta[match.group(1).lower()] = match.group(2).strip()
        declared = meta.get("license", "")
        if "MIT" in declared.upper():
            status = "self-declared MIT in the demo header"
            license_status = "explicit-mit"
        elif name in {"cart.png.dat", "config.tic.dat"}:
            status = "TIC-80 studio asset (TIC-80 MIT); not a game cartridge"
            license_status = "tic80-asset"
        elif name.startswith("forth"):
            status = "pForth demo data, not linked (BUILD_WITH_FORTH=OFF)"
            license_status = "not-linked"
        elif source is None and base.endswith("mark"):
            status = "upstream mark cartridge; no separate source file or explicit license statement in the exact tree"
            license_status = "no-explicit-license"
        elif source is None:
            status = "upstream-generated TIC-80 data asset with no source demo match or explicit license statement"
            license_status = "no-explicit-license"
        elif source.is_dir():
            status = "demo project directory; no explicit license statement found in the exact tree"
            license_status = "no-explicit-license"
        else:
            status = "community demo with no explicit license statement in the demo header"
            license_status = "no-explicit-license"
        assets.append(
            {
                "asset": f"build/assets/{name}",
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
                "sourceDemo": source.relative_to(tree).as_posix() if source else None,
                "title": meta.get("title"),
                "author": meta.get("author"),
                "declaredLicense": declared or None,
                "status": status,
                "licenseStatus": license_status,
                "embeddedBy": includes.get(name, []),
                "linkedInUniversalWebBuild": bool(includes.get(name)) and not name.startswith("forth"),
            }
        )
    return {
        "format": "floe-tic80-embedded-asset-review",
        "version": 1,
        "note": "This is a provenance review, not a clearance. The community and mark cartridges listed below are embedded by the upstream language APIs but do not carry an explicit license grant in the exact v1.4.1 tree. They are original upstream data, not Floe-created and not relicensed. Root must decide whether to keep them, replace them, or use a no-community-demo build for a distributable resource.",
        "embeddedCount": sum(1 for a in assets if a["linkedInUniversalWebBuild"]),
        "assets": assets,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tree", type=Path, default=DEFAULT_TREE)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument(
        "--toolchain",
        type=Path,
        default=ROOT / "TOOLCHAIN.json",
        help="toolchain record used for the Emscripten license text",
    )
    args = parser.parse_args()
    tree = args.tree
    if not (tree / "CMakeLists.txt").is_file():
        raise SystemExit(f"not an assembled TIC-80 tree: {tree}")
    args.out.mkdir(parents=True, exist_ok=True)

    components = []
    license_files: dict[str, dict] = {}
    for component in COMPONENTS:
        record = dict(component)
        record["licenseEvidence"] = []
        for rel in component["licenseFiles"]:
            entry = license_entry(tree, rel)
            record["licenseEvidence"].append(entry)
            license_files[rel] = entry
        components.append(record)

    linked = [c for c in components if c["linked"]]
    not_linked = [c for c in components if not c["linked"]]
    link_map = {
        "format": "floe-tic80-web-build-link-map",
        "version": 1,
        "sourceCommit": "b3dbd597eecfe6742f64001c2fe5ba6c1afe55d9",
        "build": {
            "generator": "Ninja via emcmake",
            "configuration": "Release",
            "flags": {
                "BUILD_WITH_ALL": "ON",
                "BUILD_TOUCH_INPUT": "ON",
                "BUILD_EDITORS": "ON",
                "BUILD_SURF": "ON",
                "BUILD_STATIC": "ON",
                "BUILD_WITH_ZLIB": "ON",
                "BUILD_SDL": "OFF",
                "BUILD_SOKOL": "ON",
                "BUILD_SDLGPU": "OFF",
                "BUILD_TOOLS": "OFF",
                "BUILD_PRO": "OFF",
                "BUILD_WITH_FORTH": "OFF",
            },
            "artifact": "build/bin/tic80.js + build/bin/tic80.wasm (universal Web player)",
        },
        "components": components,
        "linkedIds": [c["id"] for c in linked],
        "notLinkedIds": [c["id"] for c in not_linked],
        "licenseSummary": {
            "lgplLinked": ["blip-buf"],
            "gplLinked": [],
            "gplPresentButNotLinked": ["circle"],
            "mitOrPermissiveLinked": [c["id"] for c in linked if "GPL" not in c["license"] and "LGPL" not in c["license"]],
        },
        "caveats": [
            "The Web build is Sokol, not SDL2; vendor/sdl2 is not compiled.",
            "BUILD_WITH_FORTH is OFF even with BUILD_WITH_ALL=ON, so pforth is not compiled.",
            "Circle's GPL-3.0-or-later files are baremetal-Pi-only and are not compiled into the Web runtime.",
            "The universal player embeds upstream demo cartridges from build/assets; see EMBEDDED-ASSET-REVIEW.json. Community demos have no explicit license grant in the exact tree.",
            "This map is a build/source inventory, not a legal opinion or an App Store clearance.",
        ],
    }
    (args.out / "WEB-BUILD-LINK-MAP.json").write_text(json.dumps(link_map, indent=2) + "\n")

    license_index = {
        "format": "floe-tic80-license-index",
        "version": 1,
        "sourceCommit": "b3dbd597eecfe6742f64001c2fe5ba6c1afe55d9",
        "licenseFiles": [license_files[k] for k in sorted(license_files)],
        "components": [
            {
                "id": c["id"],
                "name": c["name"],
                "license": c["license"],
                "linked": c["linked"],
                "licenseEvidence": c["licenseEvidence"],
                "notes": c["notes"],
            }
            for c in components
        ],
        "knownGaps": [
            "Lua and LPeg have no LICENSE file in their pinned submodules; the MIT grant is in their file headers and TIC-80's LICENSES/MIT.txt is included.",
            "Embedded community demo cartridges have no explicit license statement in the exact v1.4.1 tree.",
            "Emscripten 6.0.13 is a pinned clean-rebuild toolchain; the original shipped binary's compiler version is unknown and is not claimed.",
        ],
    }
    (args.out / "LICENSE-INDEX.json").write_text(json.dumps(license_index, indent=2) + "\n")

    assets = review_embedded_assets(tree)
    (args.out / "EMBEDDED-ASSET-REVIEW.json").write_text(json.dumps(assets, indent=2) + "\n")

    print(f"components: {len(components)} ({len(linked)} linked, {len(not_linked)} not linked)")
    print(f"license files indexed: {len(license_files)}")
    print(f"embedded assets: {len(assets['assets'])}, linked in Web: {assets['embeddedCount']}")
    print(f"written under {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
