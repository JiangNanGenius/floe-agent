#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Package rebuilt TIC-80 Web artifacts for Root comparison.

Two shapes are written:

  upstream/       tic80.js + tic80.wasm + index.html, the names the upstream
                  build and release use.
  floe-resource/  tic80.js + tic80js.wasm + index.html + cart.tic, the names
                  the current FloeGameNarrativeKit TIC-80 adapter expects.  The
                  loader's locateFile() string is rewritten from tic80.wasm to
                  tic80js.wasm and the replacement is checked exactly once.

The script never executes the runtime.  It verifies the produced bytes, the
build markers, the version banner and the loader's wasm reference, then writes
a runtime profile and a per-file manifest.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RESOURCE_ROOT = Path(os.environ.get("TIC80_RESOURCE_ROOT", str(
    ROOT / "Resources" if (ROOT / "Resources").is_dir() else
    ROOT.parents[3] / "Local/Artifacts/game-predevelopment-expanded/tic80-mpl-closure")))
DEFAULT_TREE = Path(os.environ.get("TIC80_SOURCE_TREE", str(RESOURCE_ROOT / "source-tree/tic80-1.4.1")))
MARKER = b"FLOE-BLIP-RELINK-MARKER-v1"
BASELINE_BANNER = b"1.4.1 (b3dbd59)"
RELINK_BANNER = b"1.4.1-floe-relink1 (b3dbd59)"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def add_record(records: list[dict], root: Path, path: Path, role: str) -> None:
    records.append(
        {
            "path": path.relative_to(root).as_posix(),
            "role": role,
            "bytes": path.stat().st_size,
            "sha256": sha256_file(path),
        }
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-dir", type=Path, required=True)
    parser.add_argument("--tree", type=Path, default=DEFAULT_TREE)
    parser.add_argument("--kit-root", type=Path, default=ROOT)
    parser.add_argument("--variant", choices=["baseline", "relink"], required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--fixture", type=Path, default=None)
    args = parser.parse_args()

    js_src = args.build_dir / "bin/tic80.js"
    wasm_src = args.build_dir / "bin/tic80.wasm"
    for path in (js_src, wasm_src):
        if not path.is_file():
            raise SystemExit(f"missing build artifact: {path}")

    js = js_src.read_bytes()
    wasm = wasm_src.read_bytes()
    if wasm[:4] != b"\x00asm":
        raise SystemExit("tic80.wasm does not start with the WebAssembly magic")
    if b"SPRITE EDITOR" not in wasm:
        raise SystemExit("BUILD_EDITORS=ON marker missing from wasm (SPRITE EDITOR)")
    if b"Unable to initialize SDL Video" in wasm:
        raise SystemExit("SDL layer marker present; the Sokol Web layer did not take")
    has_marker = MARKER in wasm
    if args.variant == "relink" and not has_marker:
        raise SystemExit("relink variant wasm lacks FLOE-BLIP-RELINK-MARKER-v1")
    if args.variant == "baseline" and has_marker:
        raise SystemExit("baseline variant unexpectedly contains the relink marker")
    expected_banner = RELINK_BANNER if args.variant == "relink" else BASELINE_BANNER
    if expected_banner not in wasm:
        raise SystemExit(f"expected version banner missing: {expected_banner!r}")

    locate = b'locateFile("tic80.wasm")'
    if js.count(locate) != 1:
        raise SystemExit(
            f"expected exactly one locateFile(\"tic80.wasm\") in loader; found {js.count(locate)}"
        )

    out = args.out
    if out.exists():
        raise SystemExit("Use a fresh output directory; preserve the previous package")
    upstream = out / "upstream"
    floe = out / "floe-resource"
    upstream.mkdir(parents=True)
    floe.mkdir(parents=True)

    (upstream / "tic80.js").write_bytes(js)
    (upstream / "tic80.wasm").write_bytes(wasm)
    index = args.tree / "build/html/index.html"
    if not index.is_file():
        raise SystemExit(f"missing upstream index.html: {index}")
    shutil.copy2(index, upstream / "index.html")

    patched_js = js.replace(locate, b'locateFile("tic80js.wasm")')
    if patched_js.count(b'locateFile("tic80js.wasm")') != 1:
        raise SystemExit("loader wasm-name rewrite did not produce exactly one reference")
    (floe / "tic80.js").write_bytes(patched_js)
    (floe / "tic80js.wasm").write_bytes(wasm)
    (floe / "index.html").write_text(
        """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Floe TIC-80 relink check</title>
<style>html,body{margin:0;height:100%;overflow:hidden;background:#1a1c2c}canvas{position:absolute;inset:0;width:100%;height:100%;image-rendering:pixelated;touch-action:none}</style>
</head>
<body>
<canvas id="canvas" tabindex="0" oncontextmenu="event.preventDefault()"></canvas>
<script>
window.Module = {
  canvas: document.getElementById("canvas"),
  arguments: ["cart.tic"],
  print: function (text) { console.log(String(text)); },
  printErr: function (text) { console.error(String(text)); }
};
</script>
<script src="tic80.js"></script>
</body>
</html>
""",
        encoding="utf-8",
    )
    fixture = args.fixture
    if fixture is None:
        candidate = args.kit_root / "fixtures/floe-relink-check.tic"
        fixture = candidate if candidate.is_file() else None
    if fixture is not None:
        if not fixture.is_file():
            raise SystemExit(f"missing fixture: {fixture}")
        shutil.copy2(fixture, floe / "cart.tic")

    notices = out / "notices"
    notices.mkdir()
    for name in ["THIRD-PARTY-NOTICES-WEB.md", "EMSCRIPTEN-LICENSE.txt", "TIC-80-MIT.txt"]:
        source = args.kit_root / "notices" / name
        if not source.is_file():
            raise SystemExit(f"missing notice: {source}")
        shutil.copy2(source, notices / name)
    if (args.kit_root / "notices/LICENSES").is_dir():
        shutil.copytree(args.kit_root / "notices/LICENSES", notices / "LICENSES")
    license_index = args.kit_root / "manifests/LICENSE-INDEX.json"
    if license_index.is_file():
        shutil.copy2(license_index, notices / "LICENSE-INDEX.json")
    embedded = args.kit_root / "manifests/EMBEDDED-ASSET-REVIEW.json"
    if embedded.is_file():
        shutil.copy2(embedded, notices / "EMBEDDED-ASSET-REVIEW.json")
    upstream_notices = args.tree / "THIRD_PARTY_LICENSES.md"
    if upstream_notices.is_file():
        shutil.copy2(upstream_notices, notices / "UPSTREAM-THIRD-PARTY-LICENSES.md")

    records: list[dict] = []
    for directory, role in [(upstream, "upstream"), (floe, "floe-resource")]:
        for path in sorted(directory.rglob("*")):
            if path.is_file():
                add_record(records, out, path, role)
    for path in sorted(notices.rglob("*")):
        if path.is_file():
            add_record(records, out, path, "notice")

    profile = {
        "format": "floe-tic80-runtime-profile",
        "version": 1,
        "engine": "tic80",
        "upstream": "https://github.com/nesbox/TIC-80/releases/tag/v1.4.1",
        "sourceCommit": "b3dbd597eecfe6742f64001c2fe5ba6c1afe55d9",
        "runtimeRevision": "1.4.1-floe-relink1" if args.variant == "relink" else "1.4.1",
        "buildVariant": args.variant,
        "files": {
            "js": "floe-resource/tic80.js",
            "wasm": "floe-resource/tic80js.wasm",
            "entry": "floe-resource/index.html",
            "fixture": "floe-resource/cart.tic" if (floe / "cart.tic").is_file() else None,
        },
        "hashes": {
            "jsSHA256": sha256_bytes(patched_js),
            "wasmSHA256": sha256_bytes(wasm),
            "upstreamJSHA256": sha256_bytes(js),
        },
        "versionBanner": expected_banner.decode("ascii"),
        "blipRelinkMarker": has_marker,
        "license": "TIC-80 MIT; linked blip_buf LGPL-2.1-or-later; see notices",
        "caveats": [
            "Not executed by this packaging script.",
            "The relink variant proves the marker/version bytes; a human Root load is still required for UI/audio acceptance.",
            "Uncleared embedded demos are omitted by patch 0004; exact upstream source remains in the companion. See DISTRIBUTABLE-ASSET-POLICY.json.",
        ],
    }
    (out / "runtime-profile.json").write_text(json.dumps(profile, indent=2) + "\n")
    add_record(records, out, out / "runtime-profile.json", "profile")

    manifest = {
        "format": "floe-tic80-runtime-package",
        "version": 1,
        "variant": args.variant,
        "runtimeProfile": profile,
        "files": records,
    }
    (out / "RUNTIME-MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")

    print(f"packaged {args.variant}: {len(records)} files")
    print(f"  js   {sha256_bytes(patched_js)}  {len(patched_js)} bytes")
    print(f"  wasm {sha256_bytes(wasm)}  {len(wasm)} bytes")
    print(f"  marker={has_marker} banner={expected_banner.decode('ascii')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
