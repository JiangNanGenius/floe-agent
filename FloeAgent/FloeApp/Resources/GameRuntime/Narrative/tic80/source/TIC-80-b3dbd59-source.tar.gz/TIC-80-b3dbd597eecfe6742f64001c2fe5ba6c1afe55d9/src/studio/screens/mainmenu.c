// MIT License

// Copyright (c) 2017 Vadim Grigoruk @nesbox // grigoruk@gmail.com

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#include "studio/studio.h"
#include "studio/config.h"
#include "studio/screens/menu.h"
#include "tic_assert.h"
#include "mainmenu.h"

typedef struct
{
    tic_mapping mapping;
    s32 index;
    s32 key;
} Gamepads;

struct StudioMainMenu
{
    Studio* studio;
    tic_mem* tic;
    Menu* menu;

    MenuItem* items;
    s32 count;

    Gamepads gamepads;
    struct StudioOptions* options;
};

// clang-format off
#define OPTION_VALUES(...)                          \
    .values = (const char*[])__VA_ARGS__,           \
    .count = COUNT_OF(((const char*[])__VA_ARGS__))
// clang-format on

static void showMainMenu(void* data, s32 pos);
static void onBackFromOptionsMenu(void* data, s32 pos);

StudioMainMenu* studio_mainmenu_init(Menu* menu, Config* config)
{
    StudioMainMenu* main = NEW(StudioMainMenu);

    *main = (StudioMainMenu){
        .menu = menu,
        .options = &config->data.options,
        .studio = config->studio,
        .tic = config->tic,
        .gamepads.key = -1,
    };

    showMainMenu(main, 0);

    return main;
}

static void initGamepadMenu(StudioMainMenu* menu);

bool studio_mainmenu_keyboard(StudioMainMenu* main)
{
    if(main && main->gamepads.key >= 0)
    {
        tic_key key = *main->tic->ram->input.keyboard.keys;
        if(key > tic_key_unknown)
        {
            main->gamepads.mapping.data[main->gamepads.index * TIC_BUTTONS + main->gamepads.key] = key;
            initGamepadMenu(main);
        }

        return true;
    }

    return false;
}

static s32 optionFullscreenGet(void* data)
{
    (void)data;
    return tic_sys_fullscreen_get() ? 1 : 0;
}

static void optionFullscreenSet(void* data, s32 pos)
{
    StudioMainMenu* main = data;
    tic_sys_fullscreen_set(main->options->fullscreen = (pos == 1));
}

static const char OffValue[] = "OFF";
static const char OnValue[] = "ON";

static MenuOption FullscreenOption =
    {
        OPTION_VALUES({OffValue, OnValue}),
        optionFullscreenGet,
        optionFullscreenSet,
};

static s32 optionIntegerScaleGet(void* data)
{
    StudioMainMenu* main = data;
    return main->options->integerScale ? 1 : 0;
}

static void optionIntegerScaleSet(void* data, s32 pos)
{
    StudioMainMenu* main = data;
    main->options->integerScale = (pos == 1);
}

static MenuOption IntegerScaleOption =
    {
        OPTION_VALUES({OffValue, OnValue}),
        optionIntegerScaleGet,
        optionIntegerScaleSet,
};

#if defined(BUILD_RENDER_CACHE)
static s32 optionDrawCacheGet(void* data)
{
    StudioMainMenu* main = data;
    return main->options->drawCache ? 1 : 0;
}

static void optionDrawCacheSet(void* data, s32 pos)
{
    StudioMainMenu* main = data;
    main->options->drawCache = (pos == 1);
    tic_core_draw_cache_set_enabled(main->tic, main->options->drawCache);
}

static MenuOption DrawCacheOption =
    {
        OPTION_VALUES({OffValue, OnValue}),
        optionDrawCacheGet,
        optionDrawCacheSet,
};
#endif

#if defined(CRT_SHADER_SUPPORT)
static s32 optionCrtMonitorGet(void* data)
{
    StudioMainMenu* main = data;
    return main->options->crt ? 1 : 0;
}

static void optionCrtMonitorSet(void* data, s32 pos)
{
    StudioMainMenu* main = data;
    main->options->crt = pos == 1;
}

static MenuOption CrtMonitorOption =
    {
        OPTION_VALUES({OffValue, OnValue}),
        optionCrtMonitorGet,
        optionCrtMonitorSet,
};

#endif

// A layer that makes its window before the studio reads its config can never
// honor this: sokol's cannot, so it runs at the display's rate and the menu
// does not offer what it cannot do.
#if !defined(VSYNC_ALWAYS_ON)
static s32 optionVSyncGet(void* data)
{
    StudioMainMenu* main = data;
    return main->options->vsync ? 1 : 0;
}

static void optionVSyncSet(void* data, s32 pos)
{
    StudioMainMenu* main = data;
    main->options->vsync = pos == 1;
}

static MenuOption VSyncOption =
    {
        OPTION_VALUES({OffValue, OnValue}),
        optionVSyncGet,
        optionVSyncSet,
};
#endif

static s32 optionVolumeGet(void* data)
{
    StudioMainMenu* main = data;
    return main->options->volume;
}

static void optionVolumeSet(void* data, s32 pos)
{
    StudioMainMenu* main = data;
    main->options->volume = pos;
}

static MenuOption VolumeOption =
    {
        OPTION_VALUES(
            {
                "00",
                "01",
                "02",
                "03",
                "04",
                "05",
                "06",
                "07",
                "08",
                "09",
                "10",
                "11",
                "12",
                "13",
                "14",
                "15",
            }),
        optionVolumeGet,
        optionVolumeSet,
};

static void showGamepadMenu(void* data, s32 pos)
{
    (void)pos;
    StudioMainMenu* main = data;
    main->gamepads.index = 0;
    main->gamepads.mapping = main->options->mapping;

    initGamepadMenu(main);
}

enum
{
#if defined(CRT_SHADER_SUPPORT)
    OptionsMenu_CrtMonitorOption,
#endif
#if !defined(VSYNC_ALWAYS_ON)
    OptionsMenu_VSyncOption,
#endif
    OptionsMenu_FullscreenOption,
    OptionsMenu_IntegerScaleOption,
#if defined(BUILD_RENDER_CACHE)
    OptionsMenu_DrawCacheOption,
#endif
    OptionsMenu_VolumeOption,
    OptionsMenu_Gamepad,
    OptionsMenu_Separator,
    OptionsMenu_Back,
};

static const MenuItem OptionMenu[] =
    {
#if defined(CRT_SHADER_SUPPORT)
        {.label = "CRT MONITOR", .option = &CrtMonitorOption},
#endif
#if !defined(VSYNC_ALWAYS_ON)
        {.label = "VSYNC", .option = &VSyncOption, .help = "VSYNC needs restart!"},
#endif
        {.label = "FULLSCREEN", .option = &FullscreenOption},
        {.label = "INTEGER SCALE", .option = &IntegerScaleOption},
#if defined(BUILD_RENDER_CACHE)
        {.label = "DRAW CACHE", .option = &DrawCacheOption, .help = "Cache draw calls for CPU saving"},
#endif
        {.label = "VOLUME", .option = &VolumeOption},
        {.label = "SETUP GAMEPAD", .handler = showGamepadMenu},
        {.label = ""},
        {.label = "BACK", .handler = onBackFromOptionsMenu, .back = true},
};

// The menu cursor is an index into the table — a submenu returns to
// OptionsMenu_<row> (menu.c backDone) — so an entry added to one and not to
// the other silently points every later row one off. The autosave row did
// exactly that; the assert is what catches the next one.
static_assert(COUNT_OF(OptionMenu) == OptionsMenu_Back + 1, "OptionMenuCount");

static void showOptionsMenu(void* data, s32 pos);
static void gameMenuHandler(void* data, s32 pos)
{
    StudioMainMenu* main = data;
    tic_mem* tic = main->tic;

    // The menu can also be opened in the studio, where there is no pause to
    // return to: start the cart as RUN would.
    if(studio_run_paused(main->studio))
        resumeGame(main->studio);
    else
        runGame(main->studio, RUN_FROM_STUDIO);

    tic_get_script(tic)->callback.menu(tic, pos, NULL);
}

static void freeItems(StudioMainMenu* menu)
{
    if(menu && menu->items)
    {
        for(MenuItem *it = menu->items, *end = it + menu->count; it != end; ++it)
            free((void*)it->label);

        free(menu->items);
        menu->count = 0;
        menu->items = NULL;
    }
}

void studio_mainmenu_free(StudioMainMenu* menu)
{
    freeItems(menu);
    FREE(menu);
}

static void initGameMenu(StudioMainMenu* main)
{
    tic_mem* tic = main->tic;

    freeItems(main);

    const char* value = tic_tool_metatag(tic->cart.code.data, "menu", tic_get_script(tic)->singleComment);

    if(*value)
    {
        char* menu = strdup(value);

        SCOPE(free(menu))
        {
            MenuItem* items = NULL;
            s32 count = 0;

            char* label = strtok(menu, " ");
            while(label)
            {
                items = realloc(items, sizeof(MenuItem) * ++count);
                items[count - 1] = (MenuItem){.label = strdup(label), .handler = gameMenuHandler};

                label = strtok(NULL, " ");
            }

            count += 2;
            items = realloc(items, sizeof(MenuItem) * count);
            items[count - 2] = (MenuItem){.label = strdup("")};
            items[count - 1] = (MenuItem){.label = strdup("BACK"), .handler = showMainMenu, .back = true};

            main->items = items;
            main->count = count;
        }
    }
}

static void showGameMenu(void* data, s32 pos)
{
    (void)pos;
    StudioMainMenu* main = data;
    studio_menu_init(main->menu, main->items, main->count, 0, 0, showMainMenu, main);
}

static inline s32 mainMenuOffset(StudioMainMenu* menu)
{
    // Only the game menu of the loaded cart can be missing, so the entry
    // point is the item right after it. Skipping further (#2889) hid RESUME
    // GAME and RESET GAME whenever no cart was loaded, which put a lone
    // CLOSE GAME on top of the menu.
    return menu->count ? 0 : 1;
}

static void onBackFromOptionsMenu(void* data, s32 pos)
{
    StudioMainMenu* main = data;
    Config* config = studio_config_get(main->studio);
    config->saveOptions(config);

    showMainMenu(data, pos);
}

static void onResumeGame(void* data, s32 pos)
{
    (void)pos;
    StudioMainMenu* main = data;

    // Opened in the studio, there is no pause to return to; start the cart.
    if(studio_run_paused(main->studio))
        resumeGame(main->studio);
    else
        runGame(main->studio, RUN_FROM_STUDIO);
}

// The back of the top level menu (ESC or the gamepad's B): the menu sits over
// a paused run and belongs to whoever started it — a player's run resumes
// under it, while a dev run, a menu opened in the studio, and a run whose
// pause a reload cleared step out to runFrom. The same step ESC takes in RUN
// mode, so a run of a cart with a game menu is left with ESC ESC instead of a
// walk to CLOSE GAME (#2937).
static void onMenuBack(void* data, s32 pos)
{
    StudioMainMenu* main = data;

    if(studio_menu_over_player_run(main->studio))
        onResumeGame(data, pos);
    else
        leaveRun(main->studio);
}

static void onResetGame(void* data, s32 pos)
{
    (void)pos;
    StudioMainMenu* main = data;
    tic_api_reset(main->tic);
    setStudioMode(main->studio, TIC_RUN_MODE);
}

static void onExitStudio(void* data, s32 pos)
{
    (void)pos;
    StudioMainMenu* main = data;
    exitStudio(main->studio);
}

#if defined(BUILD_EDITORS) || defined(BUILD_SURF)
static void onExitGame(void* data, s32 pos)
{
    (void)pos;
    StudioMainMenu* main = data;
    exitGame(main->studio);
}
#endif

enum MainMenu
{
    MainMenu_GameMenu,
    MainMenu_ResumeGame,
    MainMenu_ResetGame,
#if defined(BUILD_EDITORS) || defined(BUILD_SURF)
    MainMenu_CloseGame,
#endif
    MainMenu_Options,
    MainMenu_Separator,
    MainMenu_Quit,
};

static const MenuItem MainMenu[] =
    {
        {.label = "GAME MENU", .handler = showGameMenu},
        {.label = "RESUME GAME", .handler = onResumeGame},
        {.label = "RESET GAME", .handler = onResetGame},
#if defined(BUILD_EDITORS)
        {.label = "CLOSE GAME", .handler = onExitGame, .help = "Press F1 to switch to editor"},
#elif defined(BUILD_SURF)
        {.label = "CLOSE GAME", .handler = onExitGame},
#endif
        {.label = "OPTIONS", .handler = showOptionsMenu},
        {.label = ""},
        {.label = "QUIT TIC-80", .handler = onExitStudio},
};

static_assert(COUNT_OF(MainMenu) == MainMenu_Quit + 1, "MainMenuCount");

static void showMainMenu(void* data, s32 pos)
{
    (void)pos;
    StudioMainMenu* main = data;
    initGameMenu(main);

    s32 offset = mainMenuOffset(main);
    studio_menu_init(main->menu, MainMenu + offset, COUNT_OF(MainMenu) - offset, 0, 0, studio_is_cart_loaded(main->studio) ? onMenuBack : NULL, main);
}

static void showOptionsMenuPos(void* data, s32 pos)
{
    StudioMainMenu* main = data;

    s32 offset = mainMenuOffset(main);
    studio_menu_init(main->menu, OptionMenu, COUNT_OF(OptionMenu), pos, MainMenu_Options - offset, onBackFromOptionsMenu, main);
}

static void showOptionsMenu(void* data, s32 pos)
{
    (void)pos;
    showOptionsMenuPos(data, OptionsMenu_VolumeOption);
}

static void resetGamepadMenu(void* data, s32 pos);

static char MappingItems[TIC_BUTTONS][sizeof "RIGHT - RIGHT"];

static const char* const ButtonLabels[] =
    {
        "UP",
        "DOWN",
        "LEFT",
        "RIGHT",
        "A",
        "B",
        "X",
        "Y",
};

enum
{
    GamepadMenu_Index,
    GamepadMenu_Separator,
    GamepadMenu_Gamepad0,
    GamepadMenu_Gamepad1,
    GamepadMenu_Gamepad2,
    GamepadMenu_Gamepad3,
    GamepadMenu_Gamepad4,
    GamepadMenu_Gamepad5,
    GamepadMenu_Gamepad6,
    GamepadMenu_Gamepad7,
    GamepadMenu_Separator2,
    GamepadMenu_Save,
    GamepadMenu_Clear,
    GamepadMenu_Reset,
    GamepadMenu_Back,
};

static void assignMapping(void* data, s32 pos)
{
    StudioMainMenu* main = data;

    main->gamepads.key = pos - GamepadMenu_Gamepad0;

    static const char Fmt[] = "to assign to (%s) button...";
    static char str[sizeof Fmt + STRLEN("RIGHT")];

    static const MenuItem AssignKeyMenu[] =
        {
            {.label = "Please, press a key you want"},
            {.label = str},
        };

    sprintf(str, Fmt, ButtonLabels[main->gamepads.key]);

    studio_menu_init(main->menu, AssignKeyMenu, COUNT_OF(AssignKeyMenu), 1, 0, NULL, main);
}

static void initGamepadButtons(StudioMainMenu* menu)
{
    static const char* const KeysList[] =
        {
            "...",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "-",
            "=",
            "[",
            "]",
            "\\",
            ";",
            "'",
            "`",
            ",",
            ".",
            "/",
            "SPCE",
            "TAB",
            "RET",
            "BACKS",
            "DEL",
            "INS",
            "PGUP",
            "PGDN",
            "HOME",
            "END",
            "UP",
            "DOWN",
            "LEFT",
            "RIGHT",
            "CAPS",
            "CTRL",
            "SHIFT",
            "ALT",
            "ESC",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "NP0",
            "NP1",
            "NP2",
            "NP3",
            "NP4",
            "NP5",
            "NP6",
            "NP7",
            "NP8",
            "NP9",
            "NP+",
            "NP-",
            "NP*",
            "NP/",
            "NPENT",
            "NP.",
        };

    for(s32 i = 0, index = menu->gamepads.index * TIC_BUTTONS; i != TIC_BUTTONS; ++i)
        sprintf(MappingItems[i], "%-5s - %-5s", ButtonLabels[i], KeysList[menu->gamepads.mapping.data[index++]]);
}

static s32 optionGamepadGet(void* data)
{
    StudioMainMenu* main = data;
    return main->gamepads.index;
}

static void optionGamepadSet(void* data, s32 pos)
{
    StudioMainMenu* main = data;
    main->gamepads.index = pos;
    initGamepadButtons(main);
}

static MenuOption GamepadOption =
    {
        OPTION_VALUES({"1", "2", "3", "4"}),
        optionGamepadGet,
        optionGamepadSet,
};

static void clearGamepadMenu(void* data, s32 pos)
{
    (void)pos;
    StudioMainMenu* main = data;
    ZEROMEM(main->gamepads.mapping);
    initGamepadMenu(main);
}

static void saveGamepadMenu(void* data, s32 pos)
{
    (void)pos;
    StudioMainMenu* main = data;

    main->options->mapping = main->gamepads.mapping;
    showOptionsMenuPos(data, OptionsMenu_Gamepad);
}

static void initGamepadMenu(StudioMainMenu* main)
{
    static const MenuItem GamepadMenu[] =
        {
            {.label = "GAMEPAD", .option = &GamepadOption},
            {.label = ""},

            {.label = MappingItems[0], .handler = assignMapping},
            {.label = MappingItems[1], .handler = assignMapping},
            {.label = MappingItems[2], .handler = assignMapping},
            {.label = MappingItems[3], .handler = assignMapping},
            {.label = MappingItems[4], .handler = assignMapping},
            {.label = MappingItems[5], .handler = assignMapping},
            {.label = MappingItems[6], .handler = assignMapping},
            {.label = MappingItems[7], .handler = assignMapping},

            {.label = ""},
            {.label = "SAVE MAPPING", .handler = saveGamepadMenu},
            {.label = "CLEAR MAPPING", .handler = clearGamepadMenu},
            {.label = "RESET TO DEFAULTS", .handler = resetGamepadMenu},
            {.label = "BACK", .handler = showOptionsMenu, .back = true},
        };

    static_assert(COUNT_OF(GamepadMenu) == GamepadMenu_Back + 1, "GamepadMenuCount");

    initGamepadButtons(main);

    studio_menu_init(main->menu, GamepadMenu, COUNT_OF(GamepadMenu),
                     main->gamepads.key < 0 ? GamepadMenu_Gamepad0 : main->gamepads.key + GamepadMenu_Gamepad0,
                     OptionsMenu_Gamepad, showOptionsMenu, main);

    main->gamepads.key = -1;
}

static void resetGamepadMenu(void* data, s32 pos)
{
    (void)pos;
    StudioMainMenu* main = data;
    main->gamepads.index = 0;
    ZEROMEM(main->gamepads.mapping);
    tic_sys_default_mapping(&main->gamepads.mapping);
    initGamepadMenu(main);
}
