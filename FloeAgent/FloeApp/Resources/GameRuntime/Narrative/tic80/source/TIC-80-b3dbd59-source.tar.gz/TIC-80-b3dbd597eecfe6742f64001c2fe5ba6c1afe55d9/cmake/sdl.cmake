################################
# SDL2
################################
if(PREFER_SYSTEM_SDL2)
    find_package(SDL2)
    if(SDL2_FOUND)
        if(NINTENDO_SWITCH)
            add_library(SDL2 ALIAS SDL2::SDL2-static)
            add_library(SDL2-static ALIAS SDL2::SDL2-static)
        else()
            add_library(SDL2 ALIAS SDL2::SDL2)
            add_library(SDL2-static ALIAS SDL2::SDL2)
        endif()
        message(STATUS "Use system library: SDL2")
    else()
        message(WARNING "System library SDL2 not found")
    endif()
endif()


if(BUILD_SDL AND NOT EMSCRIPTEN AND NOT RPI AND NOT PREFER_SYSTEM_SDL2)

    if(WIN32)
        set(HAVE_LIBC TRUE)
    endif()

    if(ANDROID)
        include_directories(${ANDROID_NDK}/sources/android/cpufeatures)
        set(SDL_STATIC_PIC ON CACHE BOOL "" FORCE)
    endif()

    # SDL2 builds its own test helper and, by default, a shared library beside
    # the static one — three passes over the same six hundred sources. TIC-80
    # links neither the helper nor, in a static build, the shared library, and
    # the extra targets are what put the macOS runners past their per-user
    # process limit (see the parallel cap in build.yml). A non-static build
    # links SDL2::SDL2, so the shared library stays in that one.
    set(SDL_TEST OFF CACHE BOOL "" FORCE)
    if(BUILD_STATIC)
        set(SDL_SHARED OFF CACHE BOOL "" FORCE)
    endif()

    # Subsystems the engine never calls: haptic, sensor and power feedback
    # (no SDL_Haptic/SDL_Sensor/SDL_GetPowerInfo anywhere in src/). SDL then
    # skips their platform backends and compiles the stubs in their place, so
    # the saving is small — the joystick subsystem stays, which is the one the
    # studio's pad support uses. Haptic is the exception on Android: SDL's JNI
    # glue there calls Android_AddHaptic and Android_RemoveHaptic whatever
    # SDL_HAPTIC says, and the link fails without them.
    set(SDL_SENSOR OFF CACHE BOOL "" FORCE)
    set(SDL_POWER  OFF CACHE BOOL "" FORCE)
    if(NOT ANDROID)
        set(SDL_HAPTIC OFF CACHE BOOL "" FORCE)
    endif()

    add_subdirectory(${THIRDPARTY_DIR}/sdl2)

    if(MSVC)
        # CMake policy CMP0079
        # This allows linking libraries to targets not built in the current directory.
        cmake_policy(SET CMP0079 NEW)

        # SDL2 here is the shared library, which a static build does not create
        # (SDL_SHARED=OFF above) — and it was never the target TIC-80 links:
        # the static one carries its own CRT settings, and giving it these would
        # mix runtimes with whatever SDL chose. So the static CRT goes to the
        # shared library when there is one, and nowhere when there is not.
        if(TARGET SDL2)
            target_link_libraries(SDL2 PRIVATE
                libcmt.lib
                libvcruntime.lib
                libucrt.lib
            )
        endif()
    endif()

endif()

################################
# SDL2 standalone cart player
################################

if(BUILD_SDL AND BUILD_PLAYER AND NOT RPI)

    add_executable(player-sdl WIN32 ${CMAKE_SOURCE_DIR}/src/system/sdl/player.c)

    if (FREEBSD)
        target_include_directories(player-sdl PRIVATE ${SYSROOT_PATH}/usr/local/include)
        target_link_directories(player-sdl PRIVATE ${SYSROOT_PATH}/usr/local/lib)
    endif()

    target_include_directories(player-sdl PRIVATE
        ${THIRDPARTY_DIR}/sdl2/include
        ${CMAKE_SOURCE_DIR}/include
        ${CMAKE_SOURCE_DIR}/src)

    if(MINGW)
        target_link_libraries(player-sdl PRIVATE mingw32)
        target_link_options(player-sdl PRIVATE -static)
    endif()

    target_link_libraries(player-sdl PRIVATE tic80core)
    if(NOT PREFER_SYSTEM_SDL2)
        target_link_libraries(player-sdl PRIVATE SDL2main)
    endif()

    if(BUILD_STATIC AND NOT USE_GLES2)
        target_link_libraries(player-sdl PRIVATE SDL2-static)
    else()
        target_link_libraries(player-sdl PRIVATE SDL2)
    endif()
endif()

################################
# SDL GPU
################################

if(BUILD_SDLGPU)

set(SDLGPU_DIR ${THIRDPARTY_DIR}/sdl-gpu/src)
set(SDLGPU_SRC
    ${SDLGPU_DIR}/renderer_GLES_2.c
    ${SDLGPU_DIR}/SDL_gpu.c
    ${SDLGPU_DIR}/SDL_gpu_matrix.c
    ${SDLGPU_DIR}/SDL_gpu_renderer.c
    ${SDLGPU_DIR}/externals/stb_image/stb_image.c
    ${SDLGPU_DIR}/externals/stb_image_write/stb_image_write.c
)

if(NOT ANDROID AND NOT NINTENDO_SWITCH AND NOT USE_GLES2)
    list(APPEND SDLGPU_SRC
        ${SDLGPU_DIR}/renderer_GLES_1.c
        ${SDLGPU_DIR}/renderer_GLES_3.c
        ${SDLGPU_DIR}/renderer_OpenGL_1.c
        ${SDLGPU_DIR}/renderer_OpenGL_1_BASE.c
        ${SDLGPU_DIR}/renderer_OpenGL_2.c
        ${SDLGPU_DIR}/renderer_OpenGL_3.c
        ${SDLGPU_DIR}/renderer_OpenGL_4.c
        ${SDLGPU_DIR}/SDL_gpu_shapes.c
        ${SDLGPU_DIR}/externals/glew/glew.c
    )
endif()

add_library(sdlgpu STATIC ${SDLGPU_SRC})

if(EMSCRIPTEN OR ANDROID OR NINTENDO_SWITCH OR USE_GLES2)
    target_compile_definitions(sdlgpu PRIVATE GLEW_STATIC SDL_GPU_DISABLE_GLES_1 SDL_GPU_DISABLE_GLES_3 SDL_GPU_DISABLE_OPENGL)
else()
    target_compile_definitions(sdlgpu PRIVATE GLEW_STATIC SDL_GPU_DISABLE_GLES SDL_GPU_DISABLE_OPENGL_3 SDL_GPU_DISABLE_OPENGL_4)
endif()

target_include_directories(sdlgpu PUBLIC ${THIRDPARTY_DIR}/sdl-gpu/include)
target_include_directories(sdlgpu PRIVATE ${THIRDPARTY_DIR}/sdl2/include)
target_include_directories(sdlgpu PRIVATE ${THIRDPARTY_DIR}/sdl-gpu/src/externals/glew)
target_include_directories(sdlgpu PRIVATE ${THIRDPARTY_DIR}/sdl-gpu/src/externals/glew/GL)
target_include_directories(sdlgpu PRIVATE ${THIRDPARTY_DIR}/sdl-gpu/src/externals/stb_image)
target_include_directories(sdlgpu PRIVATE ${THIRDPARTY_DIR}/sdl-gpu/src/externals/stb_image_write)

if(USE_GLES2 OR USE_EGL)
    target_include_directories(sdlgpu PRIVATE ${THIRDPARTY_DIR}/sdl2/src/video/khronos)
endif()

if(WIN32)
    target_link_libraries(sdlgpu opengl32)
endif()

if(LINUX)
    if(USE_GLES2)
        target_link_libraries(sdlgpu GLESv2)
    endif()

    if(USE_EGL)
        target_link_libraries(sdlgpu EGL)
    endif()

    if(NOT USE_GLES2 AND NOT USE_EGL)
        target_link_libraries(sdlgpu GL)
    endif()
endif()

if(APPLE)
    find_library(OPENGL_LIBRARY OpenGL)
    target_link_libraries(sdlgpu ${OPENGL_LIBRARY})
endif()

if(ANDROID)
    find_library( ANDROID_LOG_LIBRARY log )
    find_library( ANDROID_GLES2_LIBRARY GLESv2 )
    find_library( ANDROID_GLES1_LIBRARY GLESv1_CM )
    target_link_libraries(sdlgpu
        ${ANDROID_LOG_LIBRARY}
        ${ANDROID_GLES2_LIBRARY}
        ${ANDROID_GLES1_LIBRARY}
    )
endif()

if(NINTENDO_SWITCH)
    find_package(PkgConfig REQUIRED)
    pkg_search_module(GLES2 glesv2 REQUIRED IMPORTED_TARGET)
    target_link_libraries(sdlgpu PkgConfig::GLES2)
endif()

if(NOT EMSCRIPTEN)
    if(PREFER_SYSTEM_SDL2)
        target_link_libraries(sdlgpu SDL2)
    elseif(BUILD_STATIC AND NOT USE_GLES2)
        target_link_libraries(sdlgpu SDL2-static)
    else()
        target_link_libraries(sdlgpu SDL2)
    endif()
endif()

endif()

################################
# TIC-80 app
################################

if(BUILD_SDL)

    set(TIC80_SRC src/system/sdl/main.c)

    if(WIN32)

        configure_file("${PROJECT_SOURCE_DIR}/build/windows/tic80.rc.in" "${PROJECT_SOURCE_DIR}/build/windows/tic80.rc")
        set(TIC80_SRC ${TIC80_SRC} "${PROJECT_SOURCE_DIR}/build/windows/tic80.rc")

        add_executable(${TIC80_TARGET} ${SYSTEM_TYPE} ${TIC80_SRC})

    elseif(ANDROID)

        set(TIC80_SRC ${TIC80_SRC} ${ANDROID_NDK}/sources/android/cpufeatures/cpu-features.c)

        add_library(${TIC80_TARGET} SHARED ${TIC80_SRC})

    else()
        add_executable(${TIC80_TARGET} ${TIC80_SRC})
    endif()

    target_include_directories(${TIC80_TARGET} PRIVATE ${THIRDPARTY_DIR}/sdl2/include)

    if(MINGW)
        target_link_libraries(${TIC80_TARGET} mingw32)
        target_link_options(${TIC80_TARGET} PRIVATE -static -mconsole)
    endif()

    if(EMSCRIPTEN)
        # Emscripten gives the stack 64K by default, and a wasm build has no
        # guard page below it: a cart that recurses deeper than that overwrites
        # whatever follows, silently in a release build (a debug build asserts
        # instead). The native builds get the OS default of 8M, so a cart that
        # runs there must not corrupt the heap here: ask for 4M.
        # Carcassonne (#1948) is the cart that found this: its Wren source
        # compiles deep enough to pass 64K, and the damage surfaced later as an
        # unrelated crash in SDL's mouse handling.
        set_target_properties(${TIC80_TARGET} PROPERTIES LINK_FLAGS "-s WASM=1 -s USE_SDL=2 -s ALLOW_MEMORY_GROWTH=1 -s FETCH=1 -s STACK_SIZE=4194304 -s EXPORTED_FUNCTIONS=_main,_malloc,_free --pre-js ${CMAKE_SOURCE_DIR}/build/html/prejs.js -lidbfs.js")
        set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -s USE_SDL=2")

        if(CMAKE_BUILD_TYPE STREQUAL "Debug")
            set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -s ASSERTIONS=1")
        endif()

    elseif(NOT ANDROID AND NOT PREFER_SYSTEM_SDL2)
        target_link_libraries(${TIC80_TARGET} SDL2main)
    endif()

    target_link_libraries(${TIC80_TARGET} tic80studio)

    if(BUILD_TOUCH_INPUT)
        target_compile_definitions(${TIC80_TARGET} PRIVATE TOUCH_INPUT_SUPPORT)
    endif()

    if (FREEBSD)
        target_include_directories(${TIC80_TARGET} PRIVATE ${SYSROOT_PATH}/usr/local/include)
        target_link_directories(${TIC80_TARGET} PRIVATE ${SYSROOT_PATH}/usr/local/lib)
    endif()

    if(RPI)
        target_include_directories(${TIC80_TARGET} PRIVATE ${SYSROOT_PATH}/usr/local/include/SDL2)
        target_link_directories(${TIC80_TARGET} PRIVATE ${SYSROOT_PATH}/usr/local/lib ${SYSROOT_PATH}/opt/vc/lib)
        target_compile_definitions(${TIC80_TARGET} PRIVATE __RPI__)
    endif()

    if(BUILD_SDLGPU)
        target_link_libraries(${TIC80_TARGET} sdlgpu)
        if(LINUX)
            target_link_libraries(${TIC80_TARGET} pthread dl m)
        endif()
    else()
        if(EMSCRIPTEN)
        elseif(RPI)
            target_link_libraries(${TIC80_TARGET} libSDL2.a bcm_host pthread)
        else()
            if(BUILD_STATIC AND NOT USE_GLES2)
                target_link_libraries(${TIC80_TARGET} SDL2-static)
            else()
                target_link_libraries(${TIC80_TARGET} SDL2)
            endif()
        endif()
    endif()

endif()
