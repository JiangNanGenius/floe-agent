// MIT License

// Copyright (c) 2025 Carsten Teibes

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#include <switch.h>
#include <stdio.h>
#include <unistd.h>

#ifdef DEBUG
static int nxlink_sock = -1;

static void nxlink_init()
{
    socketInitializeDefault();
    nxlink_sock = nxlinkStdio();
    if(nxlink_sock >= 0)
        printf("nxlink activated...\n");
}

static void nxlink_exit()
{
    if(nxlink_sock >= 0)
    {
        close(nxlink_sock);
        nxlink_sock = -1;
    }
    socketExit();
}
#else
static void nxlink_init()
{
}
static void nxlink_exit()
{
}
#endif

// these hooks are called by libnx

void userAppInit()
{
    nxlink_init(); // enable debug log over network
    romfsInit();   // can be used for engine data or a shipped game
}

void userAppExit()
{
    romfsExit();
    nxlink_exit();
}
