/*
 * vim: ts=4 sts=4 sw=4 et
 */

// MIT License

// Copyright (c) 2022 Charlotte Koch @dressupgeekout <dressupgeekout@gmail.com>

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#include "core/core.h"

#include <janet.h>

extern bool parse_note(const char* noteStr, s32* note, s32* octave);

static inline tic_core* getJanetMachine(void);

static Janet janet_print(int32_t argc, Janet* argv);
static Janet janet_cls(int32_t argc, Janet* argv);
static Janet janet_pix(int32_t argc, Janet* argv);
static Janet janet_line(int32_t argc, Janet* argv);
static Janet janet_rect(int32_t argc, Janet* argv);
static Janet janet_rectb(int32_t argc, Janet* argv);
static Janet janet_spr(int32_t argc, Janet* argv);
static Janet janet_btn(int32_t argc, Janet* argv);
static Janet janet_btnp(int32_t argc, Janet* argv);
static Janet janet_btnr(int32_t argc, Janet* argv);
static Janet janet_sfx(int32_t argc, Janet* argv);
static Janet janet_map(int32_t argc, Janet* argv);
static Janet janet_mget(int32_t argc, Janet* argv);
static Janet janet_mset(int32_t argc, Janet* argv);
static Janet janet_peek(int32_t argc, Janet* argv);
static Janet janet_poke(int32_t argc, Janet* argv);
static Janet janet_peek1(int32_t argc, Janet* argv);
static Janet janet_poke1(int32_t argc, Janet* argv);
static Janet janet_peek2(int32_t argc, Janet* argv);
static Janet janet_poke2(int32_t argc, Janet* argv);
static Janet janet_peek4(int32_t argc, Janet* argv);
static Janet janet_poke4(int32_t argc, Janet* argv);
static Janet janet_memcpy(int32_t argc, Janet* argv);
static Janet janet_memset(int32_t argc, Janet* argv);
static Janet janet_trace(int32_t argc, Janet* argv);
static Janet janet_pmem(int32_t argc, Janet* argv);
static Janet janet_time(int32_t argc, Janet* argv);
static Janet janet_tstamp(int32_t argc, Janet* argv);
static Janet janet_exit(int32_t argc, Janet* argv);
static Janet janet_font(int32_t argc, Janet* argv);
static Janet janet_mouse(int32_t argc, Janet* argv);
static Janet janet_circ(int32_t argc, Janet* argv);
static Janet janet_circb(int32_t argc, Janet* argv);
static Janet janet_elli(int32_t argc, Janet* argv);
static Janet janet_ellib(int32_t argc, Janet* argv);
static Janet janet_paint(int32_t argc, Janet* argv);
static Janet janet_tri(int32_t argc, Janet* argv);
static Janet janet_trib(int32_t argc, Janet* argv);
static Janet janet_ttri(int32_t argc, Janet* argv);
static Janet janet_clip(int32_t argc, Janet* argv);
static Janet janet_music(int32_t argc, Janet* argv);
static Janet janet_sync(int32_t argc, Janet* argv);
static Janet janet_vbank(int32_t argc, Janet* argv);
static Janet janet_reset(int32_t argc, Janet* argv);
static Janet janet_key(int32_t argc, Janet* argv);
static Janet janet_keyp(int32_t argc, Janet* argv);
static Janet janet_keyr(int32_t argc, Janet* argv);
static Janet janet_fget(int32_t argc, Janet* argv);
static Janet janet_fset(int32_t argc, Janet* argv);
static Janet janet_fft(int32_t argc, Janet* argv);
static Janet janet_vqt(int32_t argc, Janet* argv);
static Janet janet_vqts(int32_t argc, Janet* argv);
static Janet janet_vqtr(int32_t argc, Janet* argv);
static Janet janet_vqtrs(int32_t argc, Janet* argv);
static Janet janet_vqtw(int32_t argc, Janet* argv);
static Janet janet_vqtsw(int32_t argc, Janet* argv);
static Janet janet_vqtrw(int32_t argc, Janet* argv);
static Janet janet_vqtrsw(int32_t argc, Janet* argv);
static Janet janet_ffts(int32_t argc, Janet* argv);
static Janet janet_fftr(int32_t argc, Janet* argv);
static Janet janet_fftrs(int32_t argc, Janet* argv);
static Janet janet_rrect(int32_t argc, Janet* argv);
static Janet janet_rrectb(int32_t argc, Janet* argv);

static void closeJanet(tic_mem* tic);
static bool initJanet(tic_mem* tic, const char* code);
static void evalJanet(tic_mem* tic, const char* code);
static void callJanetTick(tic_mem* tic);
static void callJanetBoot(tic_mem* tic);
static void callJanetIntCallback(tic_mem* tic, s32 value, void* data, const char* name);
static void callJanetScanline(tic_mem* tic, s32 row, void* data);
static void callJanetBorder(tic_mem* tic, s32 row, void* data);
static void callJanetMenu(tic_mem* tic, s32 index, void* data);
static const tic_outline_item* getJanetOutline(const char* code, s32* size);

/* ***************** */

static const JanetReg janet_c_functions[] =
    {
        {"print", janet_print, NULL},
        {"cls", janet_cls, NULL},
        {"pix", janet_pix, NULL},
        {"line", janet_line, NULL},
        {"rect", janet_rect, NULL},
        {"rectb", janet_rectb, NULL},
        {"spr", janet_spr, NULL},
        {"btn", janet_btn, NULL},
        {"btnp", janet_btnp, NULL},
        {"btnr", janet_btnr, NULL},
        {"sfx", janet_sfx, NULL},
        {"map", janet_map, NULL},
        {"mget", janet_mget, NULL},
        {"mset", janet_mset, NULL},
        {"peek", janet_peek, NULL},
        {"poke", janet_poke, NULL},
        {"peek1", janet_peek1, NULL},
        {"poke1", janet_poke1, NULL},
        {"peek2", janet_peek2, NULL},
        {"poke2", janet_poke2, NULL},
        {"peek4", janet_peek4, NULL},
        {"poke4", janet_poke4, NULL},
        {"memcpy", janet_memcpy, NULL},
        {"memset", janet_memset, NULL},
        {"trace", janet_trace, NULL},
        {"pmem", janet_pmem, NULL},
        {"time", janet_time, NULL},
        {"tstamp", janet_tstamp, NULL},
        {"exit", janet_exit, NULL},
        {"font", janet_font, NULL},
        {"mouse", janet_mouse, NULL},
        {"circ", janet_circ, NULL},
        {"circb", janet_circb, NULL},
        {"elli", janet_elli, NULL},
        {"ellib", janet_ellib, NULL},
        {"paint", janet_paint, NULL},
        {"tri", janet_tri, NULL},
        {"trib", janet_trib, NULL},
        {"ttri", janet_ttri, NULL},
        {"clip", janet_clip, NULL},
        {"music", janet_music, NULL},
        {"sync", janet_sync, NULL},
        {"vbank", janet_vbank, NULL},
        {"reset", janet_reset, NULL},
        {"key", janet_key, NULL},
        {"keyp", janet_keyp, NULL},
        {"keyr", janet_keyr, NULL},
        {"fget", janet_fget, NULL},
        {"fset", janet_fset, NULL},
        {"fft", janet_fft, NULL},
        {"ffts", janet_ffts, NULL},
        {"vqt", janet_vqt, NULL},
        {"vqts", janet_vqts, NULL},
        {"vqtr", janet_vqtr, NULL},
        {"vqtrs", janet_vqtrs, NULL},
        {"vqtw", janet_vqtw, NULL},
        {"vqtsw", janet_vqtsw, NULL},
        {"vqtrw", janet_vqtrw, NULL},
        {"vqtrsw", janet_vqtrsw, NULL},
        {"fftr", janet_fftr, NULL},
        {"fftrs", janet_fftrs, NULL},
        {"rrect", janet_rrect, NULL},
        {"rrectb", janet_rrectb, NULL},
        {NULL, NULL, NULL}};

static const char* const JanetKeywords[] =
    {
        "defmacro", "with-syms", "macex1", "macex",
        "do", "values", "break",
        "if", "when", "cond", "match",
        "each", "for", "loop", "while",
        "fn", "defn", "partial",
        "def", "var", "set", "defglobal", "let", "set", "put",
        "if-let", "when-let", "if-not",
        "or", "and", "true", "false", "nil", "not", "not=", "length",
        "brshift", "blshift", "bor", "band", "bnot", "bxor",
        "#", ":", "->", "->>", "-?>", "-?>>", "$",
        "quasiquote", "quote", "unquote", "upscope",
        "splice", ";"};

static JanetFiber* GameFiber = NULL;
static JanetBuffer* errBuffer;
static tic_core* CurrentMachine = NULL;

static inline tic_core* getJanetMachine(void)
{
    return CurrentMachine;
}

/* ***************** */

typedef struct
{
    s32 note;
    s32 octave;
} SFXNote;

static SFXNote tic_optsfxnote(Janet* argv, int32_t argc, int32_t n, SFXNote sfxNote)
{
    if(argc <= n)
    {
        return sfxNote;
    }
    else if(janet_checktype(argv[n], JANET_STRING))
    {
        const char* noteStr = janet_getcstring(argv, n);

        if(!parse_note(noteStr, &sfxNote.note, &sfxNote.octave))
        {
            janet_panicf("invalid note, should be like C#4, got %s\n", noteStr);
        }

        return sfxNote;
    }
    else
    {
        s32 id = janet_getinteger(argv, n);
        sfxNote.note = id % NOTES;
        sfxNote.octave = id / NOTES;
        return sfxNote;
    }
}

typedef struct
{
    u8 colors[TIC_PALETTE_SIZE];
    int32_t count;
} ColorKey;

static ColorKey tic_optcolorkey(Janet* argv, int32_t argc, int32_t n)
{
    ColorKey colorkey = {0};
    colorkey.count = 0;

    if(argc > n)
    {
        if(janet_checktypes(argv[n], JANET_TFLAG_INDEXED))
        {
            JanetView keys = janet_getindexed(argv, n);
            s32 list_count = keys.len;

            for(s32 i = 0; i < TIC_PALETTE_SIZE; i++)
            {
                if(i < list_count)
                {
                    colorkey.colors[i] = (u8)((s32)janet_getinteger(keys.items, i));
                    ;
                    colorkey.count++;
                }
                else
                {
                    break;
                }
            }
        }
        else if(janet_checkint(argv[n]))
        {
            colorkey.colors[0] = (u8)((s32)janet_getnumber(argv, n));
            colorkey.count = 1;
        }
        else
        {
            janet_panic("Error: colorkeys must be either int or list of int");
        }
    }

    return colorkey;
}

typedef struct
{
    float z[3];
    bool on;
} TriDepth;

static TriDepth tic_opttridepth(Janet* argv, int32_t argc, int32_t n)
{
    TriDepth depth = {0};
    depth.on = false;

    if(argc > n)
    {
        depth.on = true;

        depth.z[0] = (float)(janet_getnumber(argv, n));
        depth.z[1] = (float)(janet_getnumber(argv, n + 1));
        depth.z[2] = (float)(janet_getnumber(argv, n + 2));
    }

    return depth;
}

/* ***************** */

static Janet janet_print(int32_t argc, Janet* argv)
{
    janet_arity(argc, 1, 7);

    s32 x = 0;
    s32 y = 0;
    u8 color = 15;
    bool fixed = false;
    s32 scale = 1;
    bool alt = false;

    const char* text = janet_getcstring(argv, 0);
    if(argc >= 2) x = (s32)janet_getinteger(argv, 1);
    if(argc >= 3) y = (s32)janet_getinteger(argv, 2);
    if(argc >= 4) color = (u8)janet_getinteger(argv, 3);
    if(argc >= 5) fixed = janet_getboolean(argv, 4);
    if(argc >= 6) scale = (s32)janet_getinteger(argv, 5);
    if(argc >= 7) alt = janet_getboolean(argv, 6);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    int32_t width = core->api.print(tic, text, x, y, color, fixed, scale, alt);
    return janet_wrap_integer(width);
}

static Janet janet_cls(int32_t argc, Janet* argv)
{
    janet_arity(argc, 0, 1);
    u32 color = (u32)janet_optinteger(argv, argc, 0, 0);
    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.cls(tic, (u8)(color));
    return janet_wrap_nil();
}

static Janet janet_pix(int32_t argc, Janet* argv)
{
    janet_arity(argc, 2, 3);

    bool get;
    u8 color = 0;

    s32 x = (s32)janet_getinteger(argv, 0);
    s32 y = (s32)janet_getinteger(argv, 1);

    if(argc == 2)
    {
        get = true;
    }
    else
    {
        color = (u8)janet_getinteger(argv, 2);
        get = false;
    }

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_integer(core->api.pix(tic, x, y, color, get));
}

static Janet janet_line(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 5);

    float x1 = (float)janet_getnumber(argv, 0);
    float y1 = (float)janet_getnumber(argv, 1);
    float x2 = (float)janet_getnumber(argv, 2);
    float y2 = (float)janet_getnumber(argv, 3);
    u8 color = (u8)janet_getinteger(argv, 4);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.line(tic, x1, y1, x2, y2, color);
    return janet_wrap_nil();
}

static Janet janet_rect(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 5);

    s32 x = (s32)janet_getinteger(argv, 0);
    s32 y = (s32)janet_getinteger(argv, 1);
    s32 width = (s32)janet_getinteger(argv, 2);
    s32 height = (s32)janet_getinteger(argv, 3);
    u8 color = (u8)janet_getinteger(argv, 4);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.rect(tic, x, y, width, height, color);
    return janet_wrap_nil();
}

static Janet janet_rectb(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 5);

    s32 x = (s32)janet_getinteger(argv, 0);
    s32 y = (s32)janet_getinteger(argv, 1);
    s32 width = (s32)janet_getinteger(argv, 2);
    s32 height = (s32)janet_getinteger(argv, 3);
    u8 color = (u8)janet_getinteger(argv, 4);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.rectb(tic, x, y, width, height, color);
    return janet_wrap_nil();
}

static Janet janet_rrect(int32_t argc, Janet* argv)
{
    janet_arity(argc, 5, 7);

    s32 x = (s32)janet_getinteger(argv, 0);
    s32 y = (s32)janet_getinteger(argv, 1);
    s32 width = (s32)janet_getinteger(argv, 2);
    s32 height = (s32)janet_getinteger(argv, 3);
    u8 color = (u8)janet_getinteger(argv, 4);
    s32 radius = argc >= 6 ? (s32)janet_getinteger(argv, 5) : -1;
    float exponent = argc >= 7 ? (float)janet_getnumber(argv, 6) : 2.0f;

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.rrect(tic, x, y, width, height, color, radius, exponent);
    return janet_wrap_nil();
}

static Janet janet_rrectb(int32_t argc, Janet* argv)
{
    janet_arity(argc, 5, 7);

    s32 x = (s32)janet_getinteger(argv, 0);
    s32 y = (s32)janet_getinteger(argv, 1);
    s32 width = (s32)janet_getinteger(argv, 2);
    s32 height = (s32)janet_getinteger(argv, 3);
    u8 color = (u8)janet_getinteger(argv, 4);
    s32 radius = argc >= 6 ? (s32)janet_getinteger(argv, 5) : -1;
    float exponent = argc >= 7 ? (float)janet_getnumber(argv, 6) : 2.0f;

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.rrectb(tic, x, y, width, height, color, radius, exponent);
    return janet_wrap_nil();
}

static Janet janet_spr(int32_t argc, Janet* argv)
{
    janet_arity(argc, 3, 9);

    s32 index = (s32)janet_getinteger(argv, 0);
    s32 x = (s32)janet_getinteger(argv, 1);
    s32 y = (s32)janet_getinteger(argv, 2);

    ColorKey colorkey = tic_optcolorkey(argv, argc, 3);

    s32 scale = (s32)janet_optnumber(argv, argc, 4, 1);
    tic_flip flip = (s32)janet_optnumber(argv, argc, 5, tic_no_flip);
    tic_rotate rotate = (s32)janet_optnumber(argv, argc, 6, tic_no_rotate);
    s32 w = (s32)janet_optnumber(argv, argc, 7, 1);
    s32 h = (s32)janet_optnumber(argv, argc, 8, 1);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.spr(tic, index, x, y, w, h,
                  colorkey.colors, (u8)colorkey.count,
                  scale, flip, rotate);

    return janet_wrap_nil();
}

static Janet janet_btn(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 1);

    s32 id = (s32)janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_boolean(core->api.btn(tic, id));
}

static Janet janet_btnp(int32_t argc, Janet* argv)
{
    janet_arity(argc, 1, 3);

    s32 id = (s32)janet_getinteger(argv, 0);
    s32 hold = (s32)janet_optinteger(argv, argc, 1, -1);
    s32 period = (s32)janet_optinteger(argv, argc, 2, -1);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;

    return janet_wrap_boolean(core->api.btnp(tic, id, hold, period));
}

static Janet janet_btnr(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 1);

    s32 id = (s32)janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_boolean(core->api.btnr(tic, id));
}

static Janet janet_sfx(int32_t argc, Janet* argv)
{
    janet_arity(argc, 1, 6);
    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;

    s32 index = (s32)janet_getinteger(argv, 0);
    if(index >= SFX_COUNT)
    {
        janet_panicf("unknown sfx index, got %s\n", index);
    }

    // possibly get default values from sfx
    tic_sample* effect = tic->ram->sfx.samples.data + index;
    SFXNote defaultSfxNote = {-1, -1};
    s32 defaultSpeed = SFX_DEF_SPEED;
    if(index >= 0)
    {
        defaultSfxNote.note = effect->note;
        defaultSfxNote.octave = effect->octave;
        defaultSpeed = effect->speed;
    }

    SFXNote sfxNote = tic_optsfxnote(argv, argc, 1, defaultSfxNote);
    s32 duration = (s32)janet_optinteger(argv, argc, 2, -1);
    s32 channel = (s32)janet_optinteger(argv, argc, 3, 0);
    if(channel < 0 || channel > TIC_SOUND_CHANNELS)
    {
        janet_panicf("unknown channel, got %s\n", channel);
    }

    s32 volumes[TIC80_SAMPLE_CHANNELS] = {MAX_VOLUME, MAX_VOLUME};
    volumes[0] = (s32)janet_optinteger(argv, argc, 4, MAX_VOLUME);
    volumes[1] = volumes[0];

    s32 speed = (s32)janet_optinteger(argv, argc, 5, defaultSpeed);

    core->api.sfx(tic, index,
                  sfxNote.note, sfxNote.octave,
                  duration, channel,
                  volumes[0] & 0xf, volumes[1] & 0xf,
                  speed);
    return janet_wrap_nil();
}

static void remapCallback(void* data, s32 x, s32 y, RemapResult* result)
{
    JanetFunction* remap_fn = (JanetFunction*)data;

    Janet* argv = janet_tuple_begin(3);
    argv[0] = janet_wrap_integer(result->index);
    argv[1] = janet_wrap_integer(x);
    argv[2] = janet_wrap_integer(y);
    janet_tuple_end(argv);

    Janet jresult = janet_call(remap_fn, 3, argv);

    if(janet_checktypes(jresult, JANET_TFLAG_INDEXED))
    {
        const Janet* jresult_tuple = janet_unwrap_tuple(jresult);
        u8 retc = (u8)(janet_tuple_length(jresult_tuple));
        result->index = (u8)(janet_getinteger(jresult_tuple, 0));
        result->flip = janet_optinteger(jresult_tuple, retc, 1, 0);
        result->rotate = janet_optinteger(jresult_tuple, retc, 2, 0);
    }
    else if(janet_checkint(jresult))
    {
        result->index = (u8)(janet_unwrap_integer(jresult));
    }
}

static Janet janet_map(int32_t argc, Janet* argv)
{
    janet_arity(argc, 0, 9);

    s32 x = (s32)janet_optinteger(argv, argc, 0, 0);
    s32 y = (s32)janet_optinteger(argv, argc, 1, 0);

    s32 w = (s32)janet_optinteger(argv, argc, 2, 30);
    s32 h = (s32)janet_optinteger(argv, argc, 3, 17);

    s32 sx = (s32)janet_optinteger(argv, argc, 4, 0);
    s32 sy = (s32)janet_optinteger(argv, argc, 5, 0);

    ColorKey colorkey = tic_optcolorkey(argv, argc, 6);

    s32 scale = (s32)janet_optnumber(argv, argc, 7, 1);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;

    if(argc < 9)
    {
        core->api.map(tic, x, y, w, h, sx, sy,
                      colorkey.colors, (u8)colorkey.count,
                      scale, NULL, NULL);
    }
    else
    {
        JanetFunction* remap = janet_getfunction(argv, 8);
        core->api.map(tic, x, y, w, h, sx, sy,
                      colorkey.colors, (u8)colorkey.count,
                      scale,
                      remapCallback, remap);
    }

    return janet_wrap_nil();
}

static Janet janet_mget(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 2);

    s32 x = (s32)janet_getinteger(argv, 0);
    s32 y = (s32)janet_getinteger(argv, 1);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_integer(core->api.mget(tic, x, y));
}

static Janet janet_mset(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 3);

    s32 x = (s32)janet_getinteger(argv, 0);
    s32 y = (s32)janet_getinteger(argv, 1);
    u8 value = (u8)janet_getinteger(argv, 2);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.mset(tic, x, y, value);
    return janet_wrap_nil();
}

static Janet janet_peek(int32_t argc, Janet* argv)
{
    janet_arity(argc, 1, 2);
    s32 address = (s32)janet_getinteger(argv, 0);
    s32 bits = (s32)janet_optinteger(argv, argc, 1, BITS_IN_BYTE);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_integer(core->api.peek(tic, address, bits));
}

static Janet janet_poke(int32_t argc, Janet* argv)
{
    janet_arity(argc, 2, 3);
    s32 address = (s32)janet_getinteger(argv, 0);
    u8 value = (u8)((s32)janet_getinteger(argv, 1));
    s32 bits = (s32)janet_optinteger(argv, argc, 2, BITS_IN_BYTE);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.poke(tic, address, value, bits);

    return janet_wrap_nil();
}

static Janet janet_peek1(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 1);

    u8 address = (u8)janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_integer(core->api.peek1(tic, address));
}

static Janet janet_poke1(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 2);

    s32 address = (s32)janet_getinteger(argv, 0);
    u8 value = (u8)janet_getinteger(argv, 1);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.poke1(tic, address, value);
    return janet_wrap_nil();
}

static Janet janet_peek2(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 1);

    s32 address = janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_integer(core->api.peek2(tic, address));
}

static Janet janet_poke2(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 2);

    s32 address = janet_getinteger(argv, 0);
    u8 value = (u8)(janet_getinteger(argv, 1));

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.poke2(tic, address, value);
    return janet_wrap_nil();
}

static Janet janet_peek4(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 1);

    s32 address = janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_integer(core->api.peek4(tic, address));
}

static Janet janet_poke4(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 2);

    s32 address = janet_getinteger(argv, 0);
    u8 value = (u8)(janet_getinteger(argv, 1));

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.poke4(tic, address, value);
    return janet_wrap_nil();
}

static Janet janet_memcpy(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 3);

    s32 dst = janet_getinteger(argv, 0);
    s32 src = janet_getinteger(argv, 1);
    s32 size = janet_getinteger(argv, 2);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.memcpy(tic, dst, src, size);
    return janet_wrap_nil();
}

static Janet janet_memset(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 3);

    s32 dst = janet_getinteger(argv, 0);
    u8 val = (u8)(janet_getinteger(argv, 1));
    s32 size = janet_getinteger(argv, 2);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;

    core->api.memset(tic, dst, val, size);
    return janet_wrap_nil();
}

static Janet janet_trace(int32_t argc, Janet* argv)
{
    janet_arity(argc, 1, 2);
    u8 color = 15;

    const char* message = janet_getcstring(argv, 0);

    if(argc > 1)
    {
        color = (u8)(janet_getinteger(argv, 1));
    }

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.trace(tic, message, color);
    return janet_wrap_nil();
}

static Janet janet_pmem(int32_t argc, Janet* argv)
{
    janet_arity(argc, 1, 2);
    s32 index = janet_getinteger(argv, 0);

    if(index >= 0 && index < (s32)TIC_PERSISTENT_SIZE)
    {
        tic_core* core = getJanetMachine();
        tic_mem* tic = (tic_mem*)core;
        u32 val = core->api.pmem(tic, index, 0, false);

        if(argc >= 2)
        {
            u32 value = janet_getinteger(argv, 1);
            core->api.pmem(tic, index, value, true);
        }

        return janet_wrap_integer(val);
    }
    else
    {
        janet_panic("Error: invalid persistent tic index");
    }
}

static Janet janet_time(int32_t argc, Janet* argv)
{
    (void)argv;
    janet_fixarity(argc, 0);
    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_number(core->api.time(tic));
}

static Janet janet_tstamp(int32_t argc, Janet* argv)
{
    (void)argv;
    janet_fixarity(argc, 0);
    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_integer(core->api.tstamp(tic));
}

static Janet janet_exit(int32_t argc, Janet* argv)
{
    (void)argv;
    janet_fixarity(argc, 0);
    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.exit(tic);
    return janet_wrap_nil();
}

static Janet janet_font(int32_t argc, Janet* argv)
{
    janet_arity(argc, 3, 9);

    const char* text = janet_getcstring(argv, 0);
    s32 x = (s32)janet_getinteger(argv, 1);
    s32 y = (s32)janet_getinteger(argv, 2);

    u8 chromakey = (u8)janet_optinteger(argv, argc, 3, 0);
    s32 w = (s32)janet_optinteger(argv, argc, 4, 0);
    s32 h = (s32)janet_optinteger(argv, argc, 5, 0);
    bool fixed = janet_optboolean(argv, argc, 6, false);
    s32 scale = (s32)janet_optinteger(argv, argc, 7, 1);
    bool alt = janet_optboolean(argv, argc, 8, false);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    int32_t width = core->api.font(tic,
                                   text, x, y, &chromakey, 1,
                                   w, h, fixed, scale, alt);
    return janet_wrap_integer(width);
}

static Janet janet_mouse(int32_t argc, Janet* argv)
{
    (void)argv;
    janet_fixarity(argc, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    Janet result[7];

    {
        tic_point point = core->api.mouse(tic);
        result[0] = janet_wrap_integer(point.x);
        result[1] = janet_wrap_integer(point.y);
    }

    const tic80_mouse* mouse = &tic->ram->input.mouse;
    result[2] = janet_wrap_boolean(mouse->left);
    result[3] = janet_wrap_boolean(mouse->middle);
    result[4] = janet_wrap_boolean(mouse->right);
    result[5] = janet_wrap_number(mouse->scrollx);
    result[6] = janet_wrap_number(mouse->scrolly);

    return janet_wrap_tuple(janet_tuple_n(result, 7));
}

static Janet janet_circ(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 4);

    s32 x = janet_getinteger(argv, 0);
    s32 y = janet_getinteger(argv, 1);
    s32 radius = janet_getinteger(argv, 2);
    u8 color = (u8)(janet_getinteger(argv, 3));

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.circ(tic, x, y, radius, color);
    return janet_wrap_nil();
}

static Janet janet_circb(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 4);

    s32 x = janet_getinteger(argv, 0);
    s32 y = janet_getinteger(argv, 1);
    s32 radius = janet_getinteger(argv, 2);
    u8 color = (u8)(janet_getinteger(argv, 3));

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.circb(tic, x, y, radius, color);
    return janet_wrap_nil();
}

static Janet janet_elli(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 5);

    s32 x = janet_getinteger(argv, 0);
    s32 y = janet_getinteger(argv, 1);
    s32 a = janet_getinteger(argv, 2);
    s32 b = janet_getinteger(argv, 3);
    u8 color = (u8)(janet_getinteger(argv, 4));

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.elli(tic, x, y, a, b, color);
    return janet_wrap_nil();
}

static Janet janet_ellib(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 5);

    s32 x = janet_getinteger(argv, 0);
    s32 y = janet_getinteger(argv, 1);
    s32 a = janet_getinteger(argv, 2);
    s32 b = janet_getinteger(argv, 3);
    u8 color = (u8)(janet_getinteger(argv, 4));

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.ellib(tic, x, y, a, b, color);
    return janet_wrap_nil();
}

static Janet janet_paint(int32_t argc, Janet* argv)
{
    janet_arity(argc, 3, 4);

    s32 x = janet_getinteger(argv, 0);
    s32 y = janet_getinteger(argv, 1);
    u8 color = (u8)(janet_getinteger(argv, 2));
    u8 bordercolor = (u8)(janet_optnumber(argv, argc, 3, 255));

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.paint(tic, x, y, color, bordercolor);
    return janet_wrap_nil();
}

static Janet janet_tri(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 7);

    float x1 = (float)(janet_getnumber(argv, 0));
    float y1 = (float)(janet_getnumber(argv, 1));
    float x2 = (float)(janet_getnumber(argv, 2));
    float y2 = (float)(janet_getnumber(argv, 3));
    float x3 = (float)(janet_getnumber(argv, 4));
    float y3 = (float)(janet_getnumber(argv, 5));
    u8 color = (u8)(janet_getnumber(argv, 6));

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.tri(tic, x1, y1, x2, y2, x3, y3, color);
    return janet_wrap_nil();
}

static Janet janet_trib(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 7);

    float x1 = (float)(janet_getnumber(argv, 0));
    float y1 = (float)(janet_getnumber(argv, 1));
    float x2 = (float)(janet_getnumber(argv, 2));
    float y2 = (float)(janet_getnumber(argv, 3));
    float x3 = (float)(janet_getnumber(argv, 4));
    float y3 = (float)(janet_getnumber(argv, 5));
    u8 color = (u8)(janet_getnumber(argv, 6));

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.trib(tic, x1, y1, x2, y2, x3, y3, color);
    return janet_wrap_nil();
}

static Janet janet_ttri(int32_t argc, Janet* argv)
{
    janet_arity(argc, 12, 17);

    float x1 = (float)(janet_getnumber(argv, 0));
    float y1 = (float)(janet_getnumber(argv, 1));
    float x2 = (float)(janet_getnumber(argv, 2));
    float y2 = (float)(janet_getnumber(argv, 3));
    float x3 = (float)(janet_getnumber(argv, 4));
    float y3 = (float)(janet_getnumber(argv, 5));

    float u1 = (float)(janet_getnumber(argv, 6));
    float v1 = (float)(janet_getnumber(argv, 7));
    float u2 = (float)(janet_getnumber(argv, 8));
    float v2 = (float)(janet_getnumber(argv, 9));
    float u3 = (float)(janet_getnumber(argv, 10));
    float v3 = (float)(janet_getnumber(argv, 11));

    tic_texture_src src = tic_tiles_texture;

    if(argc > 12)
    {
        if(janet_checktypes(argv[12], JANET_TFLAG_BOOLEAN))
        {
            if(janet_getboolean(argv, 12))
            {
                src = tic_map_texture;
            }
        }
        else if(janet_checktypes(argv[12], JANET_TFLAG_NUMBER))
        {
            src = janet_getinteger(argv, 12);
        }
    }

    ColorKey trans = tic_optcolorkey(argv, argc, 13);
    TriDepth depth = tic_opttridepth(argv, argc, 14);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.ttri(tic,
                   x1, y1,
                   x2, y2,
                   x3, y3,
                   u1, v1,
                   u2, v2,
                   u3, v3,
                   src,
                   trans.colors, trans.count,
                   depth.z[0], depth.z[1], depth.z[2], depth.on);

    return janet_wrap_nil();
}

static Janet janet_clip(int32_t argc, Janet* argv)
{
    janet_arity(argc, 0, 4);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;

    if(argc == 0)
    {
        core->api.clip(tic, 0, 0, TIC80_WIDTH, TIC80_HEIGHT);
    }
    else if(argc == 4)
    {
        s32 x = janet_getinteger(argv, 0);
        s32 y = janet_getinteger(argv, 1);
        s32 w = janet_getinteger(argv, 2);
        s32 h = janet_getinteger(argv, 3);
        core->api.clip(tic, x, y, w, h);
    }
    else
    {
        janet_panic("Error: must provide exactly 0 or 4 args.");
    }

    return janet_wrap_nil();
}

static Janet janet_music(int32_t argc, Janet* argv)
{
    janet_arity(argc, 0, 7);

    s32 track = janet_optinteger(argv, argc, 0, -1);
    s32 frame = janet_optinteger(argv, argc, 1, -1);
    s32 row = janet_optinteger(argv, argc, 2, -1);
    bool loop = janet_optboolean(argv, argc, 3, true);
    bool sustain = janet_optboolean(argv, argc, 4, true);
    s32 tempo = janet_optinteger(argv, argc, 5, -1);
    s32 speed = janet_optinteger(argv, argc, 6, -1);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.music(tic, track, frame, row, loop, sustain, tempo, speed);

    return janet_wrap_nil();
}

static Janet janet_sync(int32_t argc, Janet* argv)
{
    janet_arity(argc, 0, 3);

    u32 mask = janet_optinteger(argv, argc, 0, 0);
    s32 bank = janet_optinteger(argv, argc, 1, 0);
    bool toCart = janet_optboolean(argv, argc, 2, false);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.sync(tic, mask, bank, toCart);
    return janet_wrap_nil();
}

static Janet janet_vbank(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 1);

    s32 bank = janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_integer(core->api.vbank(tic, bank));
}

static Janet janet_reset(int32_t argc, Janet* argv)
{
    (void)argv;
    janet_fixarity(argc, 0);
    tic_core* machine = getJanetMachine();
    machine->state.initialized = false;
    return janet_wrap_nil();
}

static Janet janet_key(int32_t argc, Janet* argv)
{
    janet_arity(argc, 0, 1);
    tic_key key = (tic_key)-1;

    if(argc >= 1) key = (tic_key)janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_boolean(core->api.key(tic, key));
}

static Janet janet_keyp(int32_t argc, Janet* argv)
{
    janet_arity(argc, 0, 3);
    tic_key key = (tic_key)-1;
    s32 hold = -1;
    s32 period = -1;

    if(argc >= 1) key = (tic_key)janet_getinteger(argv, 0);
    if(argc >= 2) hold = janet_getinteger(argv, 1);
    if(argc >= 3) period = janet_getinteger(argv, 2);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_boolean(core->api.keyp(tic, key, hold, period));
}

static Janet janet_keyr(int32_t argc, Janet* argv)
{
    janet_arity(argc, 0, 1);
    tic_key key = (tic_key)-1;

    if(argc >= 1) key = (tic_key)janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_boolean(core->api.keyr(tic, key));
}

static Janet janet_fget(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 2);

    s32 index = janet_getinteger(argv, 0);
    u8 flag = (u8)(janet_getinteger(argv, 1));

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_boolean(core->api.fget(tic, index, flag));
}

static Janet janet_fset(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 3);

    s32 index = janet_getinteger(argv, 0);
    u8 flag = (u8)(janet_getinteger(argv, 1));
    bool value = janet_getboolean(argv, 2);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    core->api.fset(tic, index, flag, value);
    return janet_wrap_nil();
}

static Janet janet_vqt(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 1);

    s32 bin = janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_number(core->api.vqt(tic, bin));
}

static Janet janet_vqts(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 1);

    s32 bin = janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_number(core->api.vqts(tic, bin));
}

static Janet janet_vqtr(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 1);

    s32 bin = janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_number(core->api.vqtr(tic, bin));
}

static Janet janet_vqtrs(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 1);

    s32 bin = janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_number(core->api.vqtrs(tic, bin));
}

static Janet janet_vqtw(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 1);

    s32 bin = janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_number(core->api.vqtw(tic, bin));
}

static Janet janet_vqtsw(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 1);

    s32 bin = janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_number(core->api.vqtsw(tic, bin));
}

static Janet janet_vqtrw(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 1);

    s32 bin = janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_number(core->api.vqtrw(tic, bin));
}

static Janet janet_vqtrsw(int32_t argc, Janet* argv)
{
    janet_fixarity(argc, 1);

    s32 bin = janet_getinteger(argv, 0);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_number(core->api.vqtrsw(tic, bin));
}

static Janet janet_fft(int32_t argc, Janet* argv)
{
    janet_arity(argc, 1, 2);

    s32 start_freq = -1;
    s32 end_freq = -1;

    if(argc >= 1) start_freq = janet_getinteger(argv, 0);
    if(argc >= 2) end_freq = janet_getinteger(argv, 1);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_number(core->api.fft(tic, start_freq, end_freq));
}

static Janet janet_fftr(int32_t argc, Janet* argv)
{
    janet_arity(argc, 1, 2);

    s32 start_freq = -1;
    s32 end_freq = -1;

    if(argc >= 1) start_freq = janet_getinteger(argv, 0);
    if(argc >= 2) end_freq = janet_getinteger(argv, 1);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_number(core->api.fftr(tic, start_freq, end_freq));
}

static Janet janet_fftrs(int32_t argc, Janet* argv)
{
    janet_arity(argc, 1, 2);

    s32 start_freq = -1;
    s32 end_freq = -1;

    if(argc >= 1) start_freq = janet_getinteger(argv, 0);
    if(argc >= 2) end_freq = janet_getinteger(argv, 1);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_number(core->api.fftrs(tic, start_freq, end_freq));
}

static Janet janet_ffts(int32_t argc, Janet* argv)
{
    janet_arity(argc, 1, 2);

    s32 start_freq = -1;
    s32 end_freq = -1;

    if(argc >= 1) start_freq = janet_getinteger(argv, 0);
    if(argc >= 2) end_freq = janet_getinteger(argv, 1);

    tic_core* core = getJanetMachine();
    tic_mem* tic = (tic_mem*)core;
    return janet_wrap_number(core->api.fft(tic, start_freq, end_freq));
}

/* ***************** */
static void reportError(tic_core* core, Janet result)
{
    janet_stacktrace(GameFiber, result);
    janet_buffer_push_u8(errBuffer, 0);
    core->data->error(core->data->data, (char*)errBuffer->data);
}

static void closeJanet(tic_mem* tic)
{
    tic_core* core = (tic_core*)tic;

    if(core->currentVM)
    {
        janet_deinit();
        core->currentVM = NULL;
        CurrentMachine = NULL;
        errBuffer = NULL;
        GameFiber = NULL;
    }
}

static bool initJanet(tic_mem* tic, const char* code)
{
    closeJanet(tic);
    janet_init();
    janet_sandbox(JANET_SANDBOX_ALL);

    JanetTable* sub_env = janet_table(0);
    janet_cfuns(sub_env, "tic80", janet_c_functions);

    // Provide the tic80 api as a module
    Janet module_cache = janet_resolve_core("module/cache");
    janet_table_put(janet_unwrap_table(module_cache), janet_cstringv("tic80"), janet_wrap_table(sub_env));

    tic_core* core = (tic_core*)tic;
    CurrentMachine = core;
    core->currentVM = (JanetTable*)janet_core_env(NULL);

    // override the dynamic err to a buffer, so that we can get errors later
    errBuffer = janet_buffer(1028);
    janet_setdyn("err", janet_wrap_buffer(errBuffer));

    GameFiber = janet_current_fiber();
    Janet result;

    // Load the game source code
    if(janet_dostring(core->currentVM, code, "main", &result))
    {
        reportError(core, result);
        return false;
    }

    return true;
}

static void evalJanet(tic_mem* tic, const char* code)
{
    tic_core* core = (tic_core*)tic;

    Janet result = janet_wrap_nil();
    if(janet_dostring(core->currentVM, code, "main", &result))
    {
        reportError(core, result);
    }
}

/*
 * Find a function called TIC_FN and execute it. If we can't find it, then
 * it is a problem.
 */
static void callJanetTick(tic_mem* tic)
{
    tic_core* core = (tic_core*)tic;

    // Load the TIC function
    Janet pre_fn;
    (void)janet_resolve(core->currentVM, janet_csymbol(TIC_FN), &pre_fn);

    if(janet_type(pre_fn) != JANET_FUNCTION)
    {
        core->data->error(core->data->data, "(TIC) isn't found :(");
        return;
    }

    JanetFunction* tic_fn = janet_unwrap_function(pre_fn);
    Janet result = janet_wrap_nil();
    JanetSignal status = janet_pcall(tic_fn, 0, NULL, &result, &GameFiber);

    if(status != JANET_SIGNAL_OK)
    {
        reportError(core, result);
    }

#if defined(BUILD_DEPRECATED)
    // call OVR() callback for backward compatibility
    (void)janet_resolve(core->currentVM, janet_csymbol(OVR_FN), &pre_fn);
    if(janet_type(pre_fn) == JANET_FUNCTION)
    {
        JanetFunction* ovr_fn = janet_unwrap_function(pre_fn);
        JanetSignal callStatus = janet_pcall(ovr_fn, 0, NULL, &result, &GameFiber);

        if(callStatus != JANET_SIGNAL_OK)
        {
            reportError(core, result);
        }
    }
#endif
}

/*
 * Find a function called BOOT_FN and execute it. If we can't find it, then
 * it's not a problem.
 */
static void callJanetBoot(tic_mem* tic)
{
    tic_core* core = (tic_core*)tic;

#if defined(BUILD_RENDER_CACHE)
    Janet scn_fn, bdr_fn, old_scn;
    bool has_scn = (janet_resolve(core->currentVM, janet_csymbol(SCN_FN), &scn_fn) && janet_type(scn_fn) == JANET_FUNCTION) ||
                   (janet_resolve(core->currentVM, janet_csymbol("scanline"), &old_scn) && janet_type(old_scn) == JANET_FUNCTION);
    bool has_bdr = janet_resolve(core->currentVM, janet_csymbol(BDR_FN), &bdr_fn) && janet_type(bdr_fn) == JANET_FUNCTION;

    core->state.has_scn = has_scn;
    core->state.has_bdr = has_bdr;
#endif

    Janet pre_fn;
    (void)janet_resolve(core->currentVM, janet_csymbol(BOOT_FN), &pre_fn);

    if(janet_type(pre_fn) != JANET_FUNCTION)
    {
        return;
    }

    Janet result = janet_wrap_nil();
    JanetFunction* boot_fn = janet_unwrap_function(pre_fn);
    JanetSignal status = janet_pcall(boot_fn, 0, NULL, &result, &GameFiber);

    if(status != JANET_SIGNAL_OK)
    {
        reportError(core, result);
    }
}

/*
 * Find a function with the given name and execute it with the given value.
 * If we can't find it, then it's not a problem.
 */
static void callJanetIntCallback(tic_mem* tic, s32 value, void* data, const char* name)
{
    (void)data;
    tic_core* core = (tic_core*)tic;

    Janet pre_fn;
    (void)janet_resolve(core->currentVM, janet_csymbol(name), &pre_fn);

    if(janet_type(pre_fn) != JANET_FUNCTION)
    {
        return;
    }

    Janet result = janet_wrap_nil();
    Janet argv[] = {
        janet_wrap_integer(value),
    };
    JanetFunction* fn = janet_unwrap_function(pre_fn);
    JanetSignal status = janet_pcall(fn, 1, argv, &result, &GameFiber);

    if(status != JANET_SIGNAL_OK)
    {
        reportError(core, result);
    }
}

static void callJanetScanline(tic_mem* tic, s32 row, void* data)
{
    callJanetIntCallback(tic, row, data, SCN_FN);
    callJanetIntCallback(tic, row, data, "scanline");
}

static void callJanetBorder(tic_mem* tic, s32 row, void* data)
{
    callJanetIntCallback(tic, row, data, BDR_FN);
}

static void callJanetMenu(tic_mem* tic, s32 index, void* data)
{
    callJanetIntCallback(tic, index, data, MENU_FN);
}

static const tic_outline_item* getJanetOutline(const char* code, s32* size)
{
    enum
    {
        Size = sizeof(tic_outline_item)
    };

    *size = 0;

    static tic_outline_item* items = NULL;

    if(items)
    {
        free(items);
        items = NULL;
    }

    const char* ptr = code;

    while(true)
    {
        static const char FuncString[] = "(defn ";

        ptr = strstr(ptr, FuncString);

        if(ptr)
        {
            ptr += sizeof FuncString - 1;

            const char* start = ptr;
            const char* end = start;

            while(*ptr)
            {
                char c = *ptr;

                if(c == ' ' || c == '\t' || c == '\n' || c == '[')
                {
                    end = ptr;
                    break;
                }

                ptr++;
            }

            if(end > start)
            {
                items = realloc(items, (*size + 1) * Size);

                items[*size].pos = start;
                items[*size].size = (s32)(end - start);

                (*size)++;
            }
        }
        else
            break;
    }

    return items;
}

static const u8 DemoRom[] =
    {
#include "../build/assets/janetdemo.tic.dat"
};

static const u8 MarkRom[] =
    {
#include "../build/assets/janetmark.tic.dat"
};

TIC_EXPORT const tic_script EXPORT_SCRIPT(Janet) =
    {
        .id = 18,
        .name = "janet",
        .fileExtension = ".janet",
        .projectComment = "#",
        .init = initJanet,
        .close = closeJanet,
        .tick = callJanetTick,
        .boot = callJanetBoot,

        .callback =
            {
                .scanline = callJanetScanline,
                .border = callJanetBorder,
                .menu = callJanetMenu,
            },

        .getOutline = getJanetOutline,
        .eval = evalJanet,

        .blockCommentStart = NULL,
        .blockCommentEnd = NULL,
        .blockCommentStart2 = NULL,
        .blockCommentEnd2 = NULL,
        .singleComment = "#",
        .blockStringStart = NULL,
        .blockStringEnd = NULL,
        .blockEnd = NULL,

        .keywords = JanetKeywords,
        .keywordsCount = COUNT_OF(JanetKeywords),

        .demo = {DemoRom, sizeof DemoRom, NULL},
        .mark = {MarkRom, sizeof MarkRom, "janetmark.tic"},
};
