// MIT License

// Copyright (c) 2017 Vadim Grigoruk @nesbox // grigoruk@gmail.com

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#include "console.h"
#include "studio/keyboard.h"
#include "studio/mouse.h"
#include "studio/ui.h"
#include "start.h"
#include "tools.h"
#include "tilesheet.h"
#include "studio/embed.h"
#include "studio/fs.h"
#include "studio/net.h"
#include "ext/png.h"
#include "ext/json.h"
#include "zip.h"
#include "retro_endianness.h"
#include "runtime_versions.h"

#if defined(TIC80_PRO)
#include "studio/project.h"
#else
#include "cart.h"
#endif

#include <ctype.h>
#include <string.h>

#if !defined(__TIC_MACOSX__)
#include <malloc.h>
#endif

#include <sys/stat.h>

#if defined(__TIC_WINDOWS__)
// msvc keeps chmod in io.h; sys/stat.h has the mode macros alone
#include <io.h>
#endif

#if defined(__EMSCRIPTEN__)
#include <emscripten.h>
#endif

#define CONSOLE_CURSOR_COLOR        tic_color_red
#define CONSOLE_INPUT_COLOR         tic_color_white
#define CONSOLE_BACK_TEXT_COLOR     tic_color_grey
#define CONSOLE_FRONT_TEXT_COLOR    tic_color_light_grey
#define CONSOLE_ERROR_TEXT_COLOR    tic_color_red
#define CONSOLE_LINK_TEXT_COLOR     tic_color_blue
#define CONSOLE_CURSOR_BLINK_PERIOD TIC80_FRAMERATE
#define CONSOLE_CURSOR_DELAY        (TIC80_FRAMERATE / 2)
#define CONSOLE_BUFFER_WIDTH        (STUDIO_TEXT_BUFFER_WIDTH)
#define CONSOLE_BUFFER_HEIGHT       (STUDIO_TEXT_BUFFER_HEIGHT)
#define CONSOLE_BUFFER_SCREENS      64
#define CONSOLE_BUFFER_SCREEN       (CONSOLE_BUFFER_WIDTH * CONSOLE_BUFFER_HEIGHT)
#define CONSOLE_BUFFER_SIZE         (CONSOLE_BUFFER_SCREEN * CONSOLE_BUFFER_SCREENS)
#define CONSOLE_BUFFER_ROWS         (CONSOLE_BUFFER_SIZE / CONSOLE_BUFFER_WIDTH)
#define DEFAULT_CHMOD               0755

// clang-format off
#define IMPORT_CMD_LIST(macro)  \
    macro(binary)               \
    macro(tiles)                \
    macro(sprites)              \
    macro(map)                  \
    macro(code)                 \
    macro(screen)
// clang-format on

// clang-format off
#define IMPORT_KEYS_LIST(macro) \
    macro(bank)                 \
    macro(x)                    \
    macro(y)                    \
    macro(w)                    \
    macro(h)                    \
    macro(vbank)                \
    macro(bpp)
// clang-format on

#if defined(TIC80_PRO)
#define ALONE_KEY(macro) macro(alone)
#else
#define ALONE_KEY(macro)
#endif

// clang-format off
#define EXPORT_KEYS_LIST(macro) \
    macro(bank)                 \
    macro(vbank)                \
    macro(id)                   \
    ALONE_KEY(macro)
// clang-format on

static const char* WelcomeText =
    "TIC-80 is a fantasy computer for making, playing and sharing tiny games.\n\n"
    "It has built-in tools for development: code, sprites, maps, sound editors and the command line, "
    "which is enough to create a mini retro game.\n"
    "In the end, you will get a cartridge file, which can be stored and played on the website.\n\n"
    "Also, the game can be packed into a player that works on all popular platforms and distributed as you wish.\n"
    "To make a retro-style game, the whole creation process takes place under some technical limitations: "
    "240x136 pixels display, 16 color palette, 256 8x8 color sprites, 4 channel sound, etc.";

static const struct SpecRow
{
    const char* section;
    const char* info;
} SpecText1[] =
    {
        {"DISPLAY", "240x136 pixels, 16 colors palette."},
        {"INPUT", "4 gamepads with 8 buttons / mouse / keyboard."},
        {"SPRITES", "256 8x8 tiles and 256 8x8 sprites."},
        {"MAP", "240x136 cells, 1920x1088 pixels."},
        {"SOUND", "4 channels with configurable waveforms."},
        {
            "CODE",
            "64KB of $LANG_NAMES$.",
        },
};

static const struct HotkeysRowGeneral
{
    const char* section;
    const char* info;
} HotkeysTextGeneral[] =
    {
        {"CTRL+R/ENTER", "Run current project."},
        {"CTRL+S", "Save cart."},
        {"CTRL+X/C/V", "Cut/copy/paste in the editors."},
        {"CTRL+Z/Y", "Undo/redo changes in the editors."},
        {"F6", "Toggle CRT filter."},
        {"F7", "Assign cover image while in game."},
        {"F8", "Take a screenshot."},
        {"F9", "Start/stop GIF video recording."},
        {"F10", "Focus the menu bar."},
        {"F11/ALT+ENTER", "Fullscreen/window mode."},
        {
            "CTRL+Q",
            "Quit the application.",
        },
};

static const struct HotkeysRowNavigation
{
    const char* section;
    const char* info;
} HotkeysTextNavigation[] =
    {
        {"ESC", "Switch console/editor or open menu while in game."},
        {"ESC+F1", "Switch to code editor while in game."},
        {"ALT+~", "Show console."},
        {"ALT+1/F1", "Show code editor."},
        {"ALT+2/F2", "Show sprite editor."},
        {"ALT+3/F3", "Show map editor."},
        {"ALT+4/F4", "Show sfx editor."},
        {"ALT+5/F5", "Show music editor."},
        {
            "CTRL+PGUP/PGDOWN",
            "Switch to previous/next editor mode.",
        },
};

static const struct HotkeysRowCodeEditor
{
    const char* section;
    const char* info;
} HotkeysTextCodeEditor[] =
    {
        {"CTRL+F", "Find."},
        {"CTRL+G", "Go to line."},
        {"CTRL+P/N", "Move to previous/next line."},
        {"ALT/CTRL+LEFT", "Move to previous word."},
        {"ALT/CTRL+RIGHT", "Move to next word."},
        {"ALT/CTRL+BACKSPACE", "Delete previous word."},
        {"ALT/CTRL+DELETE", "Delete next word."},
        {"CTRL+K", "Delete end of line."},
        {"CTRL+D", "Duplicate current line."},
        {"CTRL+J", "Newline."},
        {"CTRL+A", "Select all."},
        {"CTRL+F1", "Bookmark current line."},
        {"F1", "Move to next bookmark."},
        {"CTRL+B", "Show bookmark list."},
        {"CTRL+O", "Show code outline and navigate functions."},
        {"CTRL+TAB", "Indent line."},
        {"CTRL+SHIFT+TAB", "Unindent line."},
        {"CTRL+/", "Comment/Uncomment line."},
        {"RIGHT CLICK", "Drag."},
        {"SCROLL WHEEL", "Vertical scrolling."},
        {"SHIFT+SCROLL WHEEL", "Horizontal scrolling."},
        {
            "CTRL+L",
            "Center screen on cursor.",
        },
};

static const struct HotkeysRowSpriteEditor
{
    const char* section;
    const char* info;
} HotkeysTextSpriteEditor[] =
    {
        {"TAB", "Switch tiles/sprites."},
        {"CTRL+LEFT/RIGHT", "Switch sheet page."},
        {"[]", "Choose previous/next palette color."},
        {"-/=", "Change brush size."},
        {"SCROLL", "Canvas zoom."},
        {"1", "Select brush."},
        {"2", "Select color picker."},
        {"3", "Select selection tool."},
        {"4", "Select filling tool."},
        {"5", "Flip horizontally."},
        {"6", "Flip vertically."},
        {"7", "Rotate."},
        {
            "8/DELETE",
            "Erase.",
        },
};

static const struct HotkeysRowMapEditor
{
    const char* section;
    const char* info;
} HotkeysTextMapEditor[] =
    {
        {"SHIFT", "Show tilesheet."},
        {"CTRL+CLICK", "Replace all identical tiles (when the Fill tool [4] is selected)."},
        {"`", "Show/hide grid."},
        {"TAB/SCROLL", "Switch to full world map."},
        {"1", "Select draw."},
        {"2", "Select drag map."},
        {"3", "Select selection tool."},
        {
            "4",
            "Select filling tool.",
        },
};

static const struct HotkeysRowSFXEditor
{
    const char* section;
    const char* info;
} HotkeysTextSFXEditor[] =
    {
        {"SPACE", "Play last played note."},
        {"Z,X,C,V,B,N,M", "Play notes corresponding to one octave (bottom row of QWERTY layout)."},
        {
            "S,D,G,H,J",
            "Play notes corresponding to sharps and flats (home row of QWERTY layout).",
        },
};

static const struct HotkeysRowMusicEditor
{
    const char* section;
    const char* info;
} HotkeysTextMusicEditor[] =
    {
        {"SHIFT+ENTER", "Play pattern from cursor position in the music editor."},
        {"ENTER", "Play frame."},
        {"SPACE", "Play track."},
        {"SHIFT+SPACE", "Reset track."},
        {"CTRL+F", "Follow."},
        {"Z,X,C,V,B,N,M", "Play notes corresponding to one octave (bottom row of QWERTY layout) in tracker mode."},
        {"S,D,G,H,J", "Play notes corresponding to sharps and flats (home row of QWERTY layout) in tracker mode."},
        {"A", "Insert note break (or 'stop')."},
        {"DELETE", "Delete selection / selected row."},
        {"BACKSPACE", "Delete the row above."},
        {"INSERT", "Insert rows below."},
        {"CTRL+F1", "Decrease notes by Semitone."},
        {"CTRL+F2", "Increase notes by Semitone."},
        {"CTRL+F3", "Decrease octaves."},
        {"CTRL+F4", "Increase octaves."},
        {"CTRL+RIGHT", "Jump forward one frame."},
        {"CTRL+LEFT", "Jump backward one frame."},
        {"TAB", "Go to next channel."},
        {"SHIFT+TAB", "Go to previous channel."},
        {"+", "Next pattern."},
        {"-", "Previous pattern."},
        {"CTRL+UP", "Next instrument."},
        {"CTRL+DOWN", "Previous instrument."},
        {
            "F5",
            "Switch piano/tracker mode.",
        },
};

static const char* TermsText =
    "## Terms of Use\n"
    "- All cartridges posted on the " TIC_WEBSITE " website are the property of their authors.\n"
    "- Do not redistribute the cartridge without permission, directly from the author.\n"
    "- By uploading cartridges to the site, you grant Nesbox the right to freely use and distribute them. "
    "All other rights by default remain with the author.\n"
    "- Do not post material that violates copyright, obscenity or any other laws.\n"
    "- Nesbox reserves the right to remove or filter any material without prior notice.\n\n"
    "## Privacy Policy\n"
    "We store only the user's email and password in encrypted form and will not transfer any personal "
    "information to third parties without explicit permission.";

static const char* LicenseText =
    "## MIT License\n"
    "\n"
    "Copyright (c) 2017-" TIC_VERSION_YEAR " Vadim Grigoruk @nesbox // grigoruk@gmail.com\n"
    "\n"
    "Permission is hereby granted, free of charge, to any person obtaining a copy "
    "of this software and associated documentation files (the 'Software'), to deal "
    "in the Software without restriction, including without limitation the rights "
    "to use, copy, modify, merge, publish, distribute, sublicense, and/or sell "
    "copies of the Software, and to permit persons to whom the Software is "
    "furnished to do so, subject to the following conditions: "
    "The above copyright notice and this permission notice shall be included in all "
    "copies or substantial portions of the Software.\n"
    "\n"
    "THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR "
    "IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, "
    "FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE "
    "AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER "
    "LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, "
    "OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE "
    "SOFTWARE.";

static const struct StartupOption
{
    const char* name;
    const char* help;
} StartupOptions[] =
    {
#define CMD_PARAMS_DEF(name, ctype, type, post, help) {#name post, help},
        CMD_PARAMS_LIST(CMD_PARAMS_DEF)
#undef CMD_PARAMS_DEF
};

struct CommandDesc
{
    char* command;

    struct Param
    {
        char* key;
        char* val;
    }* params;

    s32 count;

    char* src;
};

static const char* PngExt = PNG_EXT;

#if defined(__EMSCRIPTEN__)
#define CAN_ADDGET_FILE 1
#endif

// You must free the result if result is non-NULL. TODO: find a better place for this function?
char* str_replace(const char* orig, char* rep, char* with)
{
    char* result;    // the return string
    const char* ins; // the next insert point
    char* tmp;       // varies
    s32 len_rep;     // length of rep (the string to remove)
    s32 len_with;    // length of with (the string to replace rep with)
    s32 len_front;   // distance between rep and end of last rep
    s32 count;       // number of replacements

    // sanity checks and initialization
    if(!orig || !rep)
        return NULL;
    len_rep = (s32)(strlen(rep));
    if(len_rep == 0)
        return NULL; // empty rep causes infinite loop during count
    if(!with)
        with = "";
    len_with = (s32)(strlen(with));

    // count the number of replacements needed
    ins = orig;
    for(count = 0; (tmp = strstr(ins, rep)); ++count)
    {
        ins = tmp + len_rep;
    }

    tmp = result = malloc(strlen(orig) + (len_with - len_rep) * count + 1);

    if(!result)
        return NULL;

    // first time through the loop, all the variable are set correctly
    // from here on,
    //    tmp points to the end of the result string
    //    ins points to the next occurrence of rep in orig
    //    orig points to the remainder of orig after "end of rep"
    while(count--)
    {
        ins = strstr(orig, rep);
        len_front = (s32)(ins - orig);
        tmp = strncpy(tmp, orig, len_front) + len_front;
        tmp = strcpy(tmp, with) + len_with;
        orig += len_front + len_rep; // move to next "end of rep"
    }
    strcpy(tmp, orig);
    return result;
}

static char* replaceHelpTokens(const char* text)
{
    char langnames[TICNAME_MAX] = {0};
    char langextensions[TICNAME_MAX] = {0};
    char langnamesspaced[TICNAME_MAX] = {0};

    for(const tic_script** it = tic_scripts(); *it; ++it)
    {
        bool isLast = *(it + 1) == NULL;
        bool isSecondToLast = *(it + 2) == NULL;

        strcat(langnames, (*it)->name);
        if(!isLast)
            strcat(langnames, isSecondToLast ? " or " : ", ");

        strcat(langextensions, (*it)->fileExtension);
        strcat(langextensions, " ");

        strcat(langnamesspaced, (*it)->name);
        if(!isLast)
            strcat(langnamesspaced, " ");
    }

    char* replaced1 = str_replace(text, "$LANG_NAMES$", langnames);
    char* replaced2 = str_replace(replaced1, "$LANG_EXTENSIONS$", langextensions);
    char* replaced3 = str_replace(replaced2, "$LANG_NAMES_SPACED$", langnamesspaced);
    free(replaced2);
    free(replaced1);
    return replaced3;
}

static void scrollBuffer(char* buffer)
{
    memmove(buffer, buffer + CONSOLE_BUFFER_WIDTH, CONSOLE_BUFFER_SIZE - CONSOLE_BUFFER_WIDTH);
    memset(buffer + CONSOLE_BUFFER_SIZE - CONSOLE_BUFFER_WIDTH, 0, CONSOLE_BUFFER_WIDTH);
}

static void scrollConsole(Console* console)
{
    while(console->cursor.pos.y >= CONSOLE_BUFFER_HEIGHT * CONSOLE_BUFFER_SCREENS)
    {
        scrollBuffer(console->text);
        scrollBuffer((char*)console->color);

        console->cursor.pos.y--;
    }

    size_t inputLines = (console->cursor.pos.x + console->input.pos) / CONSOLE_BUFFER_WIDTH;
    s32 minScroll = (s32)(console->cursor.pos.y + inputLines - CONSOLE_BUFFER_HEIGHT + 1);
    if(console->scroll.pos < minScroll)
        console->scroll.pos = minScroll;
}

static void setSymbol(Console* console, char sym, u8 color, s32 offset)
{
    console->text[offset] = sym;
    console->color[offset] = color;
}

static s32 cursorOffset(Console* console)
{
    return console->cursor.pos.x + console->cursor.pos.y * CONSOLE_BUFFER_WIDTH;
}

static tic_point cursorPos(Console* console)
{
    s32 offset = (s32)(cursorOffset(console) + console->input.pos);
    return (tic_point){
        offset % CONSOLE_BUFFER_WIDTH,
        offset / CONSOLE_BUFFER_WIDTH};
}

// Where the next symbol lands: the input's cursor while it is being typed,
// the output's own head otherwise.
static s32 printOffset(Console* console)
{
    return cursorOffset(console) + (s32)console->input.pos;
}

static s32 printColumn(Console* console)
{
    return printOffset(console) % CONSOLE_BUFFER_WIDTH;
}

static void nextLine(Console* console)
{
    console->cursor.pos.x = 0;
    console->cursor.pos.y++;
}

static bool iswrap(char sym)
{
    switch(sym)
    {
        case '|': return true;
    }

    return isspace((u8)sym);
}

static void consolePrintOffset(Console* console, const char* text, u8 color, s32 wrapLineOffset)
{
#ifndef BAREMETALPI
    printf("%s", text);
#endif

    console->cursor.pos = cursorPos(console);

    for(const char* ptr = text; *ptr; ptr++)
    {
        char symbol = *ptr;

        scrollConsole(console);

        if(symbol == '\n')
            nextLine(console);
        else
        {
            if(!iswrap(symbol))
            {
                const char* cur = ptr;
                s32 len = CONSOLE_BUFFER_WIDTH;

                while(*cur && !iswrap(*cur++))
                    len--;

                if(len > 0 && len <= console->cursor.pos.x)
                {
                    nextLine(console);
                    console->cursor.pos.x = wrapLineOffset;
                }
            }

            setSymbol(console, symbol, iswrap(symbol) ? tic_color_dark_grey : color, cursorOffset(console));

            console->cursor.pos.x++;

            if(console->cursor.pos.x >= CONSOLE_BUFFER_WIDTH)
            {
                nextLine(console);
                console->cursor.pos.x = wrapLineOffset;
            }
        }
    }

    console->input.text = console->text + cursorOffset(console);
    console->input.pos = 0;
}

static void consolePrint(Console* console, const char* text, u8 color)
{
    consolePrintOffset(console, text, color, 0);
}

static void printBack(Console* console, const char* text)
{
    consolePrint(console, text, CONSOLE_BACK_TEXT_COLOR);
}

static void printFront(Console* console, const char* text)
{
    consolePrint(console, text, CONSOLE_FRONT_TEXT_COLOR);
}

#if !defined(TIC80_PRO)
// The PRO build points at the text editor it already has instead of a link.
static void printLink(Console* console, const char* text)
{
    consolePrint(console, text, CONSOLE_LINK_TEXT_COLOR);
}
#endif

static void printError(Console* console, const char* text)
{
    consolePrint(console, text, CONSOLE_ERROR_TEXT_COLOR);
}

static void printLine(Console* console)
{
    consolePrint(console, "\n", 0);
}

// Ends the current line only if it has something on it: an async flow may
// already have ended it, and a second newline is a blank one.
static void printNewLine(Console* console)
{
    if(printColumn(console))
        printLine(console);
}

static void clearSelection(Console* console)
{
    ZEROMEM(console->select);
}

static void commandDoneLine(Console* console, bool newLine)
{
    console->progressLine = -1;

    if(!console->args.cli)
    {
        if(newLine)
            printLine(console);

        char dir[TICNAME_MAX];
        tic_fs_dir(console->fs, dir);
        if(strlen(dir))
            printBack(console, dir);

        printFront(console, ">");
    }

    console->active = true;

    clearSelection(console);

    FREE(console->desc->src);
    FREE(console->desc->command);
    FREE(console->desc->params);

    memset(console->desc, 0, sizeof(CommandDesc));
}

static void commandDone(Console* console)
{
    commandDoneLine(console, true);
}

// The console reports what it wants and the host serves it after the tick; what
// runs when the answer comes is the flow that asked, picking itself up.
static void askStart(Console* console, ConsoleAskKind kind, void (*onAnswer)(Console*, const ConsoleAnswer*))
{
    console->ask = (ConsoleAsk){.kind = kind};
    console->onAnswer = onAnswer;
}

// What a move the console asked for ends with: the command's own tail.
static void onMoved(Console* console, const ConsoleAnswer* answer)
{
    (void)answer;
    commandDone(console);
}

// The cart the console just loaded, made or section-replaced: the host takes
// its name — or is told it has none — and refreshes what it keeps about it.
static void askCart(Console* console, const char* name, bool clear, void (*onAnswer)(Console*, const ConsoleAnswer*))
{
    console->ask = (ConsoleAsk){.kind = CONSOLE_ASK_CART_LOADED, .name = name, .clear = clear};
    console->onAnswer = onAnswer;
}

static inline void drawChar(tic_mem* tic, char symbol, s32 x, s32 y, u8 color, bool alt)
{
    tic_api_print(tic, (char[]){symbol, '\0'}, x, y, color, true, 1, alt);
}

static void drawCursor(Console* console)
{
    if(!console->active)
        return;

    tic_point pos = cursorPos(console);
    pos.x *= STUDIO_TEXT_WIDTH;
    pos.y -= console->scroll.pos;
    pos.y *= STUDIO_TEXT_HEIGHT;

    u8 symbol = console->input.text[console->input.pos];

    bool inverse = console->cursor.delay || console->tickCounter % CONSOLE_CURSOR_BLINK_PERIOD < CONSOLE_CURSOR_BLINK_PERIOD / 2;

    if(inverse)
        tic_api_rect(console->tic, pos.x - 1, pos.y - 1, TIC_FONT_WIDTH + 1, TIC_FONT_HEIGHT + 1, CONSOLE_CURSOR_COLOR);

    drawChar(console->tic, symbol, pos.x, pos.y, inverse ? TIC_COLOR_BG : CONSOLE_INPUT_COLOR, false);
}

static void drawConsoleText(Console* console)
{
    tic_mem* tic = console->tic;
    const char* ptr = console->text + console->scroll.pos * CONSOLE_BUFFER_WIDTH;
    const u8* colorPointer = console->color + console->scroll.pos * CONSOLE_BUFFER_WIDTH;

    const char* end = ptr + CONSOLE_BUFFER_SCREEN;
    tic_point pos = {0};

    struct
    {
        const char* start;
        const char* end;
    } select =
        {
            console->select.start,
            console->select.end};

    if(select.start > select.end)
        SWAP(select.start, select.end, const char*);

    while(ptr < end)
    {
        char symbol = *ptr++;
        u8 color = *colorPointer++;
        bool hasSymbol = symbol && symbol != ' ';
        bool drawSelection = ptr > select.start && ptr <= select.end;
        s32 x = pos.x * STUDIO_TEXT_WIDTH;
        s32 y = pos.y * STUDIO_TEXT_HEIGHT;

        if(drawSelection)
            tic_api_rect(tic, x, y - 1, STUDIO_TEXT_WIDTH, STUDIO_TEXT_HEIGHT, hasSymbol ? color : CONSOLE_INPUT_COLOR);

        if(hasSymbol)
            drawChar(console->tic, symbol, x, y, drawSelection ? TIC_COLOR_BG : color, false);

        if(++pos.x == CONSOLE_BUFFER_WIDTH)
        {
            pos.y++;
            pos.x = 0;
        }
    }
}

static void processConsoleHome(Console* console)
{
    console->input.pos = 0;
}

static void processConsoleEnd(Console* console)
{
    console->input.pos = strlen(console->input.text);
}

static s32 getInputOffset(Console* console)
{
    return (s32)((console->input.text - console->text) + console->input.pos);
}

static void deleteText(Console* console, s32 start, s32 end)
{
    s32 offset = (s32)(console->input.text - console->text);
    s32 size = CONSOLE_BUFFER_SIZE - offset - end;
    memmove(console->input.text + start, console->input.text + end, size);

    u8* color = console->color + offset;
    memmove(color + start, color + end, size);
}

static void processConsoleDel(Console* console)
{
    deleteText(console, (s32)(console->input.pos), (s32)(console->input.pos + 1));
}

static void processConsoleBackspace(Console* console)
{
    if(console->input.pos > 0)
    {
        console->input.pos--;

        processConsoleDel(console);
    }
}

static void onHelpCommand(Console* console);

static void onExitCommand(Console* console)
{
    askStart(console, CONSOLE_ASK_EXIT, onMoved);
}

static void onEditCommand(Console* console)
{
    askStart(console, CONSOLE_ASK_CODE, onMoved);
}

static char* getDemoCartPath(char* path, const tic_script* script)
{
    strcpy(path, TIC_LOCAL_VERSION "default_");

    if(script && script->name)
        strcat(path, script->name);

    strcat(path, ".tic");

    return path;
}

static void* getDemoCart(Console* console, const tic_script* script, s32* size)
{
    char path[1024];
    getDemoCartPath(path, script);

    {
        void* data = tic_fs_loadroot(console->fs, path, size);

        if(data && *size)
            return data;
    }

    u8* data = calloc(1, TIC_CART_SAVE_SIZE);

    if(data)
    {
        *size = tic_tool_unzip(data, TIC_CART_SAVE_SIZE, script->demo.data, script->demo.size);

        if(*size)
            tic_fs_saveroot(console->fs, path, data, *size, false);
    }

    return data;
}

static void onDemoLoaded(Console* console, const ConsoleAnswer* answer)
{
    printBack(console, "\ncart ");
    printFront(console, answer->name);
    printBack(console, " loaded!\n");

    commandDone(console);
}

static void onLoadDemoCommandConfirmed(Console* console, const void* data)
{
    const tic_script* script = data;

    void* cart = NULL;
    s32 size = 0;

    char path[1024];
    getDemoCartPath(path, script);
    const char* name = tic_tool_cart_name(path);

    cart = getDemoCart(console, script, &size);
    tic_cart_load(&console->tic->cart, cart, size);
    tic_api_reset(console->tic);
    free(cart);

    askCart(console, name, false, onDemoLoaded);
}

static void printCartLoaded(Console* console, const char* name)
{
    printBack(console, "\ncart ");
    printFront(console, name);
    printBack(console, " loaded!\nuse ");
    printFront(console, "RUN");
    printBack(console, " command to run it\n");
}

static void onLoaded(Console* console, const ConsoleAnswer* answer)
{
    printCartLoaded(console, answer->name);

    // The host gives the cart its name: the load is over here, not where it
    // asked.
    commandDone(console);
}

static void onCartLoaded(Console* console, const char* name, const char* section)
{
    tic_api_reset(console->tic);

    // Replacing one section keeps the cart's name; a whole cart takes one.
    askCart(console, section ? NULL : name, false, onLoaded);
}

static inline tic_cartridge* newCart()
{
    return malloc(sizeof(tic_cartridge));
}

static void onFetched(Console* console, const ConsoleAnswer* answer)
{
    printCartLoaded(console, answer->name);

    if(console->fetch.callback)
        console->fetch.callback(console->fetch.calldata);

    commandDone(console);
}

static void loadByHash(Console* console, const char* name, const char* hash, const char* section, fs_done_callback callback, void* data)
{
    console->active = false;

    console->fetch.callback = callback;
    console->fetch.calldata = data;

    // The ask is served a frame from now, and whoever asked is free to let its
    // strings go in the meantime — the public-directory path does.
    strcpy(console->fetch.name, name);
    strcpy(console->fetch.hash, hash);
    console->fetch.section[0] = '\0';
    if(section)
        strcpy(console->fetch.section, section);

    console->ask = (ConsoleAsk){
        .kind = CONSOLE_ASK_CART_FETCH,
        .name = console->fetch.name,
        .hash = console->fetch.hash,
        .section = section ? console->fetch.section : NULL,
    };

    console->onAnswer = onFetched;
}

typedef struct
{
    Console* console;
    char* name;
    char* hash;
    char* section;
} LoadPublicCartData;

static bool compareFilename(const char* name, const char* title, const char* hash, s32 id, void* data, bool dir)
{
    (void)dir;
    (void)id;
    (void)title;
    LoadPublicCartData* loadPublicCartData = data;

    if(strcmp(name, loadPublicCartData->name) == 0 && hash && strlen(hash))
    {
        loadPublicCartData->hash = strdup(hash);
        return false;
    }

    return true;
}

static void fileFound(void* data)
{
    LoadPublicCartData* loadPublicCartData = data;
    Console* console = loadPublicCartData->console;

    if(loadPublicCartData->hash)
        loadByHash(console, loadPublicCartData->name, loadPublicCartData->hash, loadPublicCartData->section, NULL, NULL);
    else
    {
        char msg[TICNAME_MAX];
        sprintf(msg, "\nerror: `%s` file not loaded", loadPublicCartData->name);
        printError(console, msg);
        commandDone(console);
    }

    FREE(loadPublicCartData->name);
    FREE(loadPublicCartData->hash);
    FREE(loadPublicCartData->section);
    FREE(loadPublicCartData);
}

static bool printUsage(Console* console, const char* command);

static void onLoadCommandConfirmed(Console* console, const void* data)
{
    (void)data;
    if(console->desc->count > 0)
    {

        const char* param = console->desc->params->key;
        const char* name = tic_tool_cart_name(param);
        const char* section = console->desc->count > 1 ? console->desc->params[1].key : NULL;

        if(section)
        {
            static const char* Sections[] =
                {
                    "code",
#define SECTION_DEF(name, ...) #name,
                    TIC_SYNC_LIST(SECTION_DEF)
#undef SECTION_DEF
                };

            bool found = false;
            for(const char **it = Sections, **end = it + COUNT_OF(Sections); it != end; ++it)
                if(strcmp(*it, section) == 0)
                {
                    found = true;
                    break;
                }

            if(!found)
            {
                printError(console, "\nunknown section: ");
                printError(console, section);
                printLine(console);
                printUsage(console, console->desc->command);
                commandDone(console);
                return;
            }
        }

        if(tic_fs_ispubdir(console->fs))
        {
            LoadPublicCartData loadPublicCartData = {console, strdup(name), NULL, section ? strdup(section) : NULL};
            tic_fs_enum(console->fs, compareFilename, fileFound, MOVE(loadPublicCartData));

            return;
        }
        else
        {
            s32 size = 0;
            void* buf = strcmp(name, CONFIG_TIC_PATH) == 0
                            ? tic_fs_loadroot(console->fs, name, &size)
                            : tic_fs_load(console->fs, name, &size);

            if(buf) SCOPE(free(buf))
                {
                    tic_cartridge* cart = newCart();

                    SCOPE(free(cart))
                    {
                        tic_cart_load(cart, buf, size);
                        tic_tool_load_section(console->tic, cart, section);
                        onCartLoaded(console, name, section);
                    }
                }
            else if(tic_tool_has_ext(param, PngExt) && tic_fs_exists(console->fs, param))
            {
                png_buffer buffer;
                buffer.data = tic_fs_load(console->fs, param, &buffer.size);

                SCOPE(free(buffer.data))
                {
                    tic_cartridge* cart = loadPngCart(buffer);

                    if(cart) SCOPE(free(cart))
                        {
                            tic_tool_load_section(console->tic, cart, section);
                            onCartLoaded(console, param, section);
                        }
                    else
                        printError(console, "\npng cart loading error");
                }
            }
            else
            {
                const char* path = param;

#if defined(TIC80_PRO)
                if(tic_tool_is_project(path))
                {
                    void* cartData = tic_fs_load(console->fs, path, &size);

                    if(cartData) SCOPE(free(cartData))
                        {
                            tic_cartridge* cart = newCart();

                            SCOPE(free(cart))
                            {
                                tic_project_load(path, cartData, size, cart);
                                tic_tool_load_section(console->tic, cart, section);
                                onCartLoaded(console, path, section);
                            }
                        }
                    else
                        printError(console, "\nproject loading error");
                }
                else
                    printError(console, "\nfile not found");
#else
                if(tic_tool_is_project(path))
                {
                    printError(console, "\nproject loading error");
                    printFront(console, "\nThis version only supports binary .png or .tic cartridges.");
                    printLine(console);
                    printFront(console, "\nTIC-80 ");
                    consolePrint(console, "PRO", tic_color_light_blue);
                    printFront(console, " is needed for text files.");
                    printLine(console);
                    printFront(console, "\nLearn more:\n");
                    printLink(console, "https://tic80.com/pro");
                }
                else
                {
                    printError(console, "\ncart loading error");
                }

#endif
            }
        }
    }
    else
        printUsage(console, console->desc->command);

    // A load that asked the host for the cart's name finishes on that answer,
    // where the message and the prompt are printed.
    if(console->ask.kind == CONSOLE_ASK_NONE)
        commandDone(console);
}

typedef void (*ConsoleConfirmCallback)(Console* console, const void* data);

// The dialog belongs to the host; the console only says which of its flows a
// "yes" continues, and picks that flow up from the answer.
static void onConfirmed(Console* console, const ConsoleAnswer* answer)
{
    if(answer->yes)
        console->confirm.yes(console, console->confirm.data);
    else
        commandDone(console);
}

static void confirmCommand(Console* console, const char** text, s32 rows, ConsoleConfirmCallback callback, const void* data)
{
    if(console->args.cli)
    {
        for(s32 i = 0; i < rows; i++)
        {
            printError(console, text[i]);
            printLine(console);
        }

        commandDone(console);
    }
    else
    {
        console->confirm.yes = callback;
        console->confirm.data = data;

        askStart(console, CONSOLE_ASK_CONFIRM, onConfirmed);
        console->ask.rows = text;
        console->ask.rowsCount = rows;
    }
}

static const char* LoadWarningRows[] =
    {
        "WARNING!",
        "You have unsaved changes",
        "Do you really want to load cart?",
};

static void onLoadDemoCommand(Console* console, const tic_script* script)
{
    if(console->view->cartChanged)
    {
        confirmCommand(console, LoadWarningRows, COUNT_OF(LoadWarningRows), onLoadDemoCommandConfirmed, script);
    }
    else
    {
        onLoadDemoCommandConfirmed(console, script);
    }
}

static void onLoadCommand(Console* console)
{
    if(console->view->cartChanged)
    {
        confirmCommand(console, LoadWarningRows, COUNT_OF(LoadWarningRows), onLoadCommandConfirmed, NULL);
    }
    else
    {
        onLoadCommandConfirmed(console, NULL);
    }
}

static void loadDemo(Console* console, const tic_script* script)
{
    s32 size = 0;
    u8* data = getDemoCart(console, script, &size);

    if(data)
    {
        tic_cart_load(&console->tic->cart, data, size);
        tic_api_reset(console->tic);

        free(data);
    }

    askCart(console, NULL, true, NULL);
}

static void onNewCommandConfirmed(Console* console, const void* data)
{
    (void)data;
    bool done = false;

    s32 count = 0;
    FOREACH_LANG(_)
    {
        (void)_;
        count++;
    }

    if(count == 0)
    {
        printError(console, "\nerror: not found any language.");
    }
    else if(count == 1)
    {
        loadDemo(console, tic_get_script(console->tic));
        done = true;
    }
    else if(console->desc->count)
    {
        const char* param = console->desc->params->key;

        FOREACH_LANG(ln)
        {
            if(strcmp(param, ln->name) == 0)
            {
                loadDemo(console, ln);
                done = true;
            }
        }

        if(!done)
        {
            printError(console, "\nunknown parameter: ");
            printError(console, param);
            commandDone(console);
            return;
        }
    }
    else
    {
        printError(console, "\nerror: choose a language for the new cart.");
        printUsage(console, console->desc->command);
    }

    if(done)
        printBack(console, "\nnew cart has been created");
    else
        printError(console, "\ncart not created");

    commandDone(console);
}

static void onNewCommand(Console* console)
{
    if(console->view->cartChanged)
    {
        static const char* Rows[] =
            {
                "WARNING!",
                "You have unsaved changes",
                "Do you really want to create new cart?",
            };

        confirmCommand(console, Rows, COUNT_OF(Rows), onNewCommandConfirmed, NULL);
    }
    else
    {
        onNewCommandConfirmed(console, NULL);
    }
}

static void insertInputText(Console* console, const char* text)
{
    s32 size = (s32)(strlen(text));
    s32 offset = getInputOffset(console);

    if(size < CONSOLE_BUFFER_SIZE - offset)
    {
        char* pos = console->text + offset;
        u8* color = console->color + offset;

        {
            s32 len = (s32)(strlen(pos));
            memmove(pos + size, pos, len);
            memmove(color + size, color, len);
        }

        memcpy(pos, text, size);
        memset(color, CONSOLE_INPUT_COLOR, size);

        console->input.pos += size;
    }

    clearSelection(console);
}

typedef struct
{
    Console* console;
    char* incompleteWord; // Original word that's being completed.
    char* options;        // Options to show to the user.
    char* commonPrefix;   // Common prefix of all options.
} TabCompleteData;

static void addTabCompleteOption(TabCompleteData* data, const char* option)
{
    if(strstr(option, data->incompleteWord) == option)
    {
        // Possibly reduce the common prefix of all possible options.
        if(strlen(data->options) == 0)
        {
            // This is the first option to be added. Initialize the prefix.
            strncpy(data->commonPrefix, option, CONSOLE_BUFFER_SCREEN);
            // strncpy does not null-terminate if the source string is too long so
            // null terminate in the end just to be sure
            data->commonPrefix[CONSOLE_BUFFER_SCREEN - 1] = 0;
        }
        else
        {
            // Only leave the longest common prefix.
            char* tmpCommonPrefix = data->commonPrefix;
            char* tmpOption = (char*)option;

            while(*tmpCommonPrefix && *tmpOption && *tmpCommonPrefix == *tmpOption)
            {
                tmpCommonPrefix++;
                tmpOption++;
            }

            *tmpCommonPrefix = 0;
        }

        // The option matches the incomplete word, add it to the list.
        // the last parameter of strcat is the maximum number of characters to be
        // copied, and it adds a null terminator in the end. data->options having
        // capacity CONSOLE_BUFFER_SCREEN, we can append CONSOLE_BUFFER_SCREEN -
        // strlen(data->options) - 1 characters to its end at most
        strncat(data->options, option, CONSOLE_BUFFER_SCREEN - strlen(data->options) - 1);
        strncat(data->options, " ", CONSOLE_BUFFER_SCREEN - strlen(data->options) - 1);
    }
}

// Used to show tab-complete options, for example.
static void provideHint(Console* console, const char* hint)
{
    char* input = malloc(CONSOLE_BUFFER_SCREEN);
    strncpy(input, console->input.text, CONSOLE_BUFFER_SCREEN);
    // strncpy does not null-terminate if the source string is too long so
    // null terminate in the end just to be sure
    input[CONSOLE_BUFFER_SCREEN - 1] = 0;

    printLine(console);
    printBack(console, hint);
    commandDone(console);
    insertInputText(console, input);

    free(input);
}

static void finishTabComplete(const TabCompleteData* data)
{
    bool anyOptions = strlen(data->options) > 0;
    if(anyOptions)
    {
        // Adding one at the right because all options end with a space.
        bool justOneOptionLeft = strlen(data->options) == strlen(data->commonPrefix) + 1;

        if(strlen(data->commonPrefix) == strlen(data->incompleteWord) && !justOneOptionLeft)
        {
            provideHint(data->console, data->options);
        }
        processConsoleEnd(data->console);
        insertInputText(data->console, data->commonPrefix + strlen(data->incompleteWord));

        if(justOneOptionLeft)
        {
            insertInputText(data->console, " ");
        }
    }

    free(data->options);
    free(data->commonPrefix);
}

static void tabCompleteLanguages(TabCompleteData* data)
{
    FOREACH_LANG(ln)
    {
        addTabCompleteOption(data, ln->name);
    }

    finishTabComplete(data);
}

static void tabCompleteExport(TabCompleteData* data)
{
#define EXPORT_CMD_DEF(name, label) addTabCompleteOption(data, #name);
    EXPORT_CMD_LIST(EXPORT_CMD_DEF)
#undef EXPORT_CMD_DEF
    finishTabComplete(data);
}

static void tabCompleteImport(TabCompleteData* data)
{
#define IMPORT_CMD_DEF(name) addTabCompleteOption(data, #name);
    IMPORT_CMD_LIST(IMPORT_CMD_DEF)
#undef IMPORT_CMD_DEF
    finishTabComplete(data);
}

static bool addFileAndDirToTabComplete(const char* name, const char* title, const char* hash, s32 id, void* data, bool dir)
{
    (void)dir;
    (void)hash;
    (void)id;
    (void)title;
    addTabCompleteOption(data, name);

    return true;
}

static bool addFilenameToTabComplete(const char* name, const char* title, const char* hash, s32 id, void* data, bool dir)
{
    (void)hash;
    (void)id;
    (void)title;
    if(!dir)
        addTabCompleteOption(data, name);

    return true;
}

static bool addDirToTabComplete(const char* name, const char* title, const char* hash, s32 id, void* data, bool dir)
{
    (void)hash;
    (void)id;
    (void)title;
    if(dir)
        addTabCompleteOption(data, name);

    return true;
}

static void finishTabCompleteAndFreeData(void* data)
{
    finishTabComplete((const TabCompleteData*)data);
    free(data);
}

static void tabCompleteFiles(TabCompleteData* data)
{
    tic_fs_enum(data->console->fs, addFilenameToTabComplete, finishTabCompleteAndFreeData, MOVE(*data));
}

static void tabCompleteDirs(TabCompleteData* data)
{
    tic_fs_enum(data->console->fs, addDirToTabComplete, finishTabCompleteAndFreeData, MOVE(*data));
}

static void tabCompleteFilesAndDirs(TabCompleteData* data)
{
    tic_fs_enum(data->console->fs, addFileAndDirToTabComplete, finishTabCompleteAndFreeData, MOVE(*data));
}

static void tabCompleteConfig(TabCompleteData* data)
{
    addTabCompleteOption(data, "reset");
    addTabCompleteOption(data, "default");
    finishTabComplete(data);
}

typedef struct
{
    const char* name;
    bool dir;
} FileItem;

typedef struct
{
    Console* console;
    FileItem* items;
    s32 count;
} PrintFileNameData;

static bool printFilename(const char* name, const char* title, const char* hash, s32 id, void* ctx, bool dir)
{
    (void)hash;
    (void)id;
    (void)title;
    PrintFileNameData* data = ctx;

    data->items = realloc(data->items, (data->count + 1) * sizeof *data->items);
    data->items[data->count++] = (FileItem){strdup(name), dir};

    return true;
}

static s32 casecmp(const char* str1, const char* str2)
{
    while(*str1 && *str2)
    {
        if(tolower((u8)*str1) != tolower((u8)*str2))
            break;

        ++str1;
        ++str2;
    }

    return (s32)((u8)tolower((u8)(*str1)) - (u8)tolower((u8)(*str2)));
}

static inline int itemcmp(const void* a, const void* b)
{
    const FileItem* item1 = a;
    const FileItem* item2 = b;

    if(item1->dir != item2->dir)
        return item1->dir ? -1 : 1;

    return casecmp(item1->name, item2->name);
}

static void onDirDone(void* ctx)
{
    PrintFileNameData* data = ctx;
    Console* console = data->console;

    qsort(data->items, data->count, sizeof *data->items, itemcmp);

    for(const FileItem *item = data->items, *end = item + data->count; item < end; item++)
    {
        printLine(console);

        if(item->dir)
        {
            printBack(console, "[");
            printBack(console, item->name);
            printBack(console, "]");
        }
        else
            printFront(console, item->name);

        free((void*)item->name);
    }

    if(data->count == 0)
    {
        printBack(console, "\n\nuse ");
        printFront(console, "DEMO");
        printBack(console, " command to install demo carts");
    }
    else
        free(data->items);

    printLine(console);
    commandDone(console);

    free(ctx);
}

typedef struct
{
    Console* console;
    char* name;
} ChangeDirData;

static void onChangeDirectoryDone(bool dir, void* data)
{
    ChangeDirData* changeDirData = data;
    Console* console = changeDirData->console;

    if(dir)
    {
        tic_fs_changedir(console->fs, changeDirData->name);
    }
    else
        printBack(console, "\ndir doesn't exist");

    free(changeDirData->name);
    free(changeDirData);

    commandDone(console);
}

static void onChangeDirectory(Console* console)
{
    if(console->desc->count)
    {
        const char* param = console->desc->params->key;

        if(strcmp(param, "/") == 0)
        {
            tic_fs_homedir(console->fs);
        }
        else if(strcmp(param, "..") == 0)
        {
            tic_fs_dirback(console->fs);
        }
        else
        {
            ChangeDirData data = {console, strdup(param)};
            tic_fs_isdir_async(console->fs, param, onChangeDirectoryDone, MOVE(data));
            return;
        }
    }
    else
    {
        tic_fs_homedir(console->fs);
    }

    commandDone(console);
}

static void onMakeDirectory(Console* console)
{
    if(console->desc->count)
    {
        char msg[TICNAME_MAX];
        const char* param = console->desc->params->key;

        if(tic_fs_exists(console->fs, param))
        {
            sprintf(msg, "\nerror, [%s] already exists :(", param);
            printError(console, msg);
            commandDone(console);
            return;
        }

        sprintf(msg, "\ncreated [%s] folder :)", param);

        printBack(console, tic_fs_makedir(console->fs, param)
                               ? "\nerror, dir not created :("
                               : msg);
    }
    else
        printError(console, "\ninvalid dir name");

    commandDone(console);
}

static void onDirCommand(Console* console)
{
    printLine(console);

    PrintFileNameData data = {.console = console};
    tic_fs_enum(console->fs, printFilename, onDirDone, MOVE(data));
}

static void onFolderCommand(Console* console)
{

    printBack(console, "\nStorage path:\n");
    printFront(console, tic_fs_pathroot(console->fs, ""));

    tic_fs_openfolder(console->fs);

    commandDone(console);
}

static void onClsCommand(Console* console)
{
    memset(console->text, 0, CONSOLE_BUFFER_SIZE);
    memset(console->color, TIC_COLOR_BG, CONSOLE_BUFFER_SIZE);

    ZEROMEM(console->scroll);
    ZEROMEM(console->cursor);
    ZEROMEM(console->input);

    printf("\r");

    commandDoneLine(console, false);
}

static void onInstallDemosCommand(Console* console)
{
    tic_fs* fs = console->fs;
    u8* data = malloc(TIC_CART_SAVE_SIZE);

    SCOPE(free(data))
    {
        printBack(console, "\nadded carts:\n\n");

        FOREACH_LANG(ln)
        {
            for(const struct tic_demo* demo = ln->demos; demo && demo->data; demo++)
            {
                tic_fs_save(fs, demo->name, data, tic_tool_unzip(data, TIC_CART_SAVE_SIZE, demo->data, demo->size), true);
                printFront(console, demo->name);
                printLine(console);
            }
        }

        static const char* Bunny = "bunny";

        tic_fs_makedir(fs, Bunny);
        tic_fs_changedir(fs, Bunny);

        FOREACH_LANG(ln)
        {
            // having a Mark is not mandatory
            if(ln->mark.data != NULL)
            {
                tic_fs_save(fs, ln->mark.name, data, tic_tool_unzip(data, TIC_CART_SAVE_SIZE, ln->mark.data, ln->mark.size), true);
                printFront(console, Bunny);
                printFront(console, "/");
                printFront(console, ln->mark.name);
                printLine(console);
            }
        }

        tic_fs_dirback(fs);
    }

    commandDone(console);
}

static void onGameMenuCommand(Console* console)
{
    askStart(console, CONSOLE_ASK_MENU, onMoved);
}

#if defined(BUILD_SURF)
static void onSurfCommand(Console* console)
{
    // The browser takes the console's place; nothing of the command is left to
    // finish, which is why this one ends where it is asked.
    askStart(console, CONSOLE_ASK_SURF, NULL);
}
#endif

static void onConfigCommand(Console* console)
{
    if(console->desc->count)
    {
        if(strcmp(console->desc->params->key, "reset") == 0)
        {
            askStart(console, CONSOLE_ASK_CONFIG_RESET, NULL);
            printBack(console, "\nconfiguration reset :)");
        }
        else if(strcmp(console->desc->params->key, "default") == 0)
        {
            // The demo load finishes on the host's answer, where the prompt is
            // printed: none of it is left for this command to end.
            if(console->desc->count == 1)
            {
                onLoadDemoCommand(console, tic_get_script(console->tic));
                return;
            }

            FOREACH_LANG(script)
            {
                if(strcmp(console->desc->params[1].key, script->name) == 0)
                {
                    onLoadDemoCommand(console, script);
                    return;
                }
            }
        }
        else
        {
            printError(console, "\nunknown parameter:\n");
            printError(console, console->desc->params->key);
        }
    }
    else
    {
        CommandDesc desc =
            {
                .params = malloc(sizeof *desc.params),
                .count = 1,
            };

        *desc.params = (struct Param){.key = strdup(CONFIG_TIC_PATH)};
        *console->desc = desc;

        onLoadCommand(console);

        return;
    }

    commandDone(console);
}

typedef struct
{
#define IMPORT_KEYS_DEF(key) s32 key;
    IMPORT_KEYS_LIST(IMPORT_KEYS_DEF)
#undef IMPORT_KEYS_DEF
} ImportParams;

static void onFileImported(Console* console, const char* filename, bool result)
{
    printNewLine(console);

    if(result)
    {
        printBack(console, filename);
        printBack(console, " imported :)");
    }
    else
    {
        char buf[TICNAME_MAX + sizeof "error:  not imported :("];
        sprintf(buf, "error: %s not imported :(", filename);
        printError(console, buf);
    }

    commandDone(console);
}

static inline tic_bank* getBank(Console* console, s32 bank)
{
    return &console->tic->cart.banks[bank];
}

static inline const tic_palette* getPalette(Console* console, s32 bank, s32 vbank)
{
    return vbank
               ? &getBank(console, bank)->palette.vbank1
               : &getBank(console, bank)->palette.vbank0;
}

static void onImportTilesBase(Console* console, const char* name, const void* buffer, s32 size, tic_tile* base, ImportParams params)
{
    png_buffer png = {(u8*)buffer, size};
    bool error = true;
    s32 bpp = params.bpp ? params.bpp : 4;
    switch(bpp)
    {
        case 1:
        case 2:
        case 4:
            break;
        default:
            // not real!
            goto exit;
    }

    png_img img = png_read(png, NULL);

    if(img.data) SCOPE(free(img.data))
        {
            const tic_palette* pal = getPalette(console, params.bank, params.vbank);

            s32 bpp_scale = 1;
            switch(bpp)
            {
                case 1:
                    bpp_scale = 4;
                    break;
                case 2:
                    bpp_scale = 2;
                    break;
                default:
                    break;
            }
            u32 color1, color2, color3, color4, color;

            for(s32 j = 0, y = params.y, h = y + (params.h ? params.h : img.height); y < h; ++y, ++j)
                for(s32 i = 0, x = params.x, w = x + ((params.w ? params.w : img.width) / bpp_scale); x < w; ++x, i += bpp_scale)
                    if(x >= 0 && x < TIC_SPRITESHEET_SIZE && y >= 0 && y < TIC_SPRITESHEET_SIZE)
                        switch(bpp)
                        {
                            case 4:
                                tic_tilesheet_setflatpix(base, x, y, (u8)tic_nearest_color(pal->colors, (tic_rgb*)(img.pixels + i + j * img.width), TIC_PALETTE_SIZE));
                                break;
                            case 2:
                                color1 = tic_nearest_color(pal->colors, (tic_rgb*)(img.pixels + i + j * img.width), 4);
                                color2 = tic_nearest_color(pal->colors, (tic_rgb*)(img.pixels + i + 1 + j * img.width), 4);
                                // adding them together caused issues with squashing??? no idea why this isn't the case
                                // for bpp 1
                                color = (color2 << 2) | color1;
                                tic_tilesheet_setflatpix(base, x, y, (u8)(color));
                                break;
                            case 1:
                                color1 = tic_nearest_color(pal->colors, (tic_rgb*)(img.pixels + i + j * img.width), 2);
                                color2 = tic_nearest_color(pal->colors, (tic_rgb*)(img.pixels + i + 1 + j * img.width), 2);
                                color3 = tic_nearest_color(pal->colors, (tic_rgb*)(img.pixels + i + 2 + j * img.width), 2);
                                color4 = tic_nearest_color(pal->colors, (tic_rgb*)(img.pixels + i + 3 + j * img.width), 2);
                                color = (color4 << 3) | (color3 << 2) | (color2 << 1) | color1;
                                tic_tilesheet_setflatpix(base, x, y, (u8)(color));
                                break;
                        }

            error = false;
        }

exit:
    onFileImported(console, name, !error);
}

static void onImport_tiles(Console* console, const char* name, const void* buffer, s32 size, ImportParams params)
{
    onImportTilesBase(console, name, buffer, size, getBank(console, params.bank)->tiles.data, params);
}

static void onImport_binary(Console* console, const char* name, const void* buffer, s32 size, ImportParams params)
{
    (void)params;
    bool ok = name && buffer && size <= TIC_BINARY_SIZE;

    if(ok)
    {
        tic_binary* binary = &console->tic->cart.binary;
        binary->size = size;
        memcpy(binary->data, buffer, size);
    }

    onFileImported(console, name, ok);
}

static void onImport_sprites(Console* console, const char* name, const void* buffer, s32 size, ImportParams params)
{
    onImportTilesBase(console, name, buffer, size, getBank(console, params.bank)->sprites.data, params);
}

static void onImport_map(Console* console, const char* name, const void* buffer, s32 size, ImportParams params)
{
    bool ok = name && buffer && size >= 0 && size <= (s32)sizeof(tic_map);

    if(ok)
    {
        enum
        {
            Size = sizeof(tic_map)
        };

        tic_map* map = &getBank(console, params.bank)->map;
        memset(map, 0, Size);
        memcpy(map, buffer, MIN(size, Size));
    }

    onFileImported(console, name, ok);
}

static void onImport_code(Console* console, const char* name, const void* buffer, s32 size, ImportParams params)
{
    (void)params;
    tic_mem* tic = console->tic;
    bool error = false;

    if(name && buffer && size >= 0 && size <= (s32)sizeof(tic_code))
    {
        enum
        {
            Size = sizeof(tic_code)
        };

        memset(tic->cart.code.data, 0, Size);
        memcpy(tic->cart.code.data, buffer, MIN(size, Size));

        // The code came back to what it was saved as: no name changes, and the
        // host's idea of the cart is simply refreshed.
        askCart(console, NULL, false, NULL);
    }
    else
        error = true;

    onFileImported(console, name, !error);
}

static void onImport_screen(Console* console, const char* name, const void* buffer, s32 size, ImportParams params)
{
    png_buffer png = {(u8*)buffer, size};
    bool error = true;

    png_img img = png_read(png, NULL);

    if(img.data) SCOPE(free(img.data))
        {
            if(img.width == TIC80_WIDTH && img.height == TIC80_HEIGHT)
            {
                tic_bank* bank = getBank(console, params.bank);
                const tic_palette* pal = getPalette(console, params.bank, params.vbank);

                s32 i = 0;
                for(const png_rgba *pix = img.pixels, *end = pix + (TIC80_WIDTH * TIC80_HEIGHT); pix < end; pix++)
                    tic_tool_poke4(bank->screen.data, i++, (u8)(tic_nearest_color(pal->colors, (tic_rgb*)pix, TIC_PALETTE_SIZE)));

                error = false;
            }
        }

    onFileImported(console, name, !error);
}

static void onImportCommand(Console* console)
{
    bool error = true;

    if(console->desc->count > 1)
    {
        ImportParams params = {0};

        for(const struct Param *it = console->desc->params, *end = it + console->desc->count; it < end; ++it)
        {
#define IMPORT_KEYS_DEF(name) \
    if(it->val && strcmp(it->key, #name) == 0) params.name = atoi(it->val);
            IMPORT_KEYS_LIST(IMPORT_KEYS_DEF)
#undef IMPORT_KEYS_DEF
        }

        const char* filename = console->desc->params[1].key;
        s32 size = 0;
        const void* data = tic_fs_load(console->fs, filename, &size);

        if(data) SCOPE(free((void*)data))
            {
                static const struct Handler
                {
                    const char* section;
                    void (*handler)(Console*, const char*, const void*, s32, ImportParams);
                } Handlers[] =
                    {
#define IMPORT_CMD_DEF(name) {#name, onImport_##name},
                        IMPORT_CMD_LIST(IMPORT_CMD_DEF)
#undef IMPORT_CMD_DEF
                    };

                const char* section = console->desc->params[0].key;
                FOR(const struct Handler*, ptr, Handlers)
                if(strcmp(section, ptr->section) == 0)
                {
                    ptr->handler(console, filename, data, size, params);
                    error = false;
                    break;
                }
            }
        else
        {
            char msg[TICNAME_MAX];
            sprintf(msg, "\nerror, %s file not loaded", filename);
            printError(console, msg);
            commandDone(console);
            return;
        }
    }

    if(error)
    {
        printError(console, "\nerror: invalid parameters.");
        printUsage(console, console->desc->command);

        commandDone(console);
    }
}

static void onFileExported(Console* console, const char* filename, bool result)
{
    // The export may have waited on the network: its own line is where this
    // one starts, and it is already ended then.
    printNewLine(console);

    if(result)
    {
        printBack(console, filename);
        printBack(console, " exported :)");
    }
    else
    {
        char buf[TICNAME_MAX + sizeof "error:  not exported :("];
        sprintf(buf, "error: %s not exported :(", filename);
        printError(console, buf);
    }

    commandDone(console);
}

typedef struct
{
#define EXPORT_KEYS_DEF(key) s32 key;
    EXPORT_KEYS_LIST(EXPORT_KEYS_DEF)
#undef EXPORT_KEYS_DEF
} ExportParams;

static void exportSprites(Console* console, const char* filename, tic_tile* base, ExportParams params)
{

    png_img img = {.width = TIC_SPRITESHEET_SIZE, .height = TIC_SPRITESHEET_SIZE, .pixels = malloc(TIC_SPRITESHEET_SIZE * TIC_SPRITESHEET_SIZE * sizeof(png_rgba))};

    SCOPE(free(img.data))
    {
        const tic_palette* pal = getPalette(console, params.bank, params.vbank);

        for(s32 i = 0; i < TIC_SPRITESHEET_SIZE * TIC_SPRITESHEET_SIZE; i++)
            img.values[i] = tic_rgba(&pal->colors[tic_tilesheet_getflatpix(base, i % TIC_SPRITESHEET_SIZE, i / TIC_SPRITESHEET_SIZE)]);

        png_buffer png = png_write(img, (png_buffer){NULL, 0});

        SCOPE(free(png.data))
        {
            onFileExported(console, filename, tic_fs_save(console->fs, filename, png.data, png.size, true));
        }
    }
}

typedef struct
{
    Console* console;
    char filename[TICNAME_MAX];
    void* stub; // the stub zip, held until the export page arrives
    s32 stubSize;
} GameExportData;

static void onExportGet(const net_get_data* data)
{
    GameExportData* exportData = (GameExportData*)data->calldata;
    Console* console = exportData->console;

    switch(data->type)
    {
        case net_get_progress:
        {
            // A trailing newline can leave the cursor on the row past the
            // buffer: scroll before measuring, or the row would be outside it.
            scrollConsole(console);

            // Redraw the GET line in place: a fetch reports every chunk, and a
            // line per report buries the result. The first report marks its row.
            if(console->progressLine < 0)
                console->progressLine = printOffset(console) / CONSOLE_BUFFER_WIDTH * CONSOLE_BUFFER_WIDTH;

            console->cursor.pos = (tic_point){0, console->progressLine / CONSOLE_BUFFER_WIDTH};
            console->input.text = console->text + console->progressLine;
            console->input.pos = 0;
            memset(console->input.text, 0, CONSOLE_BUFFER_WIDTH);

            printf("\r");
            printBack(console, "GET ");
            printFront(console, data->url);

            char buf[8];
            sprintf(buf, " [%i%%]", data->progress.size * 100 / data->progress.total);
            printBack(console, buf);
        }
        break;
        case net_get_error:
            printNewLine(console);
            printError(console, "file downloading error :(");
            commandDone(console);
            free(exportData);
            break;
        default:
            break;
    }
}

static void onNativeExportGet(const net_get_data* data)
{
    switch(data->type)
    {
        case net_get_done:
        {
            GameExportData* exportData = (GameExportData*)data->calldata;
            Console* console = exportData->console;

            char filename[TICNAME_MAX];
            strcpy(filename, exportData->filename);
            free(exportData);

            s32 size = data->done.size;

            printNewLine(console);

            const char* path = tic_fs_path(console->fs, filename);
            void* buf = NULL;

            onFileExported(console, filename, (buf = embed_cart(console->tic, data->done.data, &size)) && fs_write(path, buf, size));
            chmod(path, DEFAULT_CHMOD);

            if(buf)
                free(buf);
        }
        break;
        default:
            onExportGet(data);
    }
}

static void exportGame(Console* console, const char* name, const char* system, net_get_callback callback, ExportParams params)
{
    (void)params;
    printLine(console);
    GameExportData data = {.console = console};
    strcpy(data.filename, name);

    // The directory this build's assets live in: a release asks for its tag
    // on tic80.com, a snapshot for its line (1.3) on dev.tic80.com. The two
    // sites lay out what their own builds ask for, so this is a lookup in a
    // directory that exists either way — a version of its own, "1.2.<commits>
    // -dev", was a 404 on every export (12.09: those 404s are in the prod
    // access log).
    char url[TICNAME_MAX] = "/export/" TIC_VERSION_DIR "/";
    strcat(url, system);

#if defined(TIC80_PRO)
    if(params.alone)
        strcat(url, tic_get_script(console->tic)->name);
#endif

    tic_net_get(console->net, url, callback, MOVE(data));
}

static bool canExportNativeFromLocalTemplate(const char* system)
{
#if defined(__TIC_WINDOWS__)
    return strcmp(system, "win") == 0;
#elif defined(__TIC_LINUX__)
    return strcmp(system, "linux") == 0;
#elif defined(__TIC_MACOSX__)
    return strcmp(system, "mac") == 0;
#else
    (void)system;
    return false;
#endif
}

// Same-platform native export prefers the local executable template.
// If the local template is not applicable or unavailable, caller falls back to server export.
static bool tryExportNativeFromLocalTemplate(Console* console, const char* name, const char* system)
{
    if(!canExportNativeFromLocalTemplate(system))
        return false;

    const char* appPath = fs_apppath();

    if(!appPath)
        return false;

    s32 appSize = 0;
    u8* app = fs_read(appPath, &appSize);

    if(!app)
        return false;

    if(appSize <= 0)
    {
        free(app);
        return false;
    }

    bool success = false;

    SCOPE(free(app))
    {
        s32 size = appSize;
        void* buf = embed_cart(console->tic, app, &size);

        if(buf) SCOPE(free(buf))
            {
                const char* path = tic_fs_path(console->fs, name);

                success = fs_write(path, buf, size);

                if(success)
                {
                    chmod(path, DEFAULT_CHMOD);

                    printNewLine(console);
                    printBack(console, "using local native template...");
                    onFileExported(console, name, true);
                }
            }
    }

    return success;
}

static inline void exportNativeGame(Console* console, const char* name, const char* system, ExportParams params)
{
#if defined(TIC80_PRO)
    // alone=1 wants an editorless player, and the local template is this very
    // client, editors and all: only the server keeps editorless stubs.
    bool local = !params.alone;
#else
    bool local = true;
#endif

    if(local && tryExportNativeFromLocalTemplate(console, name, system))
        return;

    if(local && canExportNativeFromLocalTemplate(system))
    {
        printNewLine(console);
        printBack(console, "local native template failed, using server template...");
    }

    exportGame(console, name, system, onNativeExportGet, params);
}

// The export page is the site's own player page, fetched after the stub and
// rewritten here: the title becomes the export's name, and the arguments
// marker becomes the cartridge — that is what makes the loader preload it
// (main.c emsStart reads argv[1]) instead of opening its file picker. One
// page in the tree is the point: a second, export-only copy had already
// drifted from the player's, and mobile lost its touch controls in the
// meantime.
// The title comes from a file name, so the characters that would close the
// element or open markup are escaped: a cart called `a<b>tic` is legal on
// Linux and used to produce broken markup.
static void htmlEscape(char* dst, s32 size, const char* src)
{
    s32 i = 0;

    for(; *src && i < size - 6; src++)
    {
        switch(*src)
        {
            case '<':
                memcpy(dst + i, "&lt;", 4);
                i += 4;
                break;
            case '>':
                memcpy(dst + i, "&gt;", 4);
                i += 4;
                break;
            case '&':
                memcpy(dst + i, "&amp;", 5);
                i += 5;
                break;
            default: dst[i++] = *src; break;
        }
    }

    dst[i] = '\0';
}

static bool patchHtmlTitle(char* page, const char* title)
{
    // from <head>: the argument patch anchors at the Module object for the
    // same reason — a comment above the real tag must not take the patch
    char* head = strstr(page, "<head>");
    char* open = strstr(head ? head : page, "<title>");
    char* close = open ? strstr(open, "</title>") : NULL;

    if(!close) return false;

    char* inner = open + strlen("<title>");
    s32 len = (s32)strlen(title);

    memmove(inner + len, close, strlen(close) + 1);
    memcpy(inner, title, len);

    return true;
}

static bool patchHtmlArgument(char* page)
{
    static const char find[] = "arguments: []";
    static const char repl[] = "arguments: ['cart.tic']";

    // anchored at the Module object, not the first match anywhere: a comment
    // that happens to spell the marker out would otherwise take the patch,
    // the real argument list would stay empty, and the export would open the
    // player instead of the game with nothing reported as wrong.
    char* module = strstr(page, "var Module");
    char* at = strstr(module ? module : page, find);

    if(!at) return false;

    char* tail = at + strlen(find);

    memmove(at + strlen(repl), tail, strlen(tail) + 1);
    memcpy(at, repl, strlen(repl));

    return true;
}

static void onHtmlPageGet(const net_get_data* data)
{
    GameExportData* exportData = (GameExportData*)data->calldata;
    Console* console = exportData->console;

    // onExportGet frees exportData on its error branch, so the error is
    // handled here: delegating and then freeing would free it twice and read
    // the freed struct (a 404 on the page, or an offline run, is enough).
    if(data->type == net_get_error)
    {
        printNewLine(console);
        printError(console, "file downloading error :(");
        commandDone(console);
        free(exportData->stub); // set by the stub stage; free(NULL) is fine
        free(exportData);
        return;
    }

    if(data->type == net_get_progress)
    {
        onExportGet(data);
        return;
    }

    tic_mem* tic = console->tic;

    char filename[TICNAME_MAX];
    strcpy(filename, exportData->filename);

    char title[TICNAME_MAX];
    strcpy(title, filename);

    {
        char* ext = strrchr(title, '.');
        if(ext) *ext = '\0';
    }

    // the page plus the room the injected title and argument need: an
    // escaped title is up to six bytes per character
    char* page = malloc(data->done.size + TICNAME_MAX * 6 + 64);
    memcpy(page, data->done.data, data->done.size);
    page[data->done.size] = '\0';

    // a page that no longer carries the markers is not worth shipping: the
    // export would open the picker instead of the game
    char escaped[TICNAME_MAX * 6];
    htmlEscape(escaped, sizeof escaped, title);

    bool errorOccurred = !patchHtmlTitle(page, escaped) || !patchHtmlArgument(page);

    const char* zipPath = tic_fs_path(console->fs, filename);

    // Only a file this run has written may be removed below. The zip is
    // replaced in place, so the path can hold an earlier export of the same
    // game: a run that fails before its first byte — the page no longer
    // carrying the markers, or a write that cannot even start, which leaves
    // the old file untouched — must not take that game away with it.
    bool wrote = false;

    if(!errorOccurred)
        errorOccurred = !(wrote = fs_write(zipPath, exportData->stub, exportData->stubSize));

    if(!errorOccurred)
    {
        struct zip_t* zip = zip_open(zipPath, ZIP_DEFAULT_COMPRESSION_LEVEL, 'a');

        if(zip) SCOPE(zip_close(zip))
            {
                // every entry call is checked: an unchecked one reports a
                // disk-full append to the member as a successful export
                if(zip_entry_open(zip, "index.html") != 0 || zip_entry_write(zip, page, strlen(page)) != 0 || zip_entry_close(zip) != 0)
                    errorOccurred = true;

                void* cart = malloc(TIC_CART_SAVE_SIZE);

                SCOPE(free(cart))
                {
                    s32 cartSize = tic_cart_save(&tic->cart, cart);

                    if(cartSize)
                    {
                        if(zip_entry_open(zip, "cart.tic") != 0 || zip_entry_write(zip, cart, cartSize) != 0 || zip_entry_close(zip) != 0)
                            errorOccurred = true;
                    }
                    else
                        errorOccurred = true;
                }
            }
        else
            errorOccurred = true;
    }

    // a half-written zip is not a game: whoever picks it up would ship a page
    // with no cartridge in it
    if(errorOccurred && wrote) remove(zipPath);

    free(page);
    free(exportData->stub);
    free(exportData);

    onFileExported(console, filename, !errorOccurred);
}

static void onHtmlExportGet(const net_get_data* data)
{
    switch(data->type)
    {
        case net_get_done:
        {
            GameExportData* exportData = (GameExportData*)data->calldata;
            Console* console = exportData->console;

            // the stub zip is needed again once the page arrives, and the
            // net layer frees its buffer as soon as this callback returns
            exportData->stub = malloc(data->done.size);
            memcpy(exportData->stub, data->done.data, data->done.size);
            exportData->stubSize = data->done.size;

            // the site's own page, the one and only: fetched from the player's
            // directory on this build's site — /js/<dir>/, the same directory
            // the stubs come from — rewritten for the game, and written into
            // the zip as index.html, which is the name a host serves.
            char url[TICNAME_MAX] = "/js/" TIC_VERSION_DIR "/index.html";
            tic_net_get(console->net, url, onHtmlPageGet, exportData);
        }
        break;
        default:
            onExportGet(data);
    }
}

static const char* getFilename(const char* filename, const char* ext)
{
    if(strcmp(filename + strlen(filename) - strlen(ext), ext) == 0)
        return filename;

    static char Name[TICNAME_MAX];
    strcpy(Name, filename);
    strcat(Name, ext);

    return Name;
}

static void onExport_win(Console* console, const char* param, const char* filename, ExportParams params)
{
    exportNativeGame(console, getFilename(filename, ".exe"), param, params);
}

static void onExport_linux(Console* console, const char* param, const char* filename, ExportParams params)
{
    exportNativeGame(console, filename, param, params);
}

static void onExport_linuxarm(Console* console, const char* param, const char* filename, ExportParams params)
{
    (void)param;
    exportNativeGame(console, filename, "linuxarm", params);
}

static void onExport_mac(Console* console, const char* param, const char* filename, ExportParams params)
{
    (void)param;
    // arm64 is the default mac target now; the legacy x64 build is macintel.
    exportNativeGame(console, filename, "mac", params);
}

static void onExport_macintel(Console* console, const char* param, const char* filename, ExportParams params)
{
    (void)param;
    exportNativeGame(console, filename, "macintel", params);
}

static void onExport_html(Console* console, const char* param, const char* filename, ExportParams params)
{
    exportGame(console, getFilename(filename, ".zip"), param, onHtmlExportGet, params);
}

static void onExport_tiles(Console* console, const char* param, const char* filename, ExportParams params)
{
    (void)param;
    exportSprites(console, getFilename(filename, PngExt), getBank(console, params.bank)->tiles.data, params);
}

static void onExport_binary(Console* console, const char* param, const char* path, ExportParams params)
{
    (void)param;
    (void)params;
    const char* filename = getFilename(path, ".binary");

    tic_binary* binary = &console->tic->cart.binary;
    // TODO: do we need this buffer at all, could we just handle `binary.data` directly to `tic_fs_save`?
    void* buffer = malloc(binary->size);

    SCOPE(free(buffer))
    {
        memcpy(buffer, binary->data, binary->size);

        onFileExported(console, filename, tic_fs_save(console->fs, filename, buffer, binary->size, true));
    }
}

static void onExport_sprites(Console* console, const char* param, const char* filename, ExportParams params)
{
    (void)param;
    exportSprites(console, getFilename(filename, PngExt), getBank(console, params.bank)->sprites.data, params);
}

static void onExport_map(Console* console, const char* param, const char* path, ExportParams params)
{
    (void)param;
    enum
    {
        Size = sizeof(tic_map)
    };
    const char* filename = getFilename(path, ".map");

    void* buffer = malloc(Size);

    SCOPE(free(buffer))
    {
        tic_map* map = &getBank(console, params.bank)->map;
        memcpy(buffer, map->data, Size);

        onFileExported(console, filename, tic_fs_save(console->fs, filename, buffer, Size, true));
    }
}

static void onExport_mapimg(Console* console, const char* param, const char* path, ExportParams params)
{
    (void)param;
    const char* filename = getFilename(path, ".png");

    enum
    {
        Width = TIC_MAP_WIDTH * TIC_SPRITESIZE,
        Height = TIC_MAP_HEIGHT * TIC_SPRITESIZE
    };

    png_img img = {.width = Width, .height = Height, .pixels = malloc(Width * Height * sizeof(png_rgba))};

    SCOPE(free(img.data))
    {
        {
            tic_mem* tic = console->tic;

            tic_api_sync(tic, (u32)-1, params.bank, false);

            for(s32 r = 0; r < TIC_MAP_ROWS; r++)
                for(s32 c = 0; c < TIC_MAP_COLS; c++)
                {
                    tic_api_map(tic, c * TIC_MAP_SCREEN_WIDTH, r * TIC_MAP_SCREEN_HEIGHT,
                                TIC_MAP_SCREEN_WIDTH, TIC_MAP_SCREEN_HEIGHT, 0, 0, NULL, 0, 1, NULL, NULL);

                    tic_core_blit(tic);

                    for(s32 j = 0; j < TIC80_HEIGHT; j++)
                        for(s32 i = 0; i < TIC80_WIDTH; i++)
                            img.values[(i + c * TIC80_WIDTH) + (j + r * TIC80_HEIGHT) * Width] =
                                tic->product.screen[(i + TIC80_MARGIN_LEFT) + (j + TIC80_MARGIN_TOP) * TIC80_FULLWIDTH];
                }
        }

        png_buffer png = png_write(img, (png_buffer){NULL, 0});

        SCOPE(free(png.data))
        {
            onFileExported(console, filename, tic_fs_save(console->fs, filename, png.data, png.size, true));
        }
    }
}

static void onExported(Console* console, const ConsoleAnswer* answer)
{
    onFileExported(console, console->exportName, answer->ok);
}

static void onExport_sfx(Console* console, const char* param, const char* name, ExportParams params)
{
    (void)param;
    const char* filename = getFilename(name, ".wav");

    if(params.id >= 0 && params.id < SFX_COUNT)
    {
        strcpy(console->exportName, filename);

        console->ask = (ConsoleAsk){.kind = CONSOLE_ASK_EXPORT_SFX, .name = console->exportName, .index = params.id};
        console->onAnswer = onExported;
    }
    else
        onFileExported(console, filename, false);
}

static void onExport_music(Console* console, const char* type, const char* name, ExportParams params)
{
    (void)type;
    const char* filename = getFilename(name, ".wav");

    if(params.id >= 0 && params.id < MUSIC_TRACKS)
    {
        strcpy(console->exportName, filename);

        console->ask = (ConsoleAsk){.kind = CONSOLE_ASK_EXPORT_MUSIC, .name = console->exportName, .index = params.id, .bank = params.bank};
        console->onAnswer = onExported;
    }
    else
        onFileExported(console, filename, false);
}

static void onExport_screen(Console* console, const char* param, const char* name, ExportParams params)
{
    (void)param;
    const char* filename = getFilename(name, ".png");

    png_img img = {.width = TIC80_WIDTH, .height = TIC80_HEIGHT, .pixels = malloc(TIC80_WIDTH * TIC80_HEIGHT * sizeof(png_rgba))};

    SCOPE(free(img.data))
    {
        const tic_palette* pal = getPalette(console, params.bank, params.vbank);

        tic_bank* bank = getBank(console, params.bank);
        for(s32 i = 0; i < TIC80_WIDTH * TIC80_HEIGHT; i++)
            img.values[i] = tic_rgba(&pal->colors[tic_tool_peek4(bank->screen.data, i)]);

        png_buffer png = png_write(img, (png_buffer){NULL, 0});

        SCOPE(free(png.data))
        {
            onFileExported(console, filename, tic_fs_save(console->fs, filename, png.data, png.size, true));
        }
    }
}

static void onExport_help(Console* console, const char* param, const char* name, ExportParams params);

static void onExportCommand(Console* console)
{
    if(console->desc->count > 1)
    {
        ExportParams params = {0};

        for(const struct Param *it = console->desc->params, *end = it + console->desc->count; it < end; ++it)
        {
#define EXPORT_KEYS_DEF(name) \
    if(it->val && strcmp(it->key, #name) == 0) params.name = atoi(it->val);
            EXPORT_KEYS_LIST(EXPORT_KEYS_DEF)
#undef EXPORT_KEYS_DEF
        }

        const char* filename = console->desc->params[1].key;

        static const struct Handler
        {
            const char* type;
            void (*handler)(Console*, const char*, const char*, ExportParams);
        } Handlers[] =
            {
#define EXPORT_CMD_DEF(name, label) {#name, onExport_##name},
                EXPORT_CMD_LIST(EXPORT_CMD_DEF)
#undef EXPORT_CMD_DEF
            };

        const char* type = console->desc->params[0].key;

        FOR(const struct Handler*, ptr, Handlers)
        if(strcmp(type, ptr->type) == 0)
        {
            ptr->handler(console, type, filename, params);
            return;
        }
    }

    {
        printError(console, "\nerror: invalid parameters.");
        printUsage(console, console->desc->command);
        commandDone(console);
    }
}

const char* readMetatag(const char* code, const char* tag, const char* comment);

static void onSaved(Console* console, const ConsoleAnswer* answer)
{
    if(answer->save == CART_SAVE_OK)
    {
        printBack(console, "\ncart ");
        printFront(console, answer->name);
        printBack(console, " saved!\n");
    }
    else if(answer->save == CART_SAVE_MISSING_NAME)
        printBack(console, "\ncart name is missing\n");
    else
        printBack(console, "\ncart saving error");

    commandDone(console);
}

static void onSaveCommandConfirmed(Console* console, const void* data)
{
    (void)data;
    console->ask = (ConsoleAsk){.kind = CONSOLE_ASK_CART_SAVE, .name = console->desc->count ? console->desc->params->key : NULL};
    console->onAnswer = onSaved;
}

static void onSaveCommand(Console* console)
{
    const char* param = console->desc->count ? console->desc->params->key : NULL;

    if(param && strlen(param) &&
       (tic_fs_exists(console->fs, param) ||
        tic_fs_exists(console->fs, tic_tool_cart_name(param))))
    {
        static const char* Rows[] =
            {
                "WARNING!",
                "The cart already exists",
                "Do you want to overwrite it?",
            };

        confirmCommand(console, Rows, COUNT_OF(Rows), onSaveCommandConfirmed, NULL);
    }
    else
    {
        onSaveCommandConfirmed(console, NULL);
    }
}

static void onRunCommand(Console* console)
{
    commandDone(console);

    askStart(console, CONSOLE_ASK_RUN, NULL);
}

static void onResumeCommand(Console* console)
{
    if(console->desc->count)
    {
        const char* param = console->desc->params->key;

        if(strcmp(param, "reload") == 0)
        {
            const tic_script* script_config = tic_get_script(console->tic);
            if(!script_config->eval)
            {
                printError(console, "eval not implemented for the script");
            }
            // `resume reload` re-evaluates the cart into the running VM, so it
            // needs one for the same reason `eval` does.
            else if(!tic_core_script_ready(console->tic))
            {
                printError(console, "no cart is running, RUN one first");
            }
            else
            {
                script_config->eval(console->tic, console->tic->cart.code.data);
            }
        }
    }
    commandDone(console);

    askStart(console, CONSOLE_ASK_RESUME, NULL);
}

static void onEvalCommand(Console* console)
{
    printLine(console);

    const tic_script* script_config = tic_get_script(console->tic);

    if(script_config->eval)
    {
        if(!console->desc->count)
            printError(console, "nothing to eval");
        // Every runtime evaluates against the VM the cart left behind, and
        // returns without a word when there is none -- which reads as `eval`
        // silently doing nothing. Say what is missing instead.
        else if(!tic_core_script_ready(console->tic))
            printError(console, "no cart is running, RUN one first");
        else
            script_config->eval(console->tic,
                                console->desc->src + strlen(console->desc->command));
    }
    else
    {
        printError(console, "'eval' not implemented for the script");
    }

    commandDone(console);
}

static void onDelCommandConfirmed(Console* console, const void* data)
{
    (void)data;
    if(console->desc->count)
    {
        if(tic_fs_ispubdir(console->fs))
        {
            printError(console, "\naccess denied");
        }
        else
        {
            const char* param = console->desc->params->key;
            if(tic_fs_isdir(console->fs, param))
            {
                printBack(console, tic_fs_deldir(console->fs, param)
                                       ? "\ndir not deleted"
                                       : "\ndir successfully deleted");
            }
            else
            {
                printBack(console, tic_fs_delfile(console->fs, param)
                                       ? "\nfile not deleted"
                                       : "\nfile successfully deleted");
            }
        }
    }
    else
        printBack(console, "\nname is missing");

    commandDone(console);
}

static void onDelCommand(Console* console)
{
    static const char* Rows[] =
        {
            "WARNING!",
            "Do you really want to delete file?",
        };

    confirmCommand(console, Rows, COUNT_OF(Rows), onDelCommandConfirmed, NULL);
}

#if defined(CAN_ADDGET_FILE)

static void onAddFile(Console* console, const char* name, const u8* buffer, s32 size)
{
    if(name)
    {
        const char* path = tic_fs_path(console->fs, name);

        if(!fs_exists(path))
        {
            if(fs_write(path, buffer, size))
            {
                printLine(console);
                printFront(console, name);
                printBack(console, " successfully added :)");
            }
            else
                printError(console, "\nerror: file not added :(");
        }
        else
        {
            printError(console, "\nerror: ");
            printError(console, name);
            printError(console, " already exists :(");
        }
    }

    commandDone(console);
}

// The page hands the picked file back here: emscripten no longer emits the dynCall
// the popup was written against, and its other web callbacks are exported calls too.
EMSCRIPTEN_KEEPALIVE void tic80_add_file(Console* console, const char* name, const u8* buffer, s32 size)
{
    onAddFile(console, name, buffer, size);
}

static void onAddCommand(Console* console)
{
    // clang-format off
    EM_ASM_
    ({
        Module.showAddPopup(function(filename, rom)
        {
            if(filename == null || rom == null)
            {
                Module._tic80_add_file($0, 0, 0, 0);
            }
            else
            {
                var filePtr = _malloc(filename.length + 1);
                stringToUTF8(filename, filePtr, filename.length + 1);

                var dataPtr = _malloc(rom.length);
                HEAPU8.set(rom, dataPtr);

                Module._tic80_add_file($0, filePtr, dataPtr, rom.length);

                _free(filePtr);
                _free(dataPtr);
            }
        });
    }, console);
    // clang-format on
}

static void onGetCommand(Console* console)
{
    if(console->desc->count)
    {
        const char* name = console->desc->params->key;
        const char* path = tic_fs_path(console->fs, name);

        if(fs_exists(path))
        {
            s32 size = 0;
            void* buffer = fs_read(path, &size);

            // clang-format off
            EM_ASM_
            ({
                var name = UTF8ToString($0);
                var blob = new Blob([HEAPU8.subarray($1, $1 + $2)], {type: "application/octet-stream"});

                Module.saveAs(blob, name);
            }, name, buffer, size);
            // clang-format on
        }
        else
        {
            printError(console, "\nerror: ");
            printError(console, name);
            printError(console, " doesn't exist :(");
        }
    }
    else
        printBack(console, "\nusage: get <file>");

    commandDone(console);
}

#endif

// Declare this here to resolve a cyclic dependency with COMMANDS_LIST.
static void tabCompleteHelp(TabCompleteData* data);

static const char HelpUsage[] = "help [<text>"
#define HELP_CMD_DEF(name, label) " " #name
    HELP_CMD_LIST(HELP_CMD_DEF)
#undef HELP_CMD_DEF
        "]";

// The alternatives below are separated by a space rather than glued with
// "|": the line needs somewhere to wrap, in the console and in the
// markdown tables of the /learn page, where one long run of names used to
// push the table past the page container.
#define SECTION_DEF(NAME, ...)      " " #NAME
#define EXPORT_CMD_DEF(name, label) #name " "
#define EXPORT_KEYS_DEF(name)       #name "=0 "
#define IMPORT_CMD_DEF(name)        #name " "
#define IMPORT_KEYS_DEF(key)        #key "=0 "

#if defined(CAN_ADDGET_FILE)
// clang-format off
#define ADDGET_FILE(macro)                                                              \
    macro("add",                                                                        \
        NULL,                                                                           \
        "Upload file to the browser local storage.",                                    \
        NULL,                                                                           \
        onAddCommand,                                                                   \
        NULL,                                                                           \
        NULL)                                                                           \
                                                                                        \
    macro("get",                                                                        \
        NULL,                                                                           \
        "Download file from the browser local storage.",                                \
        "get <file>",                                                                   \
        onGetCommand,                                                                   \
        tabCompleteFiles,                                                               \
        NULL)

// clang-format on
#else
#define ADDGET_FILE(macro)
#endif

// macro(name, alt, help, usage, handler, tab-complete for first param, for second param)
// The browser's command exists only where the browser does.
#if defined(BUILD_SURF)
// clang-format off
#define SURF_CMD(macro)                                                     \
    macro("surf", NULL, "Open carts browser.", NULL, onSurfCommand, NULL, NULL)
// clang-format on
#else
#define SURF_CMD(macro)
#endif

// clang-format off
#define COMMANDS_LIST(macro)                                                            \
    macro("help",                                                                       \
        NULL,                                                                           \
        "Show help info about commands/api/...",                                        \
        HelpUsage,                                                                      \
        onHelpCommand,                                                                  \
        tabCompleteHelp,                                                                \
        NULL)                                                                           \
                                                                                        \
    macro("exit",                                                                       \
        "quit",                                                                         \
        "Exit the application (Hotkey: CTRL+Q).",                                       \
        NULL,                                                                           \
        onExitCommand,                                                                  \
        NULL,                                                                           \
        NULL)                                                                           \
                                                                                        \
    macro("edit",                                                                       \
        NULL,                                                                           \
        "Open cart editors (Hotkey: ESC or F1).",                                       \
        NULL,                                                                           \
        onEditCommand,                                                                  \
        NULL,                                                                           \
        NULL)                                                                           \
                                                                                        \
    macro("new",                                                                        \
        NULL,                                                                           \
        "Creates a new `Hello World` cartridge.",                                       \
        "new <$LANG_NAMES_SPACED$>",                                                    \
        onNewCommand,                                                                   \
        tabCompleteLanguages,                                                           \
        NULL)                                                                           \
                                                                                        \
    macro("load",                                                                       \
        NULL,                                                                           \
        "Load cartridge from the local filesystem"                                      \
        "(there's no need to type the .tic extension).\n"                               \
        "You can also load just the section (sprites, map, screen etc)"                 \
        "from another cart.",                                                           \
        "load <cart> [code" TIC_SYNC_LIST(SECTION_DEF) "]",                             \
        onLoadCommand,                                                                  \
        tabCompleteFiles,                                                               \
        NULL)                                                                           \
                                                                                        \
    macro("save",                                                                       \
        NULL,                                                                           \
        "Save cartridge to the local filesystem (Hotkey: CTRL+S), use $LANG_EXTENSIONS$"\
        "cart extension to save it in text format (PRO feature).\n"                     \
        "Use .png file extension to save it as a png cart.",                            \
        "save <cart>",                                                                  \
        onSaveCommand,                                                                  \
        tabCompleteFiles,                                                               \
        NULL)                                                                           \
                                                                                        \
    macro("run",                                                                        \
        NULL,                                                                           \
        "Run current cart / project (Hotkey: CTRL+R).",                                 \
        NULL,                                                                           \
        onRunCommand,                                                                   \
        NULL,                                                                           \
        NULL)                                                                           \
                                                                                        \
    macro("resume",                                                                     \
        NULL,                                                                           \
        "Resume last run cart / project. Reload game code\n"                            \
        "first if given reload as an argument.",                                        \
        "resume [reload]",                                                              \
        onResumeCommand,                                                                \
        NULL,                                                                           \
        NULL)                                                                           \
                                                                                        \
    macro("eval",                                                                       \
        "=",                                                                            \
        "Run provided code within the console, "                                        \
        "useful for debugging and testing.\n"                                           \
        "\nTips\n"                                                                      \
        "- Use trace() to log the results. Eg: eval trace(2+2)\n"                       \
        "- The virtual machine should be launched first by "                            \
        "running a cart; otherwise it will output an empty string.",                    \
        NULL,                                                                           \
        onEvalCommand,                                                                  \
        NULL,                                                                           \
        NULL)                                                                           \
                                                                                        \
    macro("dir",                                                                        \
        "ls",                                                                           \
        "Show list of local files.",                                                    \
        NULL,                                                                           \
        onDirCommand,                                                                   \
        NULL,                                                                           \
        NULL)                                                                           \
                                                                                        \
    macro("cd",                                                                         \
        NULL,                                                                           \
        "Change directory.",                                                            \
        "\ncd <path>\ncd /\ncd ..",                                                     \
        onChangeDirectory,                                                              \
        tabCompleteDirs,                                                                \
        NULL)                                                                           \
                                                                                        \
    macro("mkdir",                                                                      \
        NULL,                                                                           \
        "Make a directory.",                                                            \
        "mkdir <name>",                                                                 \
        onMakeDirectory,                                                                \
        NULL,                                                                           \
        NULL)                                                                           \
                                                                                        \
    macro("folder",                                                                     \
        NULL,                                                                           \
        "Open working directory in OS.",                                                \
        NULL,                                                                           \
        onFolderCommand,                                                                \
        NULL,                                                                           \
        NULL)                                                                           \
                                                                                        \
    macro("export",                                                                     \
        NULL,                                                                           \
        "Export cart to HTML,\n"                                                        \
        "native build (win linux linuxarm mac macintel),\n"                                           \
        "export sprites/map/... as a .png image "                                       \
        "or export sfx and music to .wav files.",                                       \
        "\nexport [" EXPORT_CMD_LIST(EXPORT_CMD_DEF) "] "                            \
        "<file> [" EXPORT_KEYS_LIST(EXPORT_KEYS_DEF) "]" ,                           \
        onExportCommand,                                                                \
        tabCompleteExport,                                                              \
        tabCompleteFiles)                                                               \
                                                                                        \
    macro("import",                                                                     \
        NULL,                                                                           \
        "Import code/sprites/map/... from an external file.\n"                          \
        "While importing images, colors are merged to the "                             \
        "closest color of the palette.",                                                \
        "\nimport [" IMPORT_CMD_LIST(IMPORT_CMD_DEF) "] "                            \
        "<file> [" IMPORT_KEYS_LIST(IMPORT_KEYS_DEF) "]",                            \
        onImportCommand,                                                                \
        tabCompleteImport,                                                              \
        tabCompleteFiles)                                                               \
                                                                                        \
    macro("del",                                                                        \
        "rm",                                                                           \
        "Delete from the filesystem.",                                                  \
        "del <file folder>",                                                            \
        onDelCommand,                                                                   \
        tabCompleteFilesAndDirs,                                                        \
        NULL)                                                                           \
                                                                                        \
    macro("cls",                                                                        \
        "clear",                                                                        \
        "Clear console screen.",                                                        \
        NULL,                                                                           \
        onClsCommand,                                                                   \
        NULL,                                                                           \
        NULL)                                                                           \
                                                                                        \
    macro("demo",                                                                       \
        NULL,                                                                           \
        "Install demo carts to the current directory.",                                 \
        NULL,                                                                           \
        onInstallDemosCommand,                                                          \
        NULL,                                                                           \
        NULL)                                                                           \
                                                                                        \
    macro("config",                                                                     \
        NULL,                                                                           \
        "Edit system configuration cartridge.\n"                                        \
        "Use `reset` param to reset current configuration.\n"                           \
        "Use `default` to edit default cart template.",                                 \
        "config [reset default]",                                                       \
        onConfigCommand,                                                                \
        tabCompleteConfig,                                                              \
        NULL)                                                                           \
                                                                                        \
    SURF_CMD(macro)                                                                     \
                                                                                        \
    macro("menu",                                                                       \
        NULL,                                                                           \
        "Show menu where you can setup video, sound and input options.",                \
        NULL,                                                                           \
        onGameMenuCommand,                                                              \
        NULL,                                                                           \
        NULL)                                                                           \
    ADDGET_FILE(macro)
// clang-format on

static struct Command
{
    const char* name;
    const char* alt;
    const char* help;
    const char* usage;
    void (*handler)(Console*);
    void (*tabComplete1)(TabCompleteData*);
    void (*tabComplete2)(TabCompleteData*);

} Commands[] =
    {
#define COMMANDS_DEF(name, alt, help, usage, handler, tabComplete1, tabComplete2) \
    {name, alt, help, usage, handler, tabComplete1, tabComplete2},
        COMMANDS_LIST(COMMANDS_DEF)
#undef COMMANDS_DEF
};

#undef SECTION_DEF
#undef EXPORT_CMD_DEF
#undef EXPORT_KEYS_DEF
#undef IMPORT_CMD_DEF
#undef IMPORT_KEYS_DEF

typedef struct Command Command;

// clang-format off
#define API_LIST(macro)         \
    TIC_CALLBACK_LIST(macro)    \
    TIC_API_LIST(macro)
// clang-format on

static struct ApiItem
{
    const char* name;
    const char* def;
    const char* help;
} Api[] =
    {
#define TIC_API_DEF(name, def, help, ...) {#name, def, help},
        API_LIST(TIC_API_DEF)
#undef TIC_API_DEF
};

typedef struct ApiItem ApiItem;

static void tabCompleteHelp(TabCompleteData* data)
{
#define HELP_CMD_DEF(name, label) addTabCompleteOption(data, #name);
    HELP_CMD_LIST(HELP_CMD_DEF)
#undef HELP_CMD_DEF

    for(s32 i = 0; i < COUNT_OF(Commands); i++)
    {
        addTabCompleteOption(data, Commands[i].name);
    }

#define TIC_API_DEF(name, def, help, ...) addTabCompleteOption(data, #name);
    API_LIST(TIC_API_DEF)
#undef TIC_API_DEF

    finishTabComplete(data);
}

// The RAM/VRAM maps and the button/key tables, each defined ONCE. `help ram`
// and its siblings draw them as ASCII tables for the console, and `export
// help` writes the same rows as markdown for the website; the two outputs
// have to agree row for row, so a copy per output is a copy that drifts.
// Until 19.09 they were exactly that, and one pair had already drifted: the
// VRAM table's reserved row kept a trailing space on the console side only,
// which the markdown copy had lost.
//
// The address tables end in a sentinel holding the region's end address: a
// row's size is the distance to the next one, so the writers stop short of
// the last entry.

typedef struct
{
    s32 addr;
    const char* info;
} RamRow;
typedef struct
{
    s32 code;
    const char* key;
} KeyRow;

static const RamRow RamRows[] =
    {
        {0, "VRAM"},
        {offsetof(tic_ram, tiles), "TILES"},
        {offsetof(tic_ram, sprites), "SPRITES"},
        {offsetof(tic_ram, map), "MAP"},
        {offsetof(tic_ram, input.gamepads), "GAMEPADS"},
        {offsetof(tic_ram, input.mouse), "MOUSE"},
        {offsetof(tic_ram, input.keyboard), "KEYBOARD"},
        {offsetof(tic_ram, sfxpos), "SFX STATE"},
        {offsetof(tic_ram, registers), "SOUND REGISTERS"},
        {offsetof(tic_ram, sfx.waveforms), "WAVEFORMS"},
        {offsetof(tic_ram, sfx.samples), "SFX"},
        {offsetof(tic_ram, music.patterns.data), "MUSIC PATTERNS"},
        {offsetof(tic_ram, music.tracks.data), "MUSIC TRACKS"},
        {offsetof(tic_ram, music_state), "MUSIC STATE"},
        {offsetof(tic_ram, stereo), "STEREO VOLUME"},
        {offsetof(tic_ram, persistent), "PERSISTENT MEMORY"},
        {offsetof(tic_ram, flags), "SPRITE FLAGS"},
        {offsetof(tic_ram, font.regular), "FONT"},
        {offsetof(tic_ram, font.regular.params), "FONT PARAMS"},
        {offsetof(tic_ram, font.alt), "ALT FONT"},
        {offsetof(tic_ram, font.alt.params), "ALT FONT PARAMS"},
        {offsetof(tic_ram, mapping), "BUTTONS MAPPING"},
        {offsetof(tic_ram, pcm), "PCM SAMPLES"},
        {offsetof(tic_ram, free), "** RESERVED **"},
        {TIC_RAM_SIZE, ""},
};

static const RamRow VRamRows[] =
    {
        {offsetof(tic_ram, vram.screen), "SCREEN"},
        {offsetof(tic_ram, vram.palette), "PALETTE"},
        {offsetof(tic_ram, vram.mapping), "PALETTE MAP"},
        {offsetof(tic_ram, vram.vars), "BORDER COLOR"},
        {offsetof(tic_ram, vram.vars.offset), "SCREEN OFFSET"},
        {offsetof(tic_ram, vram.vars.cursor), "MOUSE CURSOR"},
        {offsetof(tic_ram, vram.blit), "BLIT SEGMENT"},
        {offsetof(tic_ram, vram.reserved), "... (reserved)"},
        {TIC_VRAM_SIZE, ""},
};

// One entry per action, in P1 order; players 2-4 follow at +8 per player.
static const char* ButtonActions[] = {"UP", "DOWN", "LEFT", "RIGHT", "A", "B", "X", "Y"};

static const KeyRow KeyRows[] =
    {
        {1, "A"},
        {2, "B"},
        {3, "C"},
        {4, "D"},
        {5, "E"},
        {6, "F"},
        {7, "G"},
        {8, "H"},
        {9, "I"},
        {10, "J"},
        {11, "K"},
        {12, "L"},
        {13, "M"},
        {14, "N"},
        {15, "O"},
        {16, "P"},
        {17, "Q"},
        {18, "R"},
        {19, "S"},
        {20, "T"},
        {21, "U"},
        {22, "V"},
        {23, "W"},
        {24, "X"},
        {25, "Y"},
        {26, "Z"},
        {27, "0"},
        {28, "1"},
        {29, "2"},
        {30, "3"},
        {31, "4"},
        {32, "5"},
        {33, "6"},
        {34, "7"},
        {35, "8"},
        {36, "9"},
        {37, "MINUS"},
        {38, "EQUALS"},
        {39, "LEFTBRACKET"},
        {40, "RIGHTBRACKT"},
        {41, "BACKSLASH"},
        {42, "SEMICOLON"},
        {43, "APOSTROPHE"},
        {44, "GRAVE"},
        {45, "COMMA"},
        {46, "PERIOD"},
        {47, "SLASH"},
        {48, "SPACE"},
        {49, "TAB"},
        {50, "RETURN"},
        {51, "BACKSPACE"},
        {52, "DELETE"},
        {53, "INSERT"},
        {54, "PAGEUP"},
        {55, "PAGEDOWN"},
        {56, "HOME"},
        {57, "END"},
        {58, "UP"},
        {59, "DOWN"},
        {60, "LEFT"},
        {61, "RIGHT"},
        {62, "CAPSLOCK"},
        {63, "CTRL"},
        {64, "SHIFT"},
        {65, "ALT"},
        {66, "ESC"},
        {67, "F1"},
        {68, "F2"},
        {69, "F3"},
        {70, "F4"},
        {71, "F5"},
        {72, "F6"},
        {73, "F7"},
        {74, "F8"},
        {75, "F9"},
        {76, "F10"},
        {77, "F11"},
        {78, "F12"},
        {79, "NUM0"},
        {80, "NUM1"},
        {81, "NUM2"},
        {82, "NUM3"},
        {83, "NUM4"},
        {84, "NUM5"},
        {85, "NUM6"},
        {86, "NUM7"},
        {87, "NUM8"},
        {88, "NUM9"},
        {89, "NUMPLUS"},
        {90, "NUMMINUS"},
        {91, "NUMMULTIPLY"},
        {92, "NUMDIVIDE"},
        {93, "NUMENTER"},
        {94, "NUMPERIOD"},
};

static s32 createRamTable(char* buf)
{
    char* ptr = buf;
    ptr += sprintf(ptr, "\n+-----------------------------------+"
                        "\n|           96KB RAM LAYOUT         |"
                        "\n+-------+-------------------+-------+"
                        "\n| ADDR  | INFO              | BYTES |"
                        "\n+-------+-------------------+-------+");

    for(const RamRow *row = RamRows, *end = row + COUNT_OF(RamRows) - 1; row < end; row++)
        ptr += sprintf(ptr, "\n| %05X | %-17s | %-5i |", row->addr, row->info, (row + 1)->addr - row->addr);

    ptr += sprintf(ptr, "\n+-------+-------------------+-------+\n");

    return (s32)(ptr - buf);
}

static s32 createVRamTable(char* buf)
{
    char* ptr = buf;
    ptr += sprintf(ptr, "\n+-----------------------------------+"
                        "\n|          16KB VRAM LAYOUT         |"
                        "\n+-------+-------------------+-------+"
                        "\n| ADDR  | INFO              | BYTES |"
                        "\n+-------+-------------------+-------+");

    for(const RamRow *row = VRamRows, *end = row + COUNT_OF(VRamRows) - 1; row < end; row++)
        ptr += sprintf(ptr, "\n| %05X | %-17s | %-5i |", row->addr, row->info, (row + 1)->addr - row->addr);

    ptr += sprintf(ptr, "\n+-------+-------------------+-------+\n");

    return (s32)(ptr - buf);
}

static s32 createKeysTable(char* buf)
{
    char* ptr = buf;
    ptr += sprintf(ptr, "\n+----+------------+ +----+------------+"
                        "\n|CODE|    KEY     | |CODE|    KEY     |"
                        "\n+----+------------+ +----+------------+");

    for(const KeyRow *row = KeyRows, *alt = row + COUNT_OF(KeyRows) / 2, *end = alt; row != end; ++row, ++alt)
    {
        ptr += sprintf(ptr, "\n| %2d | %-11s| | %2d | %-11s|", row->code, row->key, alt->code, alt->key);
    }

    ptr += sprintf(ptr, "\n+----+------------+ +----+------------+\n");

    return (s32)(ptr - buf);
}

static s32 createButtonsTable(char* buf)
{
    char* ptr = buf;
    ptr += sprintf(ptr, "\n+--------+----+----+----+----+"
                        "\n| ACTION | P1 | P2 | P3 | P4 |"
                        "\n+--------+----+----+----+----+");

    int id = 0;
    for(const char **it = ButtonActions, **end = it + COUNT_OF(ButtonActions); it < end; ++it, ++id)
        ptr += sprintf(ptr, "\n| %6s | %2d | %2d | %2d | %2d |", *it, id, id + 8, id + 16, id + 24);

    ptr += sprintf(ptr, "\n+--------+----+----+----+----+\n");

    return (s32)(ptr - buf);
}

static s32 createRamTableMd(char* buf)
{
    char* ptr = buf;
    ptr += sprintf(ptr, "\n### RAM layout (96KB)\n\n| ADDR | INFO | BYTES |\n|---|---|---|\n");

    for(const RamRow *row = RamRows, *end = row + COUNT_OF(RamRows) - 1; row < end; row++)
        ptr += sprintf(ptr, "| %05X | %s | %i |\n", row->addr, row->info, (row + 1)->addr - row->addr);

    return (s32)(ptr - buf);
}

static s32 createVRamTableMd(char* buf)
{
    char* ptr = buf;
    ptr += sprintf(ptr, "\n### VRAM layout (16KB)\n\n| ADDR | INFO | BYTES |\n|---|---|---|\n");

    for(const RamRow *row = VRamRows, *end = row + COUNT_OF(VRamRows) - 1; row < end; row++)
        ptr += sprintf(ptr, "| %05X | %s | %i |\n", row->addr, row->info, (row + 1)->addr - row->addr);

    return (s32)(ptr - buf);
}

static s32 createButtonsTableMd(char* buf)
{
    char* ptr = buf;
    ptr += sprintf(ptr, "\n| ACTION | P1 | P2 | P3 | P4 |\n|---|---|---|---|---|\n");

    int id = 0;
    for(const char **it = ButtonActions, **end = it + COUNT_OF(ButtonActions); it < end; ++it, ++id)
        ptr += sprintf(ptr, "| %s | %d | %d | %d | %d |\n", *it, id, id + 8, id + 16, id + 24);

    return (s32)(ptr - buf);
}

static s32 createKeysTableMd(char* buf)
{
    char* ptr = buf;
    ptr += sprintf(ptr, "\n| CODE | KEY | CODE | KEY |\n|---|---|---|---|\n");

    for(const KeyRow *row = KeyRows, *alt = row + COUNT_OF(KeyRows) / 2, *end = alt; row != end; ++row, ++alt)
        ptr += sprintf(ptr, "| %d | %s | %d | %s |\n", row->code, row->key, alt->code, alt->key);

    return (s32)(ptr - buf);
}

static void printMdCell(char** ptr, const char* str)
{
    // Write a markdown table cell: substitute the $LANG_...$ tokens first,
    // then escape | and collapse newlines to spaces (a cell can't span
    // lines). The escaping has to see the real text and not the token: a
    // value carrying a pipe, written after this loop, would split the row
    // and drop everything past it.
    char* replaced = strchr(str, '$') ? replaceHelpTokens(str) : NULL;
    const char* text = replaced ? replaced : str;

    for(const char* c = text; *c; ++c)
    {
        if(*c == '|')
            *(*ptr)++ = '\\', *(*ptr)++ = '|';
        else if(*c == '\n')
            *(*ptr)++ = ' ';
        else
            *(*ptr)++ = *c;
    }

    free(replaced);
}

static void onExport_help(Console* console, const char* param, const char* name, ExportParams params)
{
    (void)param;
    (void)params;
    const char* filename = getFilename(name, ".md");

    char *buf = malloc(TIC_BANK_SIZE), *ptr = buf;

    SCOPE(free(buf))
    {
        ptr += sprintf(ptr, "# " TIC_NAME_FULL "\n" TIC_VERSION "\n" TIC_COPYRIGHT "\n");

        ptr += sprintf(ptr, "\n## Table of Contents\n\n");
        ptr += sprintf(ptr, "- [Welcome](#welcome)\n- [Specification](#specification)\n- [Console commands](#console-commands)\n- [API functions](#api-functions)\n- [Button IDs](#button-ids)\n- [Key IDs](#key-ids)\n- [Startup options](#startup-options)\n- [Hotkeys](#hotkeys)\n- [Terms of Use](#terms-of-use)\n- [Privacy Policy](#privacy-policy)\n- [MIT License](#mit-license)\n");

        ptr += sprintf(ptr, "\n## Welcome\n%s\n", WelcomeText);

        ptr += sprintf(ptr, "\n## Specification\n\n| | |\n|---|---|\n");
        FOR(const struct SpecRow*, row, SpecText1)
        {
            ptr += sprintf(ptr, "| **%s** | ", row->section);
            printMdCell(&ptr, row->info); // "64KB of $LANG_NAMES$." is a cell like any other
            ptr += sprintf(ptr, " |\n");
        }

        ptr += createRamTableMd(ptr);
        ptr += createVRamTableMd(ptr);

        ptr += sprintf(ptr, "\n## Console commands\n\n| Command | Description | Usage |\n|---|---|---|\n");
        FOR(const Command*, cmd, Commands)
        {
            ptr += sprintf(ptr, "| `");
            printMdCell(&ptr, cmd->name);
            ptr += sprintf(ptr, "` | ");
            printMdCell(&ptr, cmd->help);
            ptr += sprintf(ptr, " | `");
            printMdCell(&ptr, cmd->usage ? cmd->usage : cmd->name);
            ptr += sprintf(ptr, "` |\n");
        }

        ptr += sprintf(ptr, "\n## API functions\n\n| Function | Description |\n|---|---|\n");
        FOR(const ApiItem*, api, Api)
        {
            ptr += sprintf(ptr, "| `");
            printMdCell(&ptr, api->def);
            ptr += sprintf(ptr, "` | ");
            printMdCell(&ptr, api->help);
            ptr += sprintf(ptr, " |\n");
        }

        ptr += sprintf(ptr, "\n## Button IDs\n");
        ptr += createButtonsTableMd(ptr);

        ptr += sprintf(ptr, "\n## Key IDs\n");
        ptr += createKeysTableMd(ptr);

        ptr += sprintf(ptr, "\n## Startup options\n\n| Option | Description |\n|---|---|\n");
        FOR(const struct StartupOption*, opt, StartupOptions)
        {
            ptr += sprintf(ptr, "| `--%s` | ", opt->name);
            printMdCell(&ptr, opt->help);
            ptr += sprintf(ptr, " |\n");
        }

        // The hotkeys were fixed-width text in code blocks in the old export;
        // the rewrite that turned the other lists into tables dropped them
        // instead of converting them, which took the whole keyboard reference
        // out of the document (and out of the released learn.md).
        ptr += sprintf(ptr, "\n## Hotkeys\n");
        // clang-format off
#define HOTKEYS_TABLE(title, rowtype, rows)                                            \
        ptr += sprintf(ptr, "\n### " title "\n\n| Keys | Description |\n|---|---|\n"); \
        FOR(const struct rowtype*, row, rows)                                          \
        {                                                                              \
            ptr += sprintf(ptr, "| `");                                                \
            printMdCell(&ptr, row->section);                                           \
            ptr += sprintf(ptr, "` | ");                                               \
            printMdCell(&ptr, row->info);                                              \
            ptr += sprintf(ptr, " |\n");                                               \
        }
        // clang-format on
        HOTKEYS_TABLE("General", HotkeysRowGeneral, HotkeysTextGeneral)
        HOTKEYS_TABLE("Navigation", HotkeysRowNavigation, HotkeysTextNavigation)
        HOTKEYS_TABLE("Code Editor", HotkeysRowCodeEditor, HotkeysTextCodeEditor)
        HOTKEYS_TABLE("Sprite Editor", HotkeysRowSpriteEditor, HotkeysTextSpriteEditor)
        HOTKEYS_TABLE("Map Editor", HotkeysRowMapEditor, HotkeysTextMapEditor)
        HOTKEYS_TABLE("SFX Editor", HotkeysRowSFXEditor, HotkeysTextSFXEditor)
        HOTKEYS_TABLE("Music Editor", HotkeysRowMusicEditor, HotkeysTextMusicEditor)
#undef HOTKEYS_TABLE

        ptr += sprintf(ptr, "\n%s\n\n%s", TermsText, LicenseText);

        // The cells that can carry a token go through printMdCell, which
        // replaces it before escaping the text; this pass covers the prose
        // sections and any cell still written raw. It is a no-op for the
        // document as it stands.
        char* helpReplaced = replaceHelpTokens(buf);

        SCOPE(free(helpReplaced))
        {
            onFileExported(console, filename, tic_fs_save(console->fs, filename, helpReplaced, (s32)(strlen(helpReplaced)), true));
        }
    }
}

TabCompleteData newTabCompleteData(Console* console, char* incompleteWord)
{
    TabCompleteData data = {console, .incompleteWord = incompleteWord};
    data.options = malloc(CONSOLE_BUFFER_SCREEN);
    data.commonPrefix = malloc(CONSOLE_BUFFER_SCREEN);
    data.options[0] = '\0';
    data.commonPrefix[0] = '\0';

    return data;
}

static void processConsoleTab(Console* console)
{
    char* input = console->input.text;
    char* param = strchr(input, ' ');

    if(param)
    {
        // Tab-complete command's parameters.
        param++;
        char* secondParam = strchr(param, ' ');
        if(secondParam)
            secondParam++;

        for(s32 i = 0; i < COUNT_OF(Commands); i++)
        {
            s32 commandLen = (s32)(param - input - 1);
            bool commandMatches = ((s32)strlen(Commands[i].name) == commandLen &&
                                   strncmp(Commands[i].name, input, commandLen) == 0) ||
                                  (Commands[i].alt &&
                                   (s32)strlen(Commands[i].alt) == commandLen &&
                                   strncmp(Commands[i].alt, input, commandLen) == 0);

            if(commandMatches)
            {
                if(secondParam)
                {
                    if(Commands[i].tabComplete2)
                    {
                        TabCompleteData data = newTabCompleteData(console, secondParam);
                        Commands[i].tabComplete2(&data);
                    }
                }
                else
                {
                    if(Commands[i].tabComplete1)
                    {
                        TabCompleteData data = newTabCompleteData(console, param);
                        Commands[i].tabComplete1(&data);
                    }
                }
            }
        }
    }
    else
    {
        // Tab-complete commands.
        TabCompleteData data = newTabCompleteData(console, input);
        for(s32 i = 0; i < COUNT_OF(Commands); i++)
        {
            addTabCompleteOption(&data, Commands[i].name);
            if(Commands[i].alt)
                addTabCompleteOption(&data, Commands[i].alt);
        }
        finishTabComplete(&data);
    }
    scrollConsole(console);
}

static bool printUsage(Console* console, const char* command)
{
    FOR(const Command*, cmd, Commands)
    {
        if(strcmp(command, cmd->name) == 0)
        {
            consolePrint(console, "\n---=== COMMAND ===---\n", tic_color_green);
            char* helpReplaced = replaceHelpTokens(cmd->help);
            printBack(console, helpReplaced);
            free(helpReplaced);

            if(cmd->usage)
            {
                printFront(console, "\n\nusage: ");
                char* usageReplaced = replaceHelpTokens(cmd->usage);
                printBack(console, usageReplaced);
                free(usageReplaced);
            }

            printLine(console);
            return true;
        }
    }

    return false;
}

static bool printApi(Console* console, const char* param)
{
    FOR(const ApiItem*, api, Api)
    {
        if(strcmp(param, api->name) == 0)
        {
            printLine(console);
            consolePrint(console, "---=== API ===---\n", tic_color_blue);
            consolePrint(console, api->def, tic_color_light_blue);
            printFront(console, "\n\n");
            printBack(console, api->help);
            printLine(console);
            return true;
        }
    }

    return false;
}

#define STRBUF_SIZE(name, ...) +STRLEN(#name) + STRLEN(Sep)

static void onHelp_api(Console* console)
{
    consolePrint(console, "\nAPI functions:\n", tic_color_blue);
    {
        const char Sep[] = " ";

        // calc buf size on compile time
        char buf[API_LIST(STRBUF_SIZE) + 1] = {[0] = 0};

        FOR(const ApiItem*, api, Api)
        strcat(buf, api->name), strcat(buf, Sep);

        printBack(console, buf);
    }
}

static void onHelp_commands(Console* console)
{
    consolePrint(console, "\nConsole commands:\n", tic_color_green);
    {
        const char Sep[] = " ";

        // calc buf size on compile time
        char buf[COMMANDS_LIST(STRBUF_SIZE) + 1] = {[0] = 0};

        FOR(const Command*, cmd, Commands)
        strcat(buf, cmd->name), strcat(buf, Sep);

        printBack(console, buf);
    }
}

#undef STRBUF_SIZE

static void printTable(Console* console, const char* text)
{
#ifndef BAREMETALPI
    printf("%s", text);
#endif

    for(const char *textPointer = text, *endText = textPointer + strlen(text); textPointer != endText;)
    {
        char symbol = *textPointer++;

        scrollConsole(console);

        if(symbol == '\n')
            nextLine(console);
        else
        {
            u8 color = 0;

            switch(symbol)
            {
                case '+':
                case '|':
                case '-':
                    color = tic_color_dark_grey;
                    break;
                default:
                    color = CONSOLE_FRONT_TEXT_COLOR;
            }

            setSymbol(console, symbol, color, cursorOffset(console));

            console->cursor.pos.x++;

            if(console->cursor.pos.x >= CONSOLE_BUFFER_WIDTH)
                nextLine(console);
        }
    }
}

static void onHelp_ram(Console* console)
{
    char buf[2048];
    createRamTable(buf);
    printTable(console, buf);
}

static const struct LangRuntimeVersion
{
    const char* script;
    const char* version;
} LangRuntimeVersions[] =
    {
        {"lua", TIC_RUNTIME_VERSION_LUA},
        {"ruby", TIC_RUNTIME_VERSION_RUBY},
        {"js", TIC_RUNTIME_VERSION_JS},
        {"moon", TIC_RUNTIME_VERSION_MOON},
        {"yue", TIC_RUNTIME_VERSION_YUE},
        {"fennel", TIC_RUNTIME_VERSION_FENNEL},
        {"scheme", TIC_RUNTIME_VERSION_SCHEME},
        {"squirrel", TIC_RUNTIME_VERSION_SQUIRREL},
        {"wren", TIC_RUNTIME_VERSION_WREN},
        {"wasm", TIC_RUNTIME_VERSION_WASM},
        {"janet", TIC_RUNTIME_VERSION_JANET},
        {"python", TIC_RUNTIME_VERSION_PYTHON},
        {"miniscript", TIC_RUNTIME_VERSION_MINISCRIPT},
        {"forth", TIC_RUNTIME_VERSION_FORTH},
        {"gravity", TIC_RUNTIME_VERSION_GRAVITY},
        {NULL, NULL},
};

static const char* getLangRuntimeVersion(const tic_script* script)
{
    if(script)
        FOR(const struct LangRuntimeVersion*, it, LangRuntimeVersions)
    if(it->script && strcmp(script->name, it->script) == 0)
        return it->version;

    return "unknown";
}

static void onHelp_vram(Console* console)
{
    char buf[1024];
    createVRamTable(buf);
    printTable(console, buf);
}

static void onHelp_keys(Console* console)
{
    char buf[4096];
    createKeysTable(buf);
    printTable(console, buf);
}

static void onHelp_buttons(Console* console)
{
    char buf[1024];
    createButtonsTable(buf);
    printTable(console, buf);
}

static void onHelp_version(Console* console)
{
    char buf[TICNAME_MAX];

    consolePrint(console, "\n" TIC_VERSION, CONSOLE_BACK_TEXT_COLOR);
    printBack(console, "\nlanguage runtimes:\n");

    FOREACH_LANG(script)
    {
        // %-10s: the widest name is "miniscript"; a narrower field pushes
        // its version out of the column the others line up in
        sprintf(buf, " %-10s %s\n", script->name, getLangRuntimeVersion(script));
        printBack(console, buf);
    }
}

static void onHelp_spec(Console* console)
{
    printLine(console);

    char buf[TICNAME_MAX];

    FOR(const struct SpecRow*, row, SpecText1)
    {
#define OFFSET 8
        char* rowReplaced = replaceHelpTokens(row->info);
        sprintf(buf, "%-" DEF2STR(OFFSET) "s%s\n", row->section, rowReplaced);
        consolePrintOffset(console, buf, tic_color_grey, OFFSET);
        free(rowReplaced);
#undef OFFSET
    }
}

static void onHelp_hotkeys(Console* console)
{
    printLine(console);

    char buf[TICNAME_MAX];

    printFront(console, "\nGeneral:\n");
    FOR(const struct HotkeysRowGeneral*, row, HotkeysTextGeneral)
    {
#define OFFSET 14
        char* rowReplaced = replaceHelpTokens(row->info);
        sprintf(buf, "%-" DEF2STR(OFFSET) "s%s\n", row->section, rowReplaced);
        consolePrintOffset(console, buf, tic_color_grey, OFFSET);
        free(rowReplaced);
#undef OFFSET
    }

    printFront(console, "\nNavigation:\n");
    FOR(const struct HotkeysRowNavigation*, row, HotkeysTextNavigation)
    {
#define OFFSET 17
        char* rowReplaced = replaceHelpTokens(row->info);
        sprintf(buf, "%-" DEF2STR(OFFSET) "s%s\n", row->section, rowReplaced);
        consolePrintOffset(console, buf, tic_color_grey, OFFSET);
        free(rowReplaced);
#undef OFFSET
    }

    printFront(console, "\nCode Editor:\n");
    FOR(const struct HotkeysRowCodeEditor*, row, HotkeysTextCodeEditor)
    {
#define OFFSET 19
        char* rowReplaced = replaceHelpTokens(row->info);
        sprintf(buf, "%-" DEF2STR(OFFSET) "s%s\n", row->section, rowReplaced);
        consolePrintOffset(console, buf, tic_color_grey, OFFSET);
        free(rowReplaced);
#undef OFFSET
    }

    printFront(console, "\nSprite Editor:\n");
    FOR(const struct HotkeysRowSpriteEditor*, row, HotkeysTextSpriteEditor)
    {
#define OFFSET 9
        char* rowReplaced = replaceHelpTokens(row->info);
        sprintf(buf, "%-" DEF2STR(OFFSET) "s%s\n", row->section, rowReplaced);
        consolePrintOffset(console, buf, tic_color_grey, OFFSET);
        free(rowReplaced);
#undef OFFSET
    }

    printFront(console, "\nMap Editor:\n");
    FOR(const struct HotkeysRowMapEditor*, row, HotkeysTextMapEditor)
    {
#define OFFSET 11
        char* rowReplaced = replaceHelpTokens(row->info);
        sprintf(buf, "%-" DEF2STR(OFFSET) "s%s\n", row->section, rowReplaced);
        consolePrintOffset(console, buf, tic_color_grey, OFFSET);
        free(rowReplaced);
#undef OFFSET
    }

    printFront(console, "\nSFX Editor:\n");
    FOR(const struct HotkeysRowSFXEditor*, row, HotkeysTextSFXEditor)
    {
#define OFFSET 14
        char* rowReplaced = replaceHelpTokens(row->info);
        sprintf(buf, "%-" DEF2STR(OFFSET) "s%s\n", row->section, rowReplaced);
        consolePrintOffset(console, buf, tic_color_grey, OFFSET);
        free(rowReplaced);
#undef OFFSET
    }

    printFront(console, "\nMusic Editor:\n");
    FOR(const struct HotkeysRowMusicEditor*, row, HotkeysTextMusicEditor)
    {
#define OFFSET 14
        char* rowReplaced = replaceHelpTokens(row->info);
        sprintf(buf, "%-" DEF2STR(OFFSET) "s%s\n", row->section, rowReplaced);
        consolePrintOffset(console, buf, tic_color_grey, OFFSET);
        free(rowReplaced);
#undef OFFSET
    }
}

static void onHelp_welcome(Console* console)
{
    printLine(console);
    printBack(console, WelcomeText);
}

static void onHelp_startup(Console* console)
{
    char buf[TICNAME_MAX];
    printFront(console, "\nStartup options:\n");
    FOR(const struct StartupOption*, opt, StartupOptions)
    {
#define OFFSET 12
#define PREFIX "--"
        sprintf(buf, PREFIX "%-" DEF2STR(OFFSET) "s%s\n", opt->name, opt->help);
        consolePrintOffset(console, buf, tic_color_grey, OFFSET + STRLEN(PREFIX));
#undef PREFIX
#undef OFFSET
    }
}

static void onHelp_terms(Console* console)
{
    printLine(console);
    printBack(console, TermsText);
}

static void onHelp_license(Console* console)
{
    printLine(console);
    printBack(console, LicenseText);
}

static void onHelpCommand(Console* console)
{
    if(console->desc->count)
    {
        const char* param = console->desc->params->key;
        bool foundTopic = false;

        if(printUsage(console, param))
        {
            foundTopic = true;
        }
        if(printApi(console, param))
        {
            foundTopic = true;
        }

        static const struct Handler
        {
            const char* cmd;
            void (*handler)(Console*);
        } Handlers[] =
            {
#define HELP_CMD_DEF(name, label) {#name, onHelp_##name},
                HELP_CMD_LIST(HELP_CMD_DEF)
#undef HELP_CMD_DEF
            };

        FOR(const struct Handler*, ptr, Handlers)
        if(strcmp(ptr->cmd, param) == 0)
        {
            foundTopic = true;
            ptr->handler(console);
            break;
        }

        if(!foundTopic)
        {
            printError(console, "\nunknown topic: ");
            printError(console, param);
        }
    }
    else
    {
        printFront(console, "\n\nusage: ");
        printBack(console, HelpUsage);

        printBack(console, "\n\ntype ");
        printFront(console, "help commands");
        printBack(console, " to show commands");

        printBack(console, "\n\npress ");
        printFront(console, "ESC");
        printBack(console, " to switch editor/console\n");
    }

    commandDone(console);
}

static CommandDesc parseCommand(const char* input)
{
    CommandDesc desc = {.src = strdup(input),
                        .command = strdup(input)};

    // the first token is the command's own name: strtok keeps the rest
    strtok(desc.command, " ");

    char* token;

    while((token = strtok(NULL, " ")))
    {
        desc.params = realloc(desc.params, ++desc.count * sizeof *desc.params);
        desc.params[desc.count - 1].key = token;
    }

    for(struct Param *it = desc.params, *end = it + desc.count; it < end; it++)
    {
        if(strcmp(it->key, "=") == 0) continue;

        it->key = strtok(it->key, "=");
        it->val = strtok(NULL, "=");
    }

    return desc;
}

static void processCommand(Console* console, const char* text)
{
    console->active = false;

    *console->desc = parseCommand(text);

    if(console->desc->command)
    {
        const char* command = console->desc->command;

        FOR(const Command*, cmd, Commands)
        if(casecmp(console->desc->command, cmd->name) == 0 ||
           (cmd->alt && casecmp(console->desc->command, cmd->alt) == 0))
        {
            cmd->handler(console);
            command = NULL;
            break;
        }

        if(command)
        {
            printLine(console);
            printError(console, "unknown command: ");
            printError(console, command);
            commandDone(console);
        }
    }
    else
        commandDone(console);
}

static void fillHistory(Console* console)
{
    if(console->history.size)
    {
        console->input.pos = 0;
        memset(console->input.text, '\0', strlen(console->input.text));

        const char* item = console->history.items[console->history.index];
        strcpy(console->input.text, item);
        memset(console->color + getInputOffset(console), CONSOLE_INPUT_COLOR, strlen(item));
        processConsoleEnd(console);
    }
}

static void onHistoryUp(Console* console)
{
    fillHistory(console);

    if(console->history.index > 0)
        console->history.index--;
}

static void onHistoryDown(Console* console)
{
    if(console->history.index < console->history.size - 1)
    {
        console->history.index++;
        fillHistory(console);
    }
    else
    {
        memset(console->input.text, '\0', strlen(console->input.text));
        processConsoleEnd(console);
    }
}

static void appendHistory(Console* console, const char* value)
{
    if(console->history.size)
        if(strcmp(console->history.items[console->history.index = console->history.size - 1], value) == 0)
            return;

    console->history.index = console->history.size++;
    console->history.items = realloc(console->history.items, sizeof(char*) * console->history.size);
    console->history.items[console->history.index] = strdup(value);
}

static void processConsoleCommand(Console* console)
{
    size_t commandSize = strlen(console->input.text);

    if(commandSize)
    {
        printf("%s", console->input.text);
        appendHistory(console, console->input.text);
        processCommand(console, console->input.text);
    }
    else
        commandDone(console);
}

static void error(Console* console, const char* info)
{
    consolePrint(console, info ? info : "unknown error", CONSOLE_ERROR_TEXT_COLOR);
    commandDone(console);
}

static void trace(Console* console, const char* text, u8 color)
{
    consolePrint(console, text, color);
    commandDone(console);
}

static void setScroll(Console* console, s32 val)
{
    if(console->scroll.pos != val)
    {
        console->scroll.pos = MIN(CLAMP(val, 0, console->cursor.pos.y), CONSOLE_BUFFER_ROWS - CONSOLE_BUFFER_HEIGHT);
    }
}

static void onHttpVersionGet(const net_get_data* data)
{
    Console* console = (Console*)data->calldata;

    switch(data->type)
    {
        case net_get_done:
        {
            if(json_parse((char*)data->done.data, data->done.size))
            {
                s32 major = json_int("major", 0);
                s32 minor = json_int("minor", 0);
                s32 patch = json_int("patch", 0);

                // clang-format off
                if((major > TIC_VERSION_MAJOR)
                    || (major == TIC_VERSION_MAJOR && minor > TIC_VERSION_MINOR)
                    || (major == TIC_VERSION_MAJOR && minor == TIC_VERSION_MINOR && patch > TIC_VERSION_REVISION))
                // clang-format on
                {
                    char msg[TICNAME_MAX];
                    sprintf(msg, " new version %i.%i.%i available", major, minor, patch);

                    enum
                    {
                        Offset = (2 * STUDIO_TEXT_BUFFER_WIDTH)
                    };

                    memset(console->text + Offset, ' ', STUDIO_TEXT_BUFFER_WIDTH);
                    strcpy(console->text + Offset, msg);
                    memset(console->color + Offset, tic_color_red, strlen(msg));
                }
            }
        }
        break;
        default:
            break;
    }
}

static char* getSelectionText(Console* console)
{
    const char* start = console->select.start;
    const char* end = console->select.end;

    if(start > end)
        SWAP(start, end, const char*);

    s32 size = (s32)(end - start);
    if(size)
    {
        size += size / CONSOLE_BUFFER_WIDTH + 1;
        char* clipboard = malloc(size);
        memset(clipboard, 0, size);
        char* dst = clipboard;

        s32 index = (start - console->text) % CONSOLE_BUFFER_WIDTH;

        for(const char* ptr = start; ptr < end; ptr++, index++)
        {
            if(index && (index % CONSOLE_BUFFER_WIDTH) == 0)
                *dst++ = '\n';

            if(*ptr)
                *dst++ = *ptr;
        }

        return clipboard;
    }

    return NULL;
}

static void copyToClipboard(Console* console)
{
    char* text = getSelectionText(console);

    if(text)
    {
        tic_sys_clipboard_set(text);
        free(text);
        clearSelection(console);
    }
}

static void copyFromClipboard(Console* console)
{
    if(tic_sys_clipboard_has())
    {
        const char* clipboard = tic_sys_clipboard_get();

        if(clipboard)
        {
            char* text = strdup(clipboard);

            char* dst = text;
            for(const char* src = clipboard; *src; src++)
                if(isprint((u8)(*src)))
                    *dst++ = *src;

            insertInputText(console, text);
            free(text);

            tic_sys_clipboard_free(clipboard);
        }
    }
}

static void processMouse(Console* console)
{
    tic_mem* tic = console->tic;
    // process scroll
    {
        tic80_input* input = &console->tic->ram->input;

        if(input->mouse.scrolly)
        {
            enum
            {
                Scroll = 3
            };
            s32 delta = input->mouse.scrolly > 0 ? -Scroll : Scroll;
            setScroll(console, console->scroll.pos + delta);
        }
    }

    tic_rect rect = {0, 0, TIC80_WIDTH, TIC80_HEIGHT};

    if(mouse_over(console->tic, &rect))
        ui_cursor(console->tic, tic_cursor_ibeam);

#if defined(__TIC_ANDROID__)

    if(mouse_down(&console->mouse[tic_mouse_left], &rect))
    {
        ui_cursor(console->tic, tic_cursor_hand);

        if(console->scroll.active)
        {
            setScroll(console, (console->scroll.start - tic_api_mouse(tic).y) / STUDIO_TEXT_HEIGHT);
        }
        else
        {
            console->scroll.active = true;
            console->scroll.start = tic_api_mouse(tic).y + console->scroll.pos * STUDIO_TEXT_HEIGHT;
        }
    }
    else
        console->scroll.active = false;

#else

    if(mouse_down(&console->mouse[tic_mouse_left], &rect))
    {
        tic_point m = tic_api_mouse(tic);

        console->select.end = console->text + m.x / STUDIO_TEXT_WIDTH + (m.y / STUDIO_TEXT_HEIGHT + console->scroll.pos) * CONSOLE_BUFFER_WIDTH;

        if(!console->select.active)
        {
            console->select.active = true;
            console->select.start = console->select.end;
        }
    }
    else
        console->select.active = false;

#endif

    if(mouse_click(&console->mouse[tic_mouse_middle], &rect))
    {
        char* text = getSelectionText(console);

        if(text)
        {
            insertInputText(console, text);
            tic_sys_clipboard_set(text);
            free(text);
        }
        else
            copyFromClipboard(console);
    }
}

static void processConsolePgUp(Console* console)
{
    setScroll(console, console->scroll.pos - STUDIO_TEXT_BUFFER_HEIGHT / 2);
}

static void processConsolePgDown(Console* console)
{
    setScroll(console, console->scroll.pos + STUDIO_TEXT_BUFFER_HEIGHT / 2);
}

static inline bool isalnum_(char c)
{
    return isalnum((u8)c) || c == '_';
}

static s32 leftWordPos(Console* console)
{
    const char* start = console->input.text;
    const char* pos = console->input.text + console->input.pos - 1;

    if(pos > start)
    {
        if(isalnum_(*pos))
            while(pos > start && isalnum_(*(pos - 1)))
                pos--;
        else
            while(pos > start && !isalnum_(*(pos - 1)))
                pos--;
        return (s32)(pos - console->input.text);
    }

    return (s32)(console->input.pos);
}

static s32 rightWordPos(Console* console)
{
    const char* end = console->input.text + strlen(console->input.text);
    const char* pos = console->input.text + console->input.pos;

    if(pos < end)
    {
        if(isalnum_(*pos))
            while(pos < end && isalnum_(*pos))
                pos++;
        else
            while(pos < end && !isalnum_(*pos))
                pos++;
        return (s32)(pos - console->input.text);
    }

    return (s32)(console->input.pos);
}

static void leftWord(Console* console)
{
    console->input.pos = leftWordPos(console);
}

static void rightWord(Console* console)
{
    console->input.pos = rightWordPos(console);
}

static void deleteWord(Console* console)
{
    s32 pos = rightWordPos(console);
    deleteText(console, (s32)(console->input.pos), pos);
}

static void backspaceWord(Console* console)
{
    s32 pos = leftWordPos(console);
    deleteText(console, pos, (s32)(console->input.pos));
    console->input.pos = pos;
}

static void processKeyboard(Console* console)
{
    tic_mem* tic = console->tic;

    if(!console->active)
        return;

    if(tic->ram->input.keyboard.data != 0)
    {
        switch(keyboard_clipboard(console->tic))
        {
            case TIC_CLIPBOARD_COPY: copyToClipboard(console); break;
            case TIC_CLIPBOARD_PASTE:
                copyFromClipboard(console);
                scrollConsole(console);
                break;
            default: break;
        }

        console->cursor.delay = CONSOLE_CURSOR_DELAY;

        bool ctrl = tic_api_key(tic, tic_key_ctrl);
        bool alt = tic_api_key(tic, tic_key_alt);

        if(ctrl || alt)
        {
            if(ctrl)
            {
#if defined(__TIC_LINUX__)
                tic_keycode clearKey = tic_key_l;
#else
                tic_keycode clearKey = tic_key_k;
#endif

                if(keyboard_pressed(console->tic, tic_key_a))
                    processConsoleHome(console);
                else if(keyboard_pressed(console->tic, tic_key_e))
                    processConsoleEnd(console);
                else if(keyboard_pressed(console->tic, clearKey))
                {
                    onClsCommand(console);
                    return;
                }
            }

            if(keyboard_pressed(console->tic, tic_key_left))
                leftWord(console);
            else if(keyboard_pressed(console->tic, tic_key_right))
                rightWord(console);
            else if(keyboard_pressed(console->tic, tic_key_delete))
                deleteWord(console);
            else if(keyboard_pressed(console->tic, tic_key_backspace))
                backspaceWord(console);
        }
        else
        {
            if(keyboard_pressed(console->tic, tic_key_up))
            {
                onHistoryUp(console);
                scrollConsole(console);
            }
            else if(keyboard_pressed(console->tic, tic_key_down))
                onHistoryDown(console);
            else if(keyboard_pressed(console->tic, tic_key_left))
            {
                if(console->input.pos > 0)
                    console->input.pos--;
            }
            else if(keyboard_pressed(console->tic, tic_key_right))
            {
                console->input.pos++;
                size_t len = strlen(console->input.text);
                if(console->input.pos > len)
                    console->input.pos = len;
            }
            else if(keyboard_enter(console->tic, KEYBOARD_HOLD, KEYBOARD_PERIOD))
                processConsoleCommand(console);
            else if(keyboard_pressed(console->tic, tic_key_backspace))
                processConsoleBackspace(console);
            else if(keyboard_pressed(console->tic, tic_key_delete))
                processConsoleDel(console);
            else if(keyboard_pressed(console->tic, tic_key_home))
                processConsoleHome(console);
            else if(keyboard_pressed(console->tic, tic_key_end))
                processConsoleEnd(console);
            else if(keyboard_pressed(console->tic, tic_key_tab))
                processConsoleTab(console);
            else if(keyboard_pressed(console->tic, tic_key_pageup))
                processConsolePgUp(console);
            else if(keyboard_pressed(console->tic, tic_key_pagedown))
                processConsolePgDown(console);
        }
    }

    char sym = keyboard_text(console->tic);

    if(sym)
    {
        insertInputText(console, (char[]){sym, '\0'});
        scrollConsole(console);

        console->cursor.delay = CONSOLE_CURSOR_DELAY;
    }
}

#if defined(BUILD_SURF)
static void processGamepad(Console* console)
{
    tic_mem* tic = console->tic;

    if(!console->active)
        return;

    if(tic->ram->input.keyboard.data == 0 && tic_api_btnp(tic, 6, -1, -1))
    {
        askStart(console, CONSOLE_ASK_SURF, NULL);
    }
}
#endif

// The player's run is going: the host refreshes what it keeps about the cart,
// and the console says what it says when a command is over.
static void onLaunched(Console* console, const ConsoleAnswer* answer)
{
    (void)answer;
    printLine(console);
    commandDone(console);
    console->active = true;
}

static void onPlayed(Console* console, const ConsoleAnswer* answer)
{
    (void)answer;
    askCart(console, NULL, false, onLaunched);
}

static void tick(Console* console)
{
    tic_mem* tic = console->tic;

    processMouse(console);
    processKeyboard(console);
#if defined(BUILD_SURF)
    processGamepad(console);
#endif

    if(console->tickCounter == 0)
    {
        if(!console->boot)
        {
            loadDemo(console, tic_get_script(tic));

            if(!console->args.cli)
            {
                printBack(console, "\n hello! type ");
                printFront(console, "help");
                printBack(console, " for help\n");

                if(console->config->checkNewVersion)
                    tic_net_get(console->net, "/json?fn=version", onHttpVersionGet, console);
            }

            commandDone(console);
        }
        else
            printBack(console, "\n loading cart...");
    }

    tic_api_cls(tic, TIC_COLOR_BG);
    drawConsoleText(console);

    if(console->boot)
    {
        if(console->tickCounter >= (u32)(console->args.skip ? 1 : TIC80_FRAMERATE))
        {
            // The cart came in as a file — a command line argument, a dropped
            // file, the web player's cart — so this is the player's run. The
            // flag is this console's own copy: clearing it here is what keeps
            // the branch a single shot, and the host clears its half when it
            // serves the run.
            console->boot = false;

            askStart(console, CONSOLE_ASK_PLAY, onPlayed);

            return;
        }
    }
    else
    {
        if(console->cursor.delay)
            console->cursor.delay--;

        if(!console->view->inFront) return;

        drawCursor(console);

        // One ask at a time: what the console asked the host for — the demo
        // cart's name, say — is served, and answered, before the next command
        // starts, or the first ask of a frame would be lost to the second.
        bool ready = console->ask.kind == CONSOLE_ASK_NONE;

        if(console->active && ready)
        {
            if(console->commands.current < console->commands.count)
            {
                const char* command = console->commands.items[console->commands.current];
                if(!console->args.cli)
                    printFront(console, command);

                processCommand(console, command);

                // A command that asked the host for its effect counts as run
                // when that has happened, not when it asked: `run` hands the
                // whole of it over, and runGame reads this count on the spot
                // for the rewind --keepcmd does. A command that asked for
                // nothing is done here.
                if(console->ask.kind == CONSOLE_ASK_NONE)
                    console->commands.current++;
                else
                    console->counting = true;
            }
            else if(console->config->cli)
                askStart(console, CONSOLE_ASK_EXIT, NULL);
        }
    }

    console->tickCounter++;
}

static int cmdcmp(const void* a, const void* b)
{
    return strcmp(((const Command*)a)->name, ((const Command*)b)->name);
}

static int apicmp(const void* a, const void* b)
{
    return strcmp(((const ApiItem*)a)->name, ((const ApiItem*)b)->name);
}

Console* console_create(const ConsoleDeps* deps)
{
    Console* console = calloc(1, sizeof(Console));

    console->text = malloc(CONSOLE_BUFFER_SIZE);
    console->color = malloc(CONSOLE_BUFFER_SIZE);
    console->desc = malloc(sizeof(CommandDesc));

    console->tic = deps->tic;
    console->view = deps->view;
    console->fs = deps->fs;
    console->net = deps->net;
    console->config = deps->config;
    console->mouse = deps->mouse;
    console->args.cmd = deps->args.cmd;
    console->args.cli = deps->args.cli;
    console->args.skip = deps->args.skip;
    console->args.keepcmd = deps->args.keepcmd;
    console->boot = deps->boot;

    console->cursor.pos = (tic_point){1, 3};
    console->input.text = console->text;
    console->active = !console->boot;
    console->progressLine = -1;

    // parse --cmd param
    {
        char* command = console->args.cmd;
        while(command)
        {
            console->commands.items = realloc(console->commands.items, sizeof(char*) * (console->commands.count + 1));
            console->commands.items[console->commands.count++] = command;

            static const char Sep[] = " & ";
            command = strstr(command, Sep);

            if(command)
            {
                *command = '\0';
                command += STRLEN(Sep);
            }
        }
    }

    qsort(Commands, COUNT_OF(Commands), sizeof Commands[0], cmdcmp);
    qsort(Api, COUNT_OF(Api), sizeof Api[0], apicmp);

    memset(console->text, 0, CONSOLE_BUFFER_SIZE);
    memset(console->color, TIC_COLOR_BG, CONSOLE_BUFFER_SIZE);
    memset(console->desc, 0, sizeof(CommandDesc));

    if(!console->args.cli)
    {
        start_banner(console->text, console->color);

        printLine(console);
        for(const char *ptr = console->text, *end = ptr + STUDIO_TEXT_BUFFER_SIZE;
            ptr < end; ptr += CONSOLE_BUFFER_WIDTH)
            if(*ptr)
                puts(ptr);
    }

    return console;
}

void console_free(Console* console)
{
    free(console->text);
    free(console->color);

    if(console->history.items)
    {
        for(char **ptr = console->history.items, **end = ptr + console->history.size; ptr < end; ptr++)
            free(*ptr);

        free(console->history.items);
    }

    for(s32 i = 0; i < console->commands.ownedCount; i++)
        free(console->commands.owned[i]);

    FREE(console->commands.owned);
    FREE(console->commands.items);
    free(console->desc);
    free(console);
}

// What the console wants served: the host takes it once, does it, and answers
// through console_answer(). Nothing is taken again until that answer comes.
bool console_take(Console* console, ConsoleAsk* ask)
{
    if(console->waiting || console->ask.kind == CONSOLE_ASK_NONE)
        return false;

    *ask = console->ask;
    console->ask = (ConsoleAsk){.kind = CONSOLE_ASK_NONE};
    console->waiting = true;

    return true;
}

void console_answer(Console* console, const ConsoleAnswer* answer)
{
    void (*onAnswer)(Console*, const ConsoleAnswer*) = console->onAnswer;

    console->waiting = false;
    console->onAnswer = NULL;

    // The command the host was asked for is run now; a command's later asks —
    // a dialog, then the load it confirmed — are that same command's, and do
    // not count again.
    if(console->counting)
    {
        console->counting = false;
        console->commands.current++;
    }

    if(onAnswer)
        onAnswer(console, answer);
}

void console_done(Console* console)
{
    commandDone(console);
}

bool console_active(const Console* console)
{
    return console->active;
}

bool console_replay(Console* console)
{
    if(console->args.keepcmd && console->commands.count && console->commands.current >= console->commands.count)
    {
        console->commands.current = 0;
        return true;
    }

    return false;
}

void console_exec(Console* console, const char* command)
{
    size_t length = strlen(command);

    if(length >= TICNAME_MAX)
        length = TICNAME_MAX - 1;

    char* copy = malloc(length + 1);

    if(!copy)
        return;

    memcpy(copy, command, length);
    copy[length] = '\0';

    char** items = realloc(console->commands.items,
                           sizeof(char*) * (console->commands.count + 1));
    char** owned = realloc(console->commands.owned,
                           sizeof(char*) * (console->commands.ownedCount + 1));

    if(!items || !owned)
    {
        free(copy);

        if(items)
            console->commands.items = items;

        if(owned)
            console->commands.owned = owned;

        return;
    }

    console->commands.items = items;
    console->commands.owned = owned;

    console->commands.items[console->commands.count++] = copy;
    console->commands.owned[console->commands.ownedCount++] = copy;
    console->active = true;
}

void console_trace(Console* console, const char* text, u8 color)
{
    trace(console, text, color);
}

void console_error(Console* console, const char* info)
{
    error(console, info);
}

void console_tick(Console* console)
{
    tick(console);
}
