// MIT License

// Copyright (c) 2017 Vadim Grigoruk @nesbox // grigoruk@gmail.com

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>

#include "tic.h"
#include "api.h"
#include "script.h"
#include "defines.h"
#include "tools.h"
#include "system.h"
#include "rom.h"
#include "anim.h"
#include "keyboard.h"
#include "ext/png.h"
#include "core/core.h"

#if defined(BUILD_RENDER_CACHE)
// Redirect studio drawing calls through the core API pointers to benefit from the draw cache
#define tic_api_cls(tic, ...)   (((tic_core*)(tic))->api.cls(tic, __VA_ARGS__))
#define tic_api_clip(tic, ...)  (((tic_core*)(tic))->api.clip(tic, __VA_ARGS__))
#define tic_api_print(tic, ...) (((tic_core*)(tic))->api.print(tic, __VA_ARGS__))
#define tic_api_font(tic, ...)  (((tic_core*)(tic))->api.font(tic, __VA_ARGS__))
#define tic_api_pix(tic, ...)   (((tic_core*)(tic))->api.pix(tic, __VA_ARGS__))
#define tic_api_rect(tic, ...)  (((tic_core*)(tic))->api.rect(tic, __VA_ARGS__))
#define tic_api_rectb(tic, ...) (((tic_core*)(tic))->api.rectb(tic, __VA_ARGS__))
#define tic_api_line(tic, ...)  (((tic_core*)(tic))->api.line(tic, __VA_ARGS__))
#define tic_api_circ(tic, ...)  (((tic_core*)(tic))->api.circ(tic, __VA_ARGS__))
#define tic_api_circb(tic, ...) (((tic_core*)(tic))->api.circb(tic, __VA_ARGS__))
#define tic_api_elli(tic, ...)  (((tic_core*)(tic))->api.elli(tic, __VA_ARGS__))
#define tic_api_ellib(tic, ...) (((tic_core*)(tic))->api.ellib(tic, __VA_ARGS__))
#define tic_api_paint(tic, ...) (((tic_core*)(tic))->api.paint(tic, __VA_ARGS__))
#define tic_api_tri(tic, ...)   (((tic_core*)(tic))->api.tri(tic, __VA_ARGS__))
#define tic_api_trib(tic, ...)  (((tic_core*)(tic))->api.trib(tic, __VA_ARGS__))
#define tic_api_ttri(tic, ...)  (((tic_core*)(tic))->api.ttri(tic, __VA_ARGS__))
#define tic_api_spr(tic, ...)   (((tic_core*)(tic))->api.spr(tic, __VA_ARGS__))
#define tic_api_map(tic, ...)   (((tic_core*)(tic))->api.map(tic, __VA_ARGS__))
#endif

#ifdef BAREMETALPI
#define TIC_LOCAL "../.tic80/"
#elif defined(__SWITCH__)
#define TIC_LOCAL "./data/"
#else
#define TIC_LOCAL ".local/"
#endif
#define TIC_LOCAL_VERSION TIC_LOCAL TIC_VERSION_HASH "/"
#define TIC_CACHE         TIC_LOCAL "cache/"

#define STUDIO_BAR_HEIGHT         7
#define STUDIO_TEXT_WIDTH         (TIC_FONT_WIDTH)
#define STUDIO_TEXT_HEIGHT        (TIC_FONT_HEIGHT + 1)
#define STUDIO_TEXT_BUFFER_WIDTH  (TIC80_WIDTH / STUDIO_TEXT_WIDTH)
#define STUDIO_TEXT_BUFFER_HEIGHT (TIC80_HEIGHT / STUDIO_TEXT_HEIGHT)
#define STUDIO_TEXT_BUFFER_SIZE   (STUDIO_TEXT_BUFFER_WIDTH * STUDIO_TEXT_BUFFER_HEIGHT)
#define STUDIO_ANIM_TIME          8

#define TIC_COLOR_BG tic_color_black

#define CONFIG_TIC      "config.tic"
#define CONFIG_TIC_PATH TIC_LOCAL_VERSION CONFIG_TIC

#define PNG_EXT ".png"

#if defined(CRT_SHADER_SUPPORT)
// clang-format off
#   define CRT_CMD_PARAM(macro)                                 \
    macro(crt, bool, BOOLEAN, "", "enable CRT monitor effect")
// clang-format on
#else
#define CRT_CMD_PARAM(macro)
#endif

// clang-format off
#define CMD_PARAMS_LIST(macro)                                                              \
    macro(skip,         int,    BOOLEAN,    "",         "skip startup animation")           \
    macro(volume,       s32,    INTEGER,    "=<int>",   "global volume value [0-15]")       \
    macro(cli,          int,    BOOLEAN,    "",         "console only output")              \
    macro(fullscreen,   int,    BOOLEAN,    "",         "enable fullscreen mode")           \
    macro(vsync,        int,    BOOLEAN,    "",         "enable VSYNC")                     \
    macro(soft,         int,    BOOLEAN,    "",         "use software rendering")           \
    macro(fs,           char*,  STRING,     "=<str>",   "path to the file system folder")   \
    macro(scale,        s32,    INTEGER,    "=<int>",   "main window scale")                \
    macro(cmd,          char*,  STRING,     "=<str>",   "run commands in the console")      \
    macro(keepcmd,      int,    BOOLEAN,    "",         "re-execute commands on every run") \
    macro(version,      int,    BOOLEAN,    "",         "print program version")            \
    CRT_CMD_PARAM(macro)
// clang-format on

// clang-format off
#define SHOW_TOOLTIP(STUDIO, FORMAT, ...)        \
do{                                              \
    static const char Format[] = FORMAT;         \
    static char buf[STUDIO_TEXT_BUFFER_WIDTH];   \
    snprintf(buf, sizeof buf, Format, __VA_ARGS__); \
    showTooltip(STUDIO, buf);                    \
}while(0)
// clang-format on

typedef struct
{
    char* cart;
#define CMD_PARAMS_DEF(name, ctype, type, post, help) ctype name;
    CMD_PARAMS_LIST(CMD_PARAMS_DEF)
#undef CMD_PARAMS_DEF

#if defined(BUILD_EDITORS)
    const char* codeexport;
    const char* codeimport;
    s32 delay;
    s32 lowerlimit;
    s32 upperlimit;
    s32 battletime;

    int fft;
    int fftlist;
    int fftcaptureplaybackdevices;
    const char* fftdevice;
#endif
} StartArgs;

typedef enum
{
    TIC_START_MODE,
    TIC_CONSOLE_MODE,
    TIC_RUN_MODE,
    TIC_CODE_MODE,
    TIC_SPRITE_MODE,
    TIC_MAP_MODE,
    TIC_WORLD_MODE,
    TIC_SFX_MODE,
    TIC_MUSIC_MODE,
    TIC_MENU_MODE,
#if defined(BUILD_SURF)
    TIC_SURF_MODE,
#endif

    TIC_MODES_COUNT
} EditorMode;

// Where a build goes when there is nothing else to show, and where leaving a
// run or the browser goes: the console, the browser, or the menu.
#if defined(BUILD_EDITORS)
#define TIC_HOME_MODE TIC_CONSOLE_MODE
#elif defined(BUILD_SURF)
#define TIC_HOME_MODE TIC_SURF_MODE
#else
#define TIC_HOME_MODE TIC_MENU_MODE
#endif

// Who asked for the run decides what ESC does in it (#2937): the studio's own
// runs — Ctrl+R, the console's `run` — step back out to the editor, a cart
// opened to play — a file argument, a dropped file, SURF, the web player —
// gets the pause menu. What the cart declares (a `menu:` tag) is content, not
// a role: it adds the game's own items to that menu, nothing more.
typedef enum
{
    RUN_FROM_STUDIO,
    RUN_FROM_PLAYER,
} RunOrigin;

typedef enum
{
    VI_NORMAL,
    VI_INSERT,
    VI_SELECT,
    VI_SEEK,
    VI_SEEK_BACK,
} ViMode;

enum
{
    tic_icon_cut = 80,
    tic_icon_copy = 81,
    tic_icon_paste = 82,
    tic_icon_undo = 83,
    tic_icon_redo = 84,
    tic_icon_bank = 85,
    tic_icon_tab = 87,
    tic_icon_code = 88,
    tic_icon_sprite = 89,
    tic_icon_map = 90,
    tic_icon_sfx = 91,
    tic_icon_music = 92,
    tic_icon_rec = 93,
    tic_icon_rec2 = 94,
    tic_icon_bookmark = 95,
    tic_icon_shadow = 96,
    tic_icon_hand = 99,
    tic_icon_find = 100,
    tic_icon_goto = 101,
    tic_icon_outline = 102,
    tic_icon_world = 103,
    tic_icon_grid = 104,
    tic_icon_down = 105,
    tic_icon_up = 106,
    tic_icon_fill = 107,
    tic_icon_select = 108,
    tic_icon_pen = 109,
    tic_icon_tiles = 110,
    tic_icon_sprites = 111,
    tic_icon_left = 112,
    tic_icon_right = 113,
    tic_icon_piano = 114,
    tic_icon_tracker = 115,
    tic_icon_follow = 116,
    tic_icon_sustain = 117,
    tic_icon_playnow = 118,
    tic_icon_playframe = 119,
    tic_icon_stop = 120,
    tic_icon_rgb = 121,
    tic_icon_tinyleft = 122,
    tic_icon_pos = 123,
    tic_icon_tinyright = 124,
    tic_icon_bigup = 125,
    tic_icon_bigdown = 126,
    tic_icon_bigleft = 127,
    tic_icon_bigright = 128,
    tic_icon_fliphorz = 129,
    tic_icon_flipvert = 130,
    tic_icon_rotate = 131,
    tic_icon_erase = 132,
    tic_icon_bigpen = 133,
    tic_icon_bigpicker = 134,
    tic_icon_bigselect = 135,
    tic_icon_bigfill = 136,
    tic_icon_loop = 137,
    tic_icon_random = 138,
    tic_icon_line_numbers = 139,
    tic_icon_circle = 140,
    tic_icon_more = 141,
    tic_icon_tic80 = 142,
    tic_icon_show_tiles = 143,
    tic_icon_console = 144,
    tic_icon_surf = 145,
    tic_icon_game_menu = 146,
    tic_icon_tinypicker = 147,
    tic_icon_tinyfliphorz = 148,
    tic_icon_tinyflipvert = 149,
    tic_icon_tinyerase = 150,
    tic_icon_tinyrotate = 151,
};

void setCursor(Studio* studio, tic_cursor id);

bool checkMousePos(Studio* studio, const tic_rect* rect);
bool checkMouseClick(Studio* studio, const tic_rect* rect, tic_mouse_btn button);
bool checkMouseDblClick(Studio* studio, const tic_rect* rect, tic_mouse_btn button);
bool checkMouseDown(Studio* studio, const tic_rect* rect, tic_mouse_btn button);

void drawBitIcon(Studio* studio, s32 id, s32 x, s32 y, u8 color);

tic_cartridge* loadPngCart(png_buffer buffer);
void studioRomLoaded(Studio* studio);
void studioRomSaved(Studio* studio);
void studioConfigChanged(Studio* studio);

void setStudioMode(Studio* studio, EditorMode mode);
EditorMode getStudioMode(Studio* studio);

// Where CODE and MAP content starts: 0 with autohide, 7 otherwise.
s32 getStudioEditorTop(Studio* studio);
void exitStudio(Studio* studio);

void setStudioViMode(Studio* studio, ViMode mode);
ViMode getStudioViMode(Studio* studio);
bool checkStudioViMode(Studio* studio, ViMode mode);

void toClipboard(const void* data, s32 size, bool flip);
bool fromClipboard(void* data, s32 size, bool flip, bool remove_white_spaces, bool sameSize);

// The five operations the Edit menu performs. Each editor supplies its own; a
// mode with none leaves it NULL.
typedef struct
{
    void (*cut)(void*);
    void (*copy)(void*);
    void (*paste)(void*);
    void (*undo)(void*);
    void (*redo)(void*);

} ClipboardOps;

ClipboardEvent getClipboardEvent(Studio* studio);

void showTooltip(Studio* studio, const char* text);

typedef void (*ConfirmCallback)(Studio* studio, bool yes, void* data);
void confirmDialog(Studio* studio, const char** text, s32 rows, ConfirmCallback callback, void* data);
void confirmLoadCart(Studio* studio, ConfirmCallback callback, void* data);

bool studioCartChanged(Studio* studio);
void playSystemSfx(Studio* studio, s32 id);
bool studio_is_cart_loaded(Studio* studio);

struct tic_fs* studio_fs(Studio* studio);

void gotoMenu(Studio* studio);
void gotoCode(Studio* studio);
#if defined(BUILD_SURF)
void gotoSurf(Studio* studio);
void exitSurf(Studio* studio);
#endif

void runGame(Studio* studio, RunOrigin origin);
void exitGame(Studio* studio);
void resumeGame(Studio* studio);
bool studio_run_paused(Studio* studio);
void saveProject(Studio* studio);

bool studio_menu_over_player_run(Studio* studio);
void leaveRun(Studio* studio);

tic_tiles* getBankTiles(Studio* studio);
tic_palette* getBankPalette(Studio* studio, bool bank);
tic_flags* getBankFlags(Studio* studio);
tic_map* getBankMap(Studio* studio);

char getKeyboardText(Studio* studio);
bool keyWasPressed(Studio* studio, tic_key key);
bool keyWasPressedOnce(Studio* studio, tic_key key);
bool enterWasPressed(Studio* studio);
bool enterWasPressedOnce(Studio* studio);
bool ticEnterWasPressed(tic_mem* tic, s32 hold, s32 period);

typedef struct Config Config;
const StudioConfig* getConfig(Studio* studio);
Config* studio_config_get(Studio* studio);

const char* studioExportMusic(Studio* studio, s32 track, s32 bank, const char* filename);
const char* studioExportSfx(Studio* studio, s32 sfx, const char* filename);

tic_mem* getMemory(Studio* studio);

void sfx_stop(tic_mem* tic, s32 channel);
s32 calcWaveAnimation(tic_mem* tic, u32 index, s32 channel);
void map2ram(tic_ram* ram, const tic_map* src);
void tiles2ram(tic_ram* ram, const tic_tiles* src);
void fadePalette(tic_palette* pal, s32 value);

#if defined(BUILD_EDITORS)

// The code editor's view toggles, shared by the bar's menu and the editor's
// own hotkeys so both persist.
typedef enum
{
    CodeViewFont,
    CodeViewShadow,
    CodeViewLineNumbers,
    CodeViewSidebar,
    CodeViewStatusbar,
} CodeViewOption;

void studioCodeViewToggle(Studio*, CodeViewOption);

typedef struct
{
    char* exp;
    char* imp;

    struct
    {
        tic_code code;
        char postag[sizeof "-- pos: -2147483648,-2147483648\n"];
    } last;

    s32 delay;
    s32 ticks;

    struct
    {
        s32 lower;
        s32 upper;
        s32 current;
    } limit;

    struct
    {
        s32 started;
        s32 time;
        s32 left;

        bool hidetime;
    } battle;

} Bytebattle;

Bytebattle* getBytebattle(Studio* studio);

#endif
