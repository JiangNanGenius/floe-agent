################################
# TIC-80 studio
################################

set(TIC80LIB_DIR ${CMAKE_SOURCE_DIR}/src)
set(TIC80STUDIO_SRC
    ${TIC80LIB_DIR}/studio/screens/run.c
    ${TIC80LIB_DIR}/studio/screens/menu.c
    ${TIC80LIB_DIR}/studio/screens/mainmenu.c
    ${TIC80LIB_DIR}/studio/screens/start.c
    ${TIC80LIB_DIR}/studio/studio.c
    # The state of a launch that came with a cart: every build boots, so this
    # is not editors-only.
    ${TIC80LIB_DIR}/studio/boot.c
    # The cart an app image carries, which `export game` writes and the launch
    # reads: bytes and the core's zipper, with no studio in it.
    ${TIC80LIB_DIR}/studio/embed.c
    # The sound the studio plays, which the menus, the splash and the panels all
    # reach: every build has a reason to hear it.
    ${TIC80LIB_DIR}/studio/sound.c
    # The icon and the cursor every screen draws with: the menu needs both in
    # builds that have no bar and never will.
    ${TIC80LIB_DIR}/studio/ui.c
    # What the machine's keyboard says, which the editors and the console ask
    # about more than any other one thing.
    ${TIC80LIB_DIR}/studio/keyboard.c
    # The pointer and the buttons, beside the state mouse.h already declared.
    ${TIC80LIB_DIR}/studio/mouse.c
    ${TIC80LIB_DIR}/studio/rom.c
    ${TIC80LIB_DIR}/studio/config.c
    ${TIC80LIB_DIR}/studio/fs.c
    ${TIC80LIB_DIR}/ext/md5.c
    ${TIC80LIB_DIR}/ext/json.c
    ${TIC80LIB_DIR}/ext/png.c
)

# net.c serves the console as much as the browser: the version check and the
# site filesystem both go through it, so it stays whenever either is built.
if(BUILD_EDITORS OR BUILD_SURF)
    set(TIC80STUDIO_SRC ${TIC80STUDIO_SRC}
        ${TIC80LIB_DIR}/studio/net.c
    )
endif()

if(BUILD_SURF)
    set(TIC80STUDIO_SRC ${TIC80STUDIO_SRC}
        ${TIC80LIB_DIR}/studio/screens/surf.c
    )
endif()

if(BUILD_EDITORS)
    set(TIC80STUDIO_SRC ${TIC80STUDIO_SRC}
        # The bar is the editors' shell: a build without them never draws it.
        ${TIC80LIB_DIR}/studio/menubar.c
        ${TIC80LIB_DIR}/studio/studiomenu.c
        ${TIC80LIB_DIR}/studio/screens/console.c
        ${TIC80LIB_DIR}/studio/editors/code.c
        ${TIC80LIB_DIR}/studio/editors/sprite.c
        ${TIC80LIB_DIR}/studio/editors/map.c
        ${TIC80LIB_DIR}/studio/editors/world.c
        ${TIC80LIB_DIR}/studio/editors/sfx.c
        ${TIC80LIB_DIR}/studio/editors/music.c
        ${TIC80LIB_DIR}/ext/history.c
        ${TIC80LIB_DIR}/ext/gif.c
    )
endif()

if(BUILD_PRO)
    set(TIC80STUDIO_SRC ${TIC80STUDIO_SRC}
        ${TIC80LIB_DIR}/studio/project.c)
endif()

set(TIC80_OUTPUT tic80)

add_library(tic80studio STATIC
    ${TIC80STUDIO_SRC}
    ${CMAKE_SOURCE_DIR}/build/assets/cart.png.dat)

target_include_directories(tic80studio
    PRIVATE ${THIRDPARTY_DIR}/jsmn
    PUBLIC ${CMAKE_CURRENT_BINARY_DIR}
    PUBLIC ${TIC80LIB_DIR}
    PUBLIC ${TIC80LIB_DIR}/studio
)

target_link_libraries(tic80studio PUBLIC tic80core PRIVATE zip wave_writer argparse giflib png)

if(USE_NAETT)
    target_compile_definitions(tic80studio PRIVATE USE_NAETT)
    target_link_libraries(tic80studio PRIVATE naett)
endif()

if(BUILD_PRO)
    target_compile_definitions(tic80studio PRIVATE TIC80_PRO)
endif()

if(BUILD_SDLGPU)
    target_compile_definitions(tic80studio PUBLIC CRT_SHADER_SUPPORT)
endif()

if(BUILD_EDITORS)
    target_compile_definitions(tic80studio PUBLIC BUILD_EDITORS)
endif()

if(BUILD_SURF)
    target_compile_definitions(tic80studio PUBLIC BUILD_SURF)
endif()
