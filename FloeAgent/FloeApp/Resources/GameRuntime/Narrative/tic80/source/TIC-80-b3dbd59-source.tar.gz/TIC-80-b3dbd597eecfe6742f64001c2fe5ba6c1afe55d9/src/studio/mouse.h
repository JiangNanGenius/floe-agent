// MIT License

// Copyright (c) 2017 Vadim Grigoruk @nesbox // grigoruk@gmail.com

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once

#include "tic.h"
#include "api.h"

// One button's frame: `start` and `end` in screen coordinates, so a click
// needs both inside one rectangle. Shared with the editors' own panels.
typedef struct
{
    bool down;
    bool click;

    struct
    {
        s32 start;
        s32 ticks;
        bool click;
    } dbl;

    tic_point start;
    tic_point end;

} MouseState;

// What a screen asks of the pointer: where it is, and whether a button was
// pressed, clicked or double-clicked inside a rect. A click is consumed.

bool mouse_over(tic_mem* tic, const tic_rect* rect);
bool mouse_click(MouseState* state, const tic_rect* rect);
bool mouse_dblclick(MouseState* state, const tic_rect* rect);
bool mouse_down(const MouseState* state, const tic_rect* rect);
