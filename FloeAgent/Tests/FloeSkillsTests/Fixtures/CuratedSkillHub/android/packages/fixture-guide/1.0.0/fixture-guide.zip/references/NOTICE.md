Fixture-only sample notice. No upstream work is represented.
