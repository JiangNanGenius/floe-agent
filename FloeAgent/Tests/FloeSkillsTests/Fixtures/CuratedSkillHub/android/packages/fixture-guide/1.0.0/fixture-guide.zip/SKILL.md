---
name: fixture-guide
description: Fixture-only read-only guide sample. Never install as production content.
---

This is a FIXTURE sample guide. It declares no
scripts and claims no execution capability.
