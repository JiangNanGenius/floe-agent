Fixture-only sample. The script is never executed by the builder.
