---
name: fixture-script
description: Fixture-only script sample executed via exec.shell in the task Linux guest.
---

Run scripts/echo.py through the existing task Linux
environment. Fixture-only: execution is NOT verified.
