import sys
print("fixture-only sample; runs only through exec.shell")
sys.exit(0)
