import json
print(json.dumps({"fixture": True, "verifiedExecution": False}))
