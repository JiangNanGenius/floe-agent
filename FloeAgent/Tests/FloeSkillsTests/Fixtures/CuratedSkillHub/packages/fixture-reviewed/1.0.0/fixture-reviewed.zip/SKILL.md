---
name: fixture-reviewed
description: Fixture-only sample with a simulated signed review record.
---

Exercises the signed review-binding chain only. The attached
review is a fixture artifact, not a real review decision.
