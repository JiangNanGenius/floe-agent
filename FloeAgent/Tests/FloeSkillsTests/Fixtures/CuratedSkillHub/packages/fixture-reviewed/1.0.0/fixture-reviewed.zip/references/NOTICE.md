Fixture-only sample review-binding material.
