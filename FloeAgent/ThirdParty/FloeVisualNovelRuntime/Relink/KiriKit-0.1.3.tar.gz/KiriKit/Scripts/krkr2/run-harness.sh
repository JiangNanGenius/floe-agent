#!/bin/bash
# This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
# If a copy of the MPL was not distributed with this file, You can obtain one at
# https://mozilla.org/MPL/2.0/.
#
# Runs a KiriKiri game folder (one holding base/, optionally patch/) on the ShioriKrkr Mac
# harness. The CxDec scheme, if the game has one, is exported from GARbro's database
# (Vendor/garbro, MIT) into build/, never into the repo; the game's own folder is only linked,
# never written (saves go to the work folder).
#
#   Scripts/krkr2/run-harness.sh <game folder> <work folder> [--garbro "KARAKARA 2"]
#       [--exe KARAKARA2.exe] [harness options: --frames N --click F:X,Y --capture F:file.bmp ...]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
GARBRO_COMMIT=698ccc57d766f4afab5be4ec9a1936dd830dac12   # crskycode/GARbro master, 2026-10-18
GAME=$1
WORK=$2
shift 2
TITLE=""
ARGS=()
while [ $# -gt 0 ]; do
    case $1 in
    --garbro) TITLE=$2; shift 2 ;;
    *) ARGS+=("$1"); shift ;;
    esac
done
mkdir -p "$WORK"
SCHEME=()
if [ -n "$TITLE" ]; then
    DB="$ROOT/Vendor/garbro/ArcFormats/Resources/Formats.dat"
    if [ ! -f "$DB" ] || [ "$(git -C "$ROOT/Vendor/garbro" rev-parse HEAD 2>/dev/null)" != "$GARBRO_COMMIT" ]; then
        if [ ! -d "$ROOT/Vendor/garbro/.git" ]; then
            git init -q "$ROOT/Vendor/garbro"
            git -C "$ROOT/Vendor/garbro" remote add origin https://github.com/crskycode/GARbro
        fi
        git -C "$ROOT/Vendor/garbro" sparse-checkout set ArcFormats/KiriKiri ArcFormats/Resources
        git -C "$ROOT/Vendor/garbro" fetch -q --depth 1 --filter=blob:none origin "$GARBRO_COMMIT"
        git -C "$ROOT/Vendor/garbro" checkout -q FETCH_HEAD
    fi
    python3 -I "$ROOT/Scripts/krkr2/garbro-cx.py" "$DB" "$TITLE" "$WORK/scheme.shcx" >/dev/null
    SCHEME=(--scheme "$WORK/scheme.shcx")
fi
PATCH=()
[ -d "$GAME/patch" ] && PATCH=(--patch "$GAME/patch")
# Shiori's E-mote player (Swift, on CatSystemKit) for the characters.
if [ -z "${SHIORIKRKR_EMOTE_LIB:-}" ]; then
    (cd "$ROOT" && swift build -c release --product KiriKitEmoteHarness >&2) || exit 1
    export SHIORIKRKR_EMOTE_LIB="$ROOT/.build/release/libKiriKitEmoteHarness.dylib"
fi
exec ${SHIORIKRKR_WRAP:-} "$ROOT/build/shiorikrkr/macos/shiorikrkr-harness" --base "$GAME/base" ${PATCH[@]+"${PATCH[@]}"} --work "$WORK" \
    ${SCHEME[@]+"${SCHEME[@]}"} --font "${SHIORIKRKR_FONT:-$ROOT/../shiori/App/Resources/SiglusFonts/BIZUDGothic-Regular.ttf}" ${ARGS[@]+"${ARGS[@]}"}
