using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using MillSimSharp.Geometry;

namespace MillSimSharp.IO
{
    /// <summary>
    /// Exports voxel grids and meshes to binary STL format.
    /// </summary>
    public static class StlExporter
    {
        /// <summary>
        /// Exports a voxel grid to an STL file (binary format).
        /// </summary>
        /// <param name="grid">The voxel grid to export.</param>
        /// <param name="filePath">Output file path.</param>
        public static void Export(VoxelGrid grid, string filePath)
        {
            byte[] stlData = ExportToBytes(grid);
            File.WriteAllBytes(filePath, stlData);
        }

        /// <summary>
        /// Exports a voxel grid to STL binary data.
        /// </summary>
        /// <param name="grid">The voxel grid to export.</param>
        /// <returns>Binary STL data.</returns>
        public static byte[] ExportToBytes(VoxelGrid grid)
        {
            List<Triangle> triangles = GenerateTriangles(grid);

            using (MemoryStream stream = new MemoryStream())
            using (BinaryWriter writer = new BinaryWriter(stream))
            {
                // STL header (80 bytes)
                byte[] header = new byte[80];
                string headerText = "MillSimSharp Voxel Export";
                byte[] headerBytes = System.Text.Encoding.ASCII.GetBytes(headerText);
                Array.Copy(headerBytes, header, Math.Min(headerBytes.Length, 80));
                writer.Write(header);

                // Number of triangles
                writer.Write((uint)triangles.Count);

                // Write each triangle
                foreach (Triangle tri in triangles)
                {
                    // Normal vector
                    WriteVector3(writer, tri.Normal);

                    // Vertices
                    WriteVector3(writer, tri.V1);
                    WriteVector3(writer, tri.V2);
                    WriteVector3(writer, tri.V3);

                    // Attribute byte count (unused, set to 0)
                    writer.Write((ushort)0);
                }

                return stream.ToArray();
            }
        }

        /// <summary>
        /// Exports a Mesh object to an STL file (binary format).
        /// </summary>
        /// <param name="mesh">The mesh to export.</param>
        /// <param name="filePath">Output file path.</param>
        public static void Export(Mesh mesh, string filePath)
        {
            byte[] stlData = ExportToBytes(mesh);
            File.WriteAllBytes(filePath, stlData);
        }

        /// <summary>
        /// Exports a mesh to an STL file in ASCII format.
        /// </summary>
        /// <param name="mesh">The mesh to export.</param>
        /// <param name="filePath">Output file path.</param>
        public static void ExportAscii(Mesh mesh, string filePath)
        {
            if (mesh == null) throw new ArgumentNullException(nameof(mesh));
            if (filePath == null) throw new ArgumentNullException(nameof(filePath));

            List<Triangle> triangles = GenerateTriangles(mesh);

            using var writer = new StreamWriter(filePath, false, new System.Text.UTF8Encoding(false));
            var culture = System.Globalization.CultureInfo.InvariantCulture;

            writer.WriteLine("solid MillSimSharp");
            foreach (Triangle tri in triangles)
            {
                writer.WriteLine(FormattableString.Invariant($"  facet normal {tri.Normal.X} {tri.Normal.Y} {tri.Normal.Z}"));
                writer.WriteLine("    outer loop");
                writer.WriteLine(FormattableString.Invariant($"      vertex {tri.V1.X} {tri.V1.Y} {tri.V1.Z}"));
                writer.WriteLine(FormattableString.Invariant($"      vertex {tri.V2.X} {tri.V2.Y} {tri.V2.Z}"));
                writer.WriteLine(FormattableString.Invariant($"      vertex {tri.V3.X} {tri.V3.Y} {tri.V3.Z}"));
                writer.WriteLine("    endloop");
                writer.WriteLine("  endfacet");
            }
            writer.WriteLine("endsolid MillSimSharp");
        }

        /// <summary>
        /// Exports a mesh to STL binary data.
        /// </summary>
        /// <param name="mesh">The mesh to export.</param>
        /// <returns>Binary STL data.</returns>
        public static byte[] ExportToBytes(Mesh mesh)
        {
            List<Triangle> triangles = GenerateTriangles(mesh);

            using (MemoryStream stream = new MemoryStream())
            using (BinaryWriter writer = new BinaryWriter(stream))
            {
                byte[] header = new byte[80];
                string headerText = "MillSimSharp Mesh Export";
                byte[] headerBytes = System.Text.Encoding.ASCII.GetBytes(headerText);
                Array.Copy(headerBytes, header, Math.Min(headerBytes.Length, 80));
                writer.Write(header);

                writer.Write((uint)triangles.Count);

                foreach (Triangle tri in triangles)
                {
                    WriteVector3(writer, tri.Normal);
                    WriteVector3(writer, tri.V1);
                    WriteVector3(writer, tri.V2);
                    WriteVector3(writer, tri.V3);
                    writer.Write((ushort)0);
                }
                return stream.ToArray();
            }
        }

        private static void WriteVector3(BinaryWriter writer, Vector3 v)
        {
            writer.Write((float)v.X);
            writer.Write((float)v.Y);
            writer.Write((float)v.Z);
        }

        private static List<Triangle> GenerateTriangles(VoxelGrid grid)
        {
            List<Triangle> triangles = new List<Triangle>();
            var mesh = Geometry.MeshConverter.ConvertToMesh(grid);

            // Mesh was created by expanding triangles for each triangle; convert to Triangle list
            for (int i = 0; i < mesh.Indices.Length; i += 3)
            {
                Vector3 v1 = mesh.Vertices[mesh.Indices[i + 0]];
                Vector3 v2 = mesh.Vertices[mesh.Indices[i + 1]];
                Vector3 v3 = mesh.Vertices[mesh.Indices[i + 2]];
                triangles.Add(new Triangle(v1, v2, v3, ComputeFacetNormal(v1, v2, v3)));
            }
            return triangles;
        }

        private static List<Triangle> GenerateTriangles(Mesh mesh)
        {
            List<Triangle> triangles = new List<Triangle>();
            if (mesh == null || mesh.Vertices == null || mesh.Indices == null || mesh.Normals == null)
                return triangles;

            for (int i = 0; i < mesh.Indices.Length; i += 3)
            {
                Vector3 v1 = mesh.Vertices[mesh.Indices[i + 0]];
                Vector3 v2 = mesh.Vertices[mesh.Indices[i + 1]];
                Vector3 v3 = mesh.Vertices[mesh.Indices[i + 2]];
                triangles.Add(new Triangle(v1, v2, v3, ComputeFacetNormal(v1, v2, v3)));
            }
            return triangles;
        }

        /// <summary>
        /// Computes the geometric facet normal from the triangle winding. Degenerate triangles
        /// (zero area or non-finite input) get a zero normal; the face is still written.
        /// </summary>
        private static Vector3 ComputeFacetNormal(Vector3 v1, Vector3 v2, Vector3 v3)
        {
            Vector3 normal = Vector3.Cross(v2 - v1, v3 - v1);
            float length = normal.Length();
            return length > 0f ? normal / length : Vector3.Zero;
        }


        private struct Triangle
        {
            public Vector3 V1;
            public Vector3 V2;
            public Vector3 V3;
            public Vector3 Normal;

            public Triangle(Vector3 v1, Vector3 v2, Vector3 v3, Vector3 normal)
            {
                V1 = v1;
                V2 = v2;
                V3 = v3;
                Normal = normal;
            }
        }
    }
}
