using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using System.Threading.Tasks;

namespace MillSimSharp.Geometry
{
    /// <summary>
    /// Sparse Voxel Octree Node
    /// </summary>
    public class SVONode
    {
        /// <summary>
        /// Children nodes (8 for octree)
        /// </summary>
        public SVONode[] children;
        /// <summary>
        /// Is this node a leaf node?
        /// </summary>
        public bool isLeaf;
        /// <summary>
        /// Value at this node (true = empty, false = material)
        /// </summary>
        public bool value;

        /// <summary>
        /// Constructor for SVONode.
        /// </summary>
        public SVONode()
        {
            children = new SVONode[8];
            isLeaf = false;
            value = false;
        }

        /// <summary>
        /// Gets the value at the specified voxel coordinates.
        /// </summary>
        public bool Get(int x, int y, int z, int level, int maxLevel)
        {
            if (isLeaf)
                return value; // true if empty

            if (level >= maxLevel)
                return false; // not empty

            int childIndex = ((x >> (maxLevel - level - 1)) & 1) |
                             (((y >> (maxLevel - level - 1)) & 1) << 1) |
                             (((z >> (maxLevel - level - 1)) & 1) << 2);

            if (children[childIndex] == null)
                return false; // not empty

            return children[childIndex].Get(x, y, z, level + 1, maxLevel);
        }

        /// <summary>
        /// Sets the value at the specified voxel coordinates.
        /// </summary>
        public void Set(int x, int y, int z, bool val, int level, int maxLevel)
        {
            if (level >= maxLevel)
            {
                isLeaf = true;
                value = val; // true for empty
                return;
            }

            int childIndex = ((x >> (maxLevel - level - 1)) & 1) |
                             (((y >> (maxLevel - level - 1)) & 1) << 1) |
                             (((z >> (maxLevel - level - 1)) & 1) << 2);

            if (children[childIndex] == null)
                children[childIndex] = new SVONode();

            children[childIndex].Set(x, y, z, val, level + 1, maxLevel);
        }

        /// <summary>
        /// Counts the number of empty voxels in this subtree up to the specified max level.
        /// </summary>
        public int CountEmpty(int level, int maxLevel)
        {
            if (isLeaf)
                return value ? 1 : 0;

            if (level >= maxLevel)
                return 0;

            int count = 0;
            for (int i = 0; i < 8; i++)
            {
                if (children[i] != null)
                    count += children[i].CountEmpty(level + 1, maxLevel);
            }
            return count;
        }
    }

    /// <summary>
    /// Represents a 3D voxel grid for material simulation using Sparse Voxel Octree.
    /// </summary>
    public class VoxelGrid
    {
        /// <summary>
        /// Event invoked when voxels are changed. Provides min and max indices of the region that changed.
        /// </summary>
        public event Action<int, int, int, int, int, int>? VoxelsChanged;
        private SVONode? _root;
        private readonly int _sizeX;
        private readonly int _sizeY;
        private readonly int _sizeZ;
        private readonly float _resolution;
        private readonly BoundingBox _bounds;
        private readonly int _maxLevel;
        private readonly int _totalVoxels;

        /// <summary>
        /// Gets the resolution (voxel size) in millimeters.
        /// </summary>
        public float Resolution => _resolution;

        /// <summary>
        /// Gets the bounding box of the work area.
        /// </summary>
        public BoundingBox Bounds => _bounds;

        /// <summary>
        /// Gets the dimensions of the voxel grid.
        /// </summary>
        public (int X, int Y, int Z) Dimensions => (_sizeX, _sizeY, _sizeZ);

        /// <summary>
        /// Gets or sets whether large removals may collect candidate voxels in parallel.
        /// The sparse voxel octree is always committed on a single thread, so the resulting voxel
        /// state is deterministic regardless of this setting.
        /// </summary>
        public bool UseParallelRemoval { get; set; } = true;

        /// <summary>
        /// Creates a new voxel grid with the specified work area and resolution.
        /// <para>
        /// Dimensions are rounded up to whole voxels. <see cref="Bounds"/> reports the effective
        /// voxelized extent (<c>Min + Dimensions * Resolution</c>), so a requested size that is not
        /// divisible by the resolution expands by less than one voxel per axis (Max side only).
        /// </para>
        /// <para>
        /// The work area must have a positive, finite size in every dimension; zero-size bounds are
        /// rejected (matching <see cref="SDFGrid"/>).
        /// </para>
        /// </summary>
        /// <param name="workArea">The bounding box defining the work area.</param>
        /// <param name="resolution">Voxel size in millimeters (default: 0.5mm).</param>
        /// <exception cref="ArgumentNullException">Thrown when <paramref name="workArea"/> is null.</exception>
        /// <exception cref="ArgumentException">Thrown when <paramref name="resolution"/> is not a
        /// finite positive number, the work area has a zero or non-finite size in any dimension, or
        /// the grid would contain more voxels than <see cref="int.MaxValue"/> (the public voxel
        /// counts are <see cref="int"/>-based).</exception>
        public VoxelGrid(BoundingBox workArea, float resolution = 0.5f)
        {
            if (workArea == null) throw new ArgumentNullException(nameof(workArea));
            if (!float.IsFinite(resolution) || resolution <= 0)
                throw new ArgumentException("Resolution must be a finite positive number.", nameof(resolution));

            _resolution = resolution;

            // Calculate grid dimensions
            Vector3 size = workArea.Size;
            if (!IsFinitePositive(size))
                throw new ArgumentException("Work area must have a finite positive size in all dimensions.", nameof(workArea));

            // Voxel dimensions. The quotient must fit in int before the cast, otherwise the cast
            // would wrap (for example an enormous work area at a tiny resolution).
            double sizeX = Math.Ceiling(size.X / resolution);
            double sizeY = Math.Ceiling(size.Y / resolution);
            double sizeZ = Math.Ceiling(size.Z / resolution);
            if (!(sizeX <= int.MaxValue) || !(sizeY <= int.MaxValue) || !(sizeZ <= int.MaxValue))
            {
                throw new ArgumentException(
                    $"The work area contains more than {int.MaxValue} voxels; reduce the work area or increase the resolution.",
                    nameof(workArea));
            }

            _sizeX = (int)sizeX;
            _sizeY = (int)sizeY;
            _sizeZ = (int)sizeZ;

            // The public voxel counts (CountMaterialVoxels, GetMaterialVoxelCount) are int-based:
            // reject grids that cannot be represented instead of overflowing. Each factor is bounded
            // before multiplying, so the product itself cannot overflow (factors fit in int, and each
            // intermediate result is checked against int.MaxValue).
            long totalVoxels = _sizeX;
            if (totalVoxels > int.MaxValue / _sizeY)
            {
                throw new ArgumentException(
                    $"The work area contains more than {int.MaxValue} voxels; reduce the work area or increase the resolution.",
                    nameof(workArea));
            }
            totalVoxels *= _sizeY;

            if (totalVoxels > int.MaxValue / _sizeZ)
            {
                throw new ArgumentException(
                    $"The work area contains more than {int.MaxValue} voxels; reduce the work area or increase the resolution.",
                    nameof(workArea));
            }
            totalVoxels *= _sizeZ;

            _totalVoxels = (int)totalVoxels;

            // Effective bounds of the discretized field: whole voxels from the requested minimum.
            _bounds = new BoundingBox(
                workArea.Min,
                workArea.Min + new Vector3(_sizeX, _sizeY, _sizeZ) * resolution);

            // Calculate max level for SVO
            int maxDim = Math.Max(_sizeX, Math.Max(_sizeY, _sizeZ));
            _maxLevel = (int)Math.Ceiling(Math.Log(maxDim, 2));

            // Root is null initially, meaning all voxels are material (true)
            _root = null;
        }

        /// <summary>
        /// Checks that a grid size is finite and strictly positive on every axis.
        /// </summary>
        private static bool IsFinitePositive(Vector3 size)
        {
            return float.IsFinite(size.X) && size.X > 0f
                && float.IsFinite(size.Y) && size.Y > 0f
                && float.IsFinite(size.Z) && size.Z > 0f;
        }

        /// <summary>
        /// Converts world coordinates to voxel indices (floor semantics).
        /// </summary>
        private (int x, int y, int z) WorldToVoxel(Vector3 worldPos)
        {
            Vector3 localPos = worldPos - _bounds.Min;
            return (
                (int)MathF.Floor(localPos.X / _resolution),
                (int)MathF.Floor(localPos.Y / _resolution),
                (int)MathF.Floor(localPos.Z / _resolution)
            );
        }

        /// <summary>
        /// Converts voxel indices to world coordinates (center of voxel).
        /// </summary>
        private Vector3 VoxelToWorld(int x, int y, int z)
        {
            return _bounds.Min + new Vector3(
                (x + 0.5f) * _resolution,
                (y + 0.5f) * _resolution,
                (z + 0.5f) * _resolution
            );
        }

        /// <summary>
        /// Checks if voxel indices are within bounds.
        /// </summary>
        private bool IsValidIndex(int x, int y, int z)
        {
            return x >= 0 && x < _sizeX &&
                   y >= 0 && y < _sizeY &&
                   z >= 0 && z < _sizeZ;
        }

        /// <summary>
        /// Converts 3D indices to 1D array index.
        /// </summary>
        private int GetIndex(int x, int y, int z)
        {
            return x + y * _sizeX + z * _sizeX * _sizeY;
        }

        /// <summary>
        /// Gets the material state of a voxel at the specified indices.
        /// </summary>
        /// <returns>True if the voxel contains material, false if empty.</returns>
        public bool GetVoxel(int x, int y, int z)
        {
            if (!IsValidIndex(x, y, z))
                return false;

            if (_root == null)
                return true; // default material

            return !_root.Get(x, y, z, 0, _maxLevel); // Get returns true if empty, so ! for material
        }

        /// <summary>
        /// Sets the material state of a voxel at the specified indices.
        /// <para>
        /// Raises <see cref="VoxelsChanged"/> when the material state actually changes; setting the
        /// same value again is a no-op. Bulk removals mutate through <see cref="SetVoxelRaw"/> and
        /// report the aggregated dirty region once, so no per-voxel event storm occurs.
        /// </para>
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="z"></param>
        /// <param name="isMaterial"></param>
        public void SetVoxel(int x, int y, int z, bool isMaterial)
        {
            if (!IsValidIndex(x, y, z))
                return;

            if (GetVoxel(x, y, z) == isMaterial)
                return; // same value: no material change, no notification

            SetVoxelRaw(x, y, z, isMaterial);
            ReportChange(x, y, z, x, y, z);
        }

        /// <summary>
        /// Mutates a voxel without raising <see cref="VoxelsChanged"/>. Bulk operations use this
        /// and report the aggregated dirty region exactly once.
        /// </summary>
        /// <param name="x">Voxel index X (must be valid).</param>
        /// <param name="y">Voxel index Y (must be valid).</param>
        /// <param name="z">Voxel index Z (must be valid).</param>
        /// <param name="isMaterial">True for material, false for empty.</param>
        private void SetVoxelRaw(int x, int y, int z, bool isMaterial)
        {
            if (_root == null)
                _root = new SVONode();
            _root.Set(x, y, z, !isMaterial, 0, _maxLevel); // !isMaterial: true for empty, false for material
        }

        /// <summary>
        /// Gets the material state of a voxel at world coordinates.
        /// </summary>
        public bool GetVoxelAtWorld(Vector3 worldPos)
        {
            var (x, y, z) = WorldToVoxel(worldPos);
            return GetVoxel(x, y, z);
        }

        /// <summary>
        /// Sets the material state of a voxel at world coordinates.
        /// </summary>
        public void SetVoxelAtWorld(Vector3 worldPos, bool isMaterial)
        {
            var (x, y, z) = WorldToVoxel(worldPos);
            SetVoxel(x, y, z, isMaterial);
        }

        // Batch edit state: while editing, changes are accumulated and reported once on EndEdit.
        private int _editDepth;
        private bool _editHasChanges;
        private int _editMinX = int.MaxValue, _editMinY = int.MaxValue, _editMinZ = int.MaxValue;
        private int _editMaxX = int.MinValue, _editMaxY = int.MinValue, _editMaxZ = int.MinValue;

        /// <summary>
        /// Begins a batch edit. While active, <see cref="VoxelsChanged"/> is not raised for each
        /// operation; the aggregated changed bounds are reported once by <see cref="EndEdit"/>.
        /// </summary>
        public void BeginEdit()
        {
            _editDepth++;
        }

        /// <summary>
        /// Ends a batch edit and raises <see cref="VoxelsChanged"/> once with the aggregated
        /// changed bounds (if anything actually changed).
        /// </summary>
        /// <exception cref="InvalidOperationException">Thrown when called without a matching BeginEdit.</exception>
        public void EndEdit()
        {
            if (_editDepth == 0)
                throw new InvalidOperationException("EndEdit called without a matching BeginEdit.");

            _editDepth--;
            if (_editDepth > 0 || !_editHasChanges) return;

            int minX = _editMinX, minY = _editMinY, minZ = _editMinZ;
            int maxX = _editMaxX, maxY = _editMaxY, maxZ = _editMaxZ;

            _editHasChanges = false;
            _editMinX = int.MaxValue; _editMinY = int.MaxValue; _editMinZ = int.MaxValue;
            _editMaxX = int.MinValue; _editMaxY = int.MinValue; _editMaxZ = int.MinValue;

            VoxelsChanged?.Invoke(minX, minY, minZ, maxX, maxY, maxZ);
        }

        /// <summary>
        /// Reports a changed region, either immediately or accumulated into the current batch edit.
        /// </summary>
        private void ReportChange(int minX, int minY, int minZ, int maxX, int maxY, int maxZ)
        {
            if (_editDepth > 0)
            {
                _editHasChanges = true;
                if (minX < _editMinX) _editMinX = minX;
                if (minY < _editMinY) _editMinY = minY;
                if (minZ < _editMinZ) _editMinZ = minZ;
                if (maxX > _editMaxX) _editMaxX = maxX;
                if (maxY > _editMaxY) _editMaxY = maxY;
                if (maxZ > _editMaxZ) _editMaxZ = maxZ;
                return;
            }

            VoxelsChanged?.Invoke(minX, minY, minZ, maxX, maxY, maxZ);
        }

        private const int ParallelRemovalThreshold = 1000;
        private const int MaxParallelRemovalVolume = 4_000_000;

        /// <summary>
        /// Removes voxels in the region sequentially and reports the exact changed bounds.
        /// </summary>
        private void RemoveSequentially(int minX, int minY, int minZ, int maxX, int maxY, int maxZ, Func<int, int, int, bool> shouldRemove)
        {
            int changedMinX = int.MaxValue, changedMinY = int.MaxValue, changedMinZ = int.MaxValue;
            int changedMaxX = int.MinValue, changedMaxY = int.MinValue, changedMaxZ = int.MinValue;

            for (int z = minZ; z <= maxZ; z++)
                for (int y = minY; y <= maxY; y++)
                    for (int x = minX; x <= maxX; x++)
                    {
                        if (!shouldRemove(x, y, z) || !GetVoxel(x, y, z)) continue;

                        SetVoxelRaw(x, y, z, false);
                        if (x < changedMinX) changedMinX = x;
                        if (y < changedMinY) changedMinY = y;
                        if (z < changedMinZ) changedMinZ = z;
                        if (x > changedMaxX) changedMaxX = x;
                        if (y > changedMaxY) changedMaxY = y;
                        if (z > changedMaxZ) changedMaxZ = z;
                    }

            if (changedMinX <= changedMaxX)
            {
                ReportChange(changedMinX, changedMinY, changedMinZ, changedMaxX, changedMaxY, changedMaxZ);
            }
        }

        /// <summary>
        /// Collects candidate voxels in parallel (read-only queries) and commits them to the
        /// sparse voxel octree on a single thread. This keeps results deterministic.
        /// </summary>
        private void RemoveInParallel(int minX, int minY, int minZ, int maxX, int maxY, int maxZ, Func<int, int, int, bool> shouldRemove)
        {
            var removals = new List<(int x, int y, int z)>();
            var sync = new object();

            Parallel.For(minZ, maxZ + 1,
                () => new List<(int x, int y, int z)>(),
                (z, _, local) =>
                {
                    for (int y = minY; y <= maxY; y++)
                        for (int x = minX; x <= maxX; x++)
                        {
                            if (shouldRemove(x, y, z) && GetVoxel(x, y, z))
                            {
                                local.Add((x, y, z));
                            }
                        }
                    return local;
                },
                local =>
                {
                    lock (sync) removals.AddRange(local);
                });

            int changedMinX = int.MaxValue, changedMinY = int.MaxValue, changedMinZ = int.MaxValue;
            int changedMaxX = int.MinValue, changedMaxY = int.MinValue, changedMaxZ = int.MinValue;

            foreach (var (x, y, z) in removals)
            {
                SetVoxelRaw(x, y, z, false);
                if (x < changedMinX) changedMinX = x;
                if (y < changedMinY) changedMinY = y;
                if (z < changedMinZ) changedMinZ = z;
                if (x > changedMaxX) changedMaxX = x;
                if (y > changedMaxY) changedMaxY = y;
                if (z > changedMaxZ) changedMaxZ = z;
            }

            if (changedMinX <= changedMaxX)
            {
                ReportChange(changedMinX, changedMinY, changedMinZ, changedMaxX, changedMaxY, changedMaxZ);
            }
        }

        /// <summary>
        /// Removes voxels in the specified index region for which <paramref name="shouldRemove"/>
        /// returns true. The region is clamped to the grid. Large regions use the deterministic
        /// two-phase parallel path.
        /// </summary>
        internal void RemoveVoxelsInRegion(int minX, int minY, int minZ, int maxX, int maxY, int maxZ, Func<int, int, int, bool> shouldRemove)
        {
            minX = Math.Max(0, minX);
            minY = Math.Max(0, minY);
            minZ = Math.Max(0, minZ);
            maxX = Math.Min(_sizeX - 1, maxX);
            maxY = Math.Min(_sizeY - 1, maxY);
            maxZ = Math.Min(_sizeZ - 1, maxZ);
            if (minX > maxX || minY > maxY || minZ > maxZ) return;

            int volumeSize = (maxZ - minZ + 1) * (maxY - minY + 1) * (maxX - minX + 1);
            if (UseParallelRemoval && volumeSize > ParallelRemovalThreshold && volumeSize <= MaxParallelRemovalVolume)
            {
                RemoveInParallel(minX, minY, minZ, maxX, maxY, maxZ, shouldRemove);
            }
            else
            {
                RemoveSequentially(minX, minY, minZ, maxX, maxY, maxZ, shouldRemove);
            }
        }

        /// <summary>
        /// Removes voxels whose center lies inside the tool solid described by
        /// <paramref name="signedDistance"/> (negative = inside) within <paramref name="worldBounds"/>.
        /// </summary>
        internal void RemoveVoxelsInRegion(BoundingBox worldBounds, Func<Vector3, float> signedDistance)
        {
            if (worldBounds == null) throw new ArgumentNullException(nameof(worldBounds));
            if (signedDistance == null) throw new ArgumentNullException(nameof(signedDistance));

            var (minX, minY, minZ) = WorldToVoxel(worldBounds.Min);
            var (maxX, maxY, maxZ) = WorldToVoxel(worldBounds.Max);

            RemoveVoxelsInRegion(minX, minY, minZ, maxX, maxY, maxZ,
                (x, y, z) => signedDistance(VoxelToWorld(x, y, z)) < 0f);
        }

        /// <summary>
        /// Checks whether any material voxel center inside <paramref name="worldBounds"/> also lies
        /// inside the tool solid described by <paramref name="signedDistance"/> (negative = inside).
        /// Read-only: does not modify the grid.
        /// </summary>
        internal bool IntersectsToolSolid(BoundingBox worldBounds, Func<Vector3, float> signedDistance)
        {
            if (worldBounds == null) throw new ArgumentNullException(nameof(worldBounds));
            if (signedDistance == null) throw new ArgumentNullException(nameof(signedDistance));

            var (minX, minY, minZ) = WorldToVoxel(worldBounds.Min);
            var (maxX, maxY, maxZ) = WorldToVoxel(worldBounds.Max);

            minX = Math.Max(0, minX);
            minY = Math.Max(0, minY);
            minZ = Math.Max(0, minZ);
            maxX = Math.Min(_sizeX - 1, maxX);
            maxY = Math.Min(_sizeY - 1, maxY);
            maxZ = Math.Min(_sizeZ - 1, maxZ);
            if (minX > maxX || minY > maxY || minZ > maxZ) return false;

            for (int z = minZ; z <= maxZ; z++)
                for (int y = minY; y <= maxY; y++)
                    for (int x = minX; x <= maxX; x++)
                    {
                        if (!GetVoxel(x, y, z)) continue;
                        if (signedDistance(VoxelToWorld(x, y, z)) < 0f) return true;
                    }

            return false;
        }

        /// <summary>
        /// Removes all voxels whose center lies strictly inside a sphere (sets them to empty).
        /// A voxel center exactly on the surface is preserved (<c>signedDistance &lt; 0</c>
        /// convention), matching the tool geometry path.
        /// <para>
        /// Large removals collect candidate voxels in parallel but commit to the sparse voxel
        /// octree on a single thread, so results are deterministic.
        /// </para>
        /// </summary>
        /// <param name="center">Center of the sphere in world coordinates.</param>
        /// <param name="radius">Radius of the sphere in millimeters.</param>
        public void RemoveVoxelsInSphere(Vector3 center, float radius)
        {
            // Calculate bounding box of the sphere in voxel space
            var (minX, minY, minZ) = WorldToVoxel(center - new Vector3(radius, radius, radius));
            var (maxX, maxY, maxZ) = WorldToVoxel(center + new Vector3(radius, radius, radius));

            // Clamp to grid bounds
            minX = Math.Max(0, minX);
            minY = Math.Max(0, minY);
            minZ = Math.Max(0, minZ);
            maxX = Math.Min(_sizeX - 1, maxX);
            maxY = Math.Min(_sizeY - 1, maxY);
            maxZ = Math.Min(_sizeZ - 1, maxZ);
            if (minX > maxX || minY > maxY || minZ > maxZ) return;

            float radiusSquared = radius * radius;

            bool ShouldRemove(int x, int y, int z)
            {
                // Early rejection: skip Y slice if too far from center
                float yDist = Math.Abs(VoxelToWorld(0, y, 0).Y - center.Y);
                if (yDist > radius) return false;
                return Vector3.DistanceSquared(VoxelToWorld(x, y, z), center) < radiusSquared;
            }

            RemoveVoxelsInRegion(minX, minY, minZ, maxX, maxY, maxZ, ShouldRemove);
        }

        /// <summary>
        /// Removes all voxels whose center lies strictly inside a cylinder (sets them to empty).
        /// A voxel center exactly on the surface is preserved (<c>signedDistance &lt; 0</c>
        /// convention), matching the tool geometry path.
        /// <para>
        /// Large removals collect candidate voxels in parallel but commit to the sparse voxel
        /// octree on a single thread, so results are deterministic.
        /// </para>
        /// </summary>
        /// <param name="start">Start point of the cylinder axis in world coordinates.</param>
        /// <param name="end">End point of the cylinder axis in world coordinates.</param>
        /// <param name="radius">Radius of the cylinder in millimeters.</param>
        /// <param name="flatEnds">If true, the cylinder has flat ends. If false, it has hemispherical ends (capsule).</param>
        public void RemoveVoxelsInCylinder(Vector3 start, Vector3 end, float radius, bool flatEnds = false)
        {
            Vector3 axis = end - start;
            float length = axis.Length();

            if (length < 1e-6f)
            {
                // Degenerate cases match the SDF backend semantics:
                // capsule -> sphere, flat-ended cylinder -> no volume (nothing removed).
                if (!flatEnds)
                    RemoveVoxelsInSphere(start, radius);
                return;
            }

            Vector3 axisDir = Vector3.Normalize(axis);

            // Calculate bounding box of the cylinder
            Vector3 min = new Vector3(
                Math.Min(start.X, end.X) - radius,
                Math.Min(start.Y, end.Y) - radius,
                Math.Min(start.Z, end.Z) - radius
            );
            Vector3 max = new Vector3(
                Math.Max(start.X, end.X) + radius,
                Math.Max(start.Y, end.Y) + radius,
                Math.Max(start.Z, end.Z) + radius
            );

            var (minX, minY, minZ) = WorldToVoxel(min);
            var (maxX, maxY, maxZ) = WorldToVoxel(max);

            // Clamp to grid bounds
            minX = Math.Max(0, minX);
            minY = Math.Max(0, minY);
            minZ = Math.Max(0, minZ);
            maxX = Math.Min(_sizeX - 1, maxX);
            maxY = Math.Min(_sizeY - 1, maxY);
            maxZ = Math.Min(_sizeZ - 1, maxZ);
            if (minX > maxX || minY > maxY || minZ > maxZ) return;

            float radiusSquared = radius * radius;

            bool ShouldRemove(int x, int y, int z)
            {
                Vector3 voxelCenter = VoxelToWorld(x, y, z);

                // Calculate distance from voxel to cylinder axis
                Vector3 toVoxel = voxelCenter - start;
                float projectionLength = Vector3.Dot(toVoxel, axisDir);

                // Check if projection is within cylinder length with tolerance
                if (projectionLength >= -1e-5f && projectionLength <= length + 1e-5f)
                {
                    Vector3 closestPoint = start + axisDir * projectionLength;
                    return Vector3.DistanceSquared(voxelCenter, closestPoint) < radiusSquared;
                }

                if (!flatEnds)
                {
                    // Check distance to end caps (spheres)
                    float distToStart = Vector3.DistanceSquared(voxelCenter, start);
                    float distToEnd = Vector3.DistanceSquared(voxelCenter, end);
                    return distToStart < radiusSquared || distToEnd < radiusSquared;
                }

                return false;
            }

            RemoveVoxelsInRegion(minX, minY, minZ, maxX, maxY, maxZ, ShouldRemove);
        }

        /// <summary>
        /// Clears all voxels (resets to all material).
        /// Raises <see cref="VoxelsChanged"/> once when the reset actually changes the grid.
        /// </summary>
        public void Clear()
        {
            if (_root == null)
                return; // already all material

            int emptyVoxels = _root.CountEmpty(0, _maxLevel);
            _root = null;

            if (emptyVoxels > 0)
            {
                ReportChange(0, 0, 0, _sizeX - 1, _sizeY - 1, _sizeZ - 1);
            }
        }

        /// <summary>
        /// Returns a dense 3D array of voxel material states for fast access.
        /// </summary>
        public bool[][][] ToDenseArray()
        {
            bool[][][] dense = new bool[_sizeX][][];
            for (int x = 0; x < _sizeX; x++)
            {
                dense[x] = new bool[_sizeY][];
                for (int y = 0; y < _sizeY; y++)
                {
                    dense[x][y] = new bool[_sizeZ];
                    for (int z = 0; z < _sizeZ; z++)
                    {
                        dense[x][y][z] = GetVoxel(x, y, z);
                    }
                }
            }
            return dense;
        }

        /// <summary>
        /// Counts the number of voxels containing material.
        /// </summary>
        public int CountMaterialVoxels()
        {
            return _totalVoxels - (_root?.CountEmpty(0, _maxLevel) ?? 0);
        }

        /// <summary>
        /// Gets the material volume in cubic millimeters (material voxel count times the voxel
        /// volume). The value is center-sampled and therefore resolution-limited, matching
        /// <see cref="SDFGrid.GetMaterialVolume"/>.
        /// </summary>
        /// <returns>Material volume in mm^3.</returns>
        public double GetMaterialVolume()
        {
            return CountMaterialVoxels() * (double)_resolution * _resolution * _resolution;
        }

        /// <summary>
        /// Gets the air (non-material) volume inside the effective bounds in cubic millimeters.
        /// The value is center-sampled and therefore resolution-limited, matching
        /// <see cref="SDFGrid.GetRemovedVolume"/>.
        /// </summary>
        /// <returns>Removed volume in mm^3.</returns>
        public double GetRemovedVolume()
        {
            return (_totalVoxels - CountMaterialVoxels()) * (double)_resolution * _resolution * _resolution;
        }

        /// <summary>
        /// Get list of occupied voxel coordinates.
        /// </summary>
        public List<(int x, int y, int z)> GetOccupiedVoxels()
        {
            var list = new List<(int x, int y, int z)>();
            if (_root == null)
            {
                // All voxels are occupied
                for (int z = 0; z < _sizeZ; z++)
                    for (int y = 0; y < _sizeY; y++)
                        for (int x = 0; x < _sizeX; x++)
                        {
                            list.Add((x, y, z));
                        }
            }
            else
            {
                TraverseOccupied(_root, 0, 0, 0, 0, _maxLevel, list);
            }
            return list;
        }

        private void TraverseOccupied(SVONode? node, int x, int y, int z, int level, int maxLevel, List<(int, int, int)> list)
        {
            // The octree is a padded cube (2^maxLevel per axis), so regions that start outside the
            // real grid dimensions are padding and must not be reported as occupied voxels.
            if (x >= _sizeX || y >= _sizeY || z >= _sizeZ) return;

            if (node != null && node.isLeaf)
            {
                if (node.value) return; // empty leaf
                AddOccupiedRegion(x, y, z, 1 << (maxLevel - level), list);
                return;
            }

            if (level >= maxLevel)
            {
                // Voxel-level cell: a missing node is material (the default fill).
                if (node == null || !node.value)
                {
                    list.Add((x, y, z));
                }
                return;
            }

            int childSize = 1 << (maxLevel - level - 1);
            for (int i = 0; i < 8; i++)
            {
                int cx = x + ((i & 1) != 0 ? childSize : 0);
                int cy = y + ((i & 2) != 0 ? childSize : 0);
                int cz = z + ((i & 4) != 0 ? childSize : 0);
                SVONode? child = node?.children[i];
                TraverseOccupied(child, cx, cy, cz, level + 1, maxLevel, list);
            }
        }

        /// <summary>
        /// Adds every voxel of a material region that lies inside the real grid dimensions.
        /// </summary>
        private void AddOccupiedRegion(int x0, int y0, int z0, int size, List<(int, int, int)> list)
        {
            int xMax = Math.Min(x0 + size - 1, _sizeX - 1);
            int yMax = Math.Min(y0 + size - 1, _sizeY - 1);
            int zMax = Math.Min(z0 + size - 1, _sizeZ - 1);

            for (int z = z0; z <= zMax; z++)
                for (int y = y0; y <= yMax; y++)
                    for (int x = x0; x <= xMax; x++)
                        list.Add((x, y, z));
        }

        /// <summary>
        /// Convert this VoxelGrid into a Mesh using the marching cubes algorithm.
        /// </summary>
        /// <returns>A Mesh representing the surface of the material in the voxel grid.</returns>
        public Mesh ToMesh()
        {
            return MeshConverter.ConvertToMesh(this);
        }
    }
}
