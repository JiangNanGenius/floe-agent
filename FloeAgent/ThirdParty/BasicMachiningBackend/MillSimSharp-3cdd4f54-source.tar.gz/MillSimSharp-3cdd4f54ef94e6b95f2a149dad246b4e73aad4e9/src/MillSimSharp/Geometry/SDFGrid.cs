using System;
using System.Numerics;
using System.Threading.Tasks;

namespace MillSimSharp.Geometry
{
    /// <summary>
    /// Represents a Signed Distance Field (SDF) grid.
    /// <para>
    /// Sign convention (standard SDF): negative = material (solid), positive = empty
    /// (air / removed material), zero = surface. All stored values and distance APIs are in
    /// world-space millimeters.
    /// </para>
    /// <para>
    /// Samples live at voxel centers. Distances from voxel-based construction are computed with
    /// an exact Euclidean Distance Transform and corrected by half a voxel so the zero level set
    /// lies between adjacent voxel centers. Cells outside the grid bounds are treated as empty.
    /// </para>
    /// </summary>
    public class SDFGrid
    {
        private readonly object _sync = new object();
        private readonly int _sizeX;
        private readonly int _sizeY;
        private readonly int _sizeZ;
        private readonly float _resolution;
        private readonly BoundingBox _bounds;
        private readonly float _narrowBandWidth;
        private readonly float[,,] _distances;
        private VoxelGrid? _sourceVoxelGrid;
        private VoxelGrid? _subscribedVoxelGrid;

        /// <summary>
        /// Gets the resolution (voxel size) in millimeters.
        /// </summary>
        public float Resolution => _resolution;

        /// <summary>
        /// Gets the bounding box of the field.
        /// </summary>
        public BoundingBox Bounds => _bounds;

        /// <summary>
        /// Gets the dimensions of the SDF grid.
        /// </summary>
        public (int X, int Y, int Z) Dimensions => (_sizeX, _sizeY, _sizeZ);

        /// <summary>
        /// Gets the narrow band width in millimeters (maximum distance computed accurately).
        /// </summary>
        public float NarrowBandWidth => _narrowBandWidth;

        /// <summary>
        /// Creates an SDF grid with all material (negative distances).
        /// <para>
        /// Dimensions are rounded up to whole voxels. <see cref="Bounds"/> reports the effective
        /// voxelized extent (<c>Min + Dimensions * Resolution</c>), matching
        /// <see cref="VoxelGrid"/>: a requested size that is not divisible by the resolution
        /// expands by less than one voxel per axis (Max side only).
        /// </para>
        /// <para>
        /// The bounds must have a positive, finite size in every dimension; zero-size bounds are
        /// rejected instead of being clamped to a single voxel per axis. The grid is stored densely,
        /// so bounds whose sample count exceeds <see cref="int.MaxValue"/> are rejected as well.
        /// </para>
        /// </summary>
        /// <param name="bounds">Bounding box of the SDF grid.</param>
        /// <param name="resolution">Voxel size in millimeters.</param>
        /// <param name="narrowBandWidth">Width of the narrow band in voxels (default: 10).</param>
        /// <exception cref="ArgumentNullException">Thrown when <paramref name="bounds"/> is null.</exception>
        /// <exception cref="ArgumentException">Thrown when <paramref name="resolution"/> or
        /// <paramref name="narrowBandWidth"/> is not positive, the bounds have a zero or non-finite
        /// size in any dimension, or the grid would contain more samples than
        /// <see cref="int.MaxValue"/>.</exception>
        public SDFGrid(BoundingBox bounds, float resolution, int narrowBandWidth = 10)
        {
            if (bounds == null) throw new ArgumentNullException(nameof(bounds));
            if (!float.IsFinite(resolution) || resolution <= 0) throw new ArgumentException("Resolution must be a finite positive number.", nameof(resolution));
            if (narrowBandWidth <= 0) throw new ArgumentException("Narrow band width must be positive.", nameof(narrowBandWidth));

            var size = bounds.Max - bounds.Min;
            if (!IsFinitePositive(size)) throw new ArgumentException("Bounds must have a finite positive size in all dimensions.", nameof(bounds));

            // The sample count is validated like VoxelGrid's voxel count: each dimension must fit in
            // int before the cast (an extreme quotient would otherwise wrap) and the total (dense
            // float array) must fit the int-based indexing / count APIs.
            double sizeX = Math.Ceiling(size.X / resolution);
            double sizeY = Math.Ceiling(size.Y / resolution);
            double sizeZ = Math.Ceiling(size.Z / resolution);
            if (!(sizeX <= int.MaxValue) || !(sizeY <= int.MaxValue) || !(sizeZ <= int.MaxValue))
            {
                throw new ArgumentException(
                    $"The SDF grid would contain more than {int.MaxValue} samples; increase the resolution or reduce the bounds.",
                    nameof(bounds));
            }

            long totalSamples = (int)sizeX;
            if (totalSamples > int.MaxValue / (int)sizeY)
            {
                throw new ArgumentException(
                    $"The SDF grid would contain more than {int.MaxValue} samples; increase the resolution or reduce the bounds.",
                    nameof(bounds));
            }
            totalSamples *= (int)sizeY;

            if (totalSamples > int.MaxValue / (int)sizeZ)
            {
                throw new ArgumentException(
                    $"The SDF grid would contain more than {int.MaxValue} samples; increase the resolution or reduce the bounds.",
                    nameof(bounds));
            }

            _sizeX = (int)sizeX;
            _sizeY = (int)sizeY;
            _sizeZ = (int)sizeZ;
            _resolution = resolution;
            _bounds = new BoundingBox(
                bounds.Min,
                bounds.Min + new Vector3(_sizeX, _sizeY, _sizeZ) * resolution);
            _narrowBandWidth = narrowBandWidth * resolution;
            _distances = new float[_sizeX, _sizeY, _sizeZ];
            _sourceVoxelGrid = null;
            _subscribedVoxelGrid = null;

            FillSolidBlock();
        }

        /// <summary>
        /// Creates an SDF grid from an existing VoxelGrid.
        /// <para>
        /// This takes a one-time snapshot: later voxel changes are not reflected until the SDF is
        /// bound with <see cref="BindToVoxelGrid"/> (for live incremental updates) and/or
        /// synchronized with <see cref="SyncFromVoxelGrid"/>. The source grid is remembered so
        /// <see cref="SyncFromVoxelGrid"/> can rebuild from it.
        /// </para>
        /// </summary>
        /// <param name="voxelGrid">Source voxel grid.</param>
        /// <param name="narrowBandWidth">Width of the narrow band in voxels (default: 10).</param>
        public static SDFGrid FromVoxelGrid(VoxelGrid voxelGrid, int narrowBandWidth = 10)
        {
            if (voxelGrid == null) throw new ArgumentNullException(nameof(voxelGrid));

            var dimensions = voxelGrid.Dimensions;
            var sdf = new SDFGrid(voxelGrid, dimensions.X, dimensions.Y, dimensions.Z,
                                  voxelGrid.Resolution, voxelGrid.Bounds, narrowBandWidth);

            SignedDistanceFieldBuilder.ComputeRegion(
                (x, y, z) => voxelGrid.GetVoxel(x, y, z),
                dimensions.X, dimensions.Y, dimensions.Z,
                voxelGrid.Resolution, sdf._narrowBandWidth,
                sdf._distances,
                0, 0, 0,
                dimensions.X - 1, dimensions.Y - 1, dimensions.Z - 1);

            return sdf;
        }

        /// <summary>
        /// Private constructor used by FromVoxelGrid. Distances are filled by the caller and the
        /// source grid is remembered for <see cref="SyncFromVoxelGrid"/>; no events are subscribed
        /// until <see cref="BindToVoxelGrid"/> is called.
        /// </summary>
        private SDFGrid(VoxelGrid voxelGrid, int sizeX, int sizeY, int sizeZ,
               float resolution, BoundingBox bounds, int narrowBandWidth)
        {
            if (narrowBandWidth <= 0) throw new ArgumentException("Narrow band width must be positive.", nameof(narrowBandWidth));

            _sizeX = sizeX;
            _sizeY = sizeY;
            _sizeZ = sizeZ;
            _resolution = resolution;
            _bounds = bounds;
            _narrowBandWidth = narrowBandWidth * resolution;
            _distances = new float[_sizeX, _sizeY, _sizeZ];
            _sourceVoxelGrid = voxelGrid;
            _subscribedVoxelGrid = null;
        }

        /// <summary>
        /// Initializes the field as a solid block filling the effective bounds: material inside
        /// (negative) with the analytic distance to the nearest boundary face, clamped to the
        /// narrow band. Outside the bounds is air, matching <see cref="GetDistance(Vector3)"/>.
        /// </summary>
        private void FillSolidBlock()
        {
            for (int z = 0; z < _sizeZ; z++)
                for (int y = 0; y < _sizeY; y++)
                    for (int x = 0; x < _sizeX; x++)
                    {
                        Vector3 center = VoxelToWorld(x, y, z);
                        float distance = BoxSignedDistance(center);
                        _distances[x, y, z] = ClampToNarrowBand(distance);
                    }
        }

        /// <summary>
        /// Signed distance to the effective bounds box (negative inside, positive outside).
        /// </summary>
        private float BoxSignedDistance(Vector3 point)
        {
            float dx = MathF.Max(_bounds.Min.X - point.X, point.X - _bounds.Max.X);
            float dy = MathF.Max(_bounds.Min.Y - point.Y, point.Y - _bounds.Max.Y);
            float dz = MathF.Max(_bounds.Min.Z - point.Z, point.Z - _bounds.Max.Z);

            float outsideSquared = MathF.Max(dx, 0f) * MathF.Max(dx, 0f)
                                 + MathF.Max(dy, 0f) * MathF.Max(dy, 0f)
                                 + MathF.Max(dz, 0f) * MathF.Max(dz, 0f);
            float inside = MathF.Min(MathF.Max(dx, MathF.Max(dy, dz)), 0f);
            return MathF.Sqrt(outsideSquared) + inside;
        }

        private float ClampToNarrowBand(float value)
        {
            if (value < -_narrowBandWidth) return -_narrowBandWidth;
            if (value > _narrowBandWidth) return _narrowBandWidth;
            return value;
        }

        /// <summary>
        /// Checks that a grid size is finite and strictly positive on every axis.
        /// </summary>
        private static bool IsFinitePositive(Vector3 size)
        {
            return float.IsFinite(size.X) && size.X > 0f
                && float.IsFinite(size.Y) && size.Y > 0f
                && float.IsFinite(size.Z) && size.Z > 0f;
        }

        /// <summary>
        /// Binds to a VoxelGrid so that future voxel changes update this SDF incrementally.
        /// The grid must describe the same field (dimensions, resolution and bounds), otherwise
        /// voxel indices and world coordinates would not correspond.
        /// <para>
        /// Binding only subscribes to future changes: existing values (including voxel edits made
        /// before the call) are not synchronized. Use <see cref="SyncFromVoxelGrid"/> for a full
        /// rebuild. Direct carving into the SDF (for example <see cref="RemoveSphere"/>) is allowed
        /// while bound, but any region rebuilt from a later voxel change overwrites those edits;
        /// call <see cref="UnbindFromVoxelGrid"/> to keep SDF-native edits. The grid is also
        /// remembered as the sync source for <see cref="SyncFromVoxelGrid"/>.
        /// </para>
        /// </summary>
        /// <exception cref="ArgumentException">Thrown when the grid is not compatible with this SDF grid.</exception>
        public void BindToVoxelGrid(VoxelGrid grid)
        {
            if (grid == null) throw new ArgumentNullException(nameof(grid));
            EnsureCompatible(grid);
            if (_subscribedVoxelGrid != null)
                UnbindFromVoxelGrid();

            _sourceVoxelGrid = grid;
            _subscribedVoxelGrid = grid;
            grid.VoxelsChanged += OnVoxelGridChanged;
        }

        /// <summary>
        /// Checks that a voxel grid describes the same field as this SDF grid.
        /// </summary>
        private void EnsureCompatible(VoxelGrid grid)
        {
            const float tolerance = 1e-4f;

            var (sx, sy, sz) = grid.Dimensions;
            bool compatible =
                sx == _sizeX && sy == _sizeY && sz == _sizeZ &&
                MathF.Abs(grid.Resolution - _resolution) <= tolerance &&
                (grid.Bounds.Min - _bounds.Min).Length() <= tolerance &&
                (grid.Bounds.Max - _bounds.Max).Length() <= tolerance;

            if (!compatible)
            {
                throw new ArgumentException(
                    "The voxel grid must have the same dimensions, resolution and bounds as the SDF grid.",
                    nameof(grid));
            }
        }

        /// <summary>
        /// Unbinds from the source VoxelGrid: future voxel changes no longer update this SDF and
        /// direct SDF edits are preserved. The source grid is remembered, so
        /// <see cref="SyncFromVoxelGrid"/> can still rebuild the field from it later. Rebinding does
        /// not resynchronize existing values either.
        /// </summary>
        public void UnbindFromVoxelGrid()
        {
            if (_subscribedVoxelGrid == null) return;
            _subscribedVoxelGrid.VoxelsChanged -= OnVoxelGridChanged;
            _subscribedVoxelGrid = null;
        }

        /// <summary>
        /// Rebuilds the whole field from the source voxel grid (the grid passed to
        /// <see cref="FromVoxelGrid"/> or <see cref="BindToVoxelGrid"/>, kept after
        /// <see cref="UnbindFromVoxelGrid"/>).
        /// <para>
        /// Use this after edits made while unbound, or to discard direct SDF carving, so that every
        /// sample is derived from the current voxel state. Incremental binding only synchronizes
        /// future changes.
        /// </para>
        /// </summary>
        /// <exception cref="InvalidOperationException">Thrown when this SDF grid has no source
        /// voxel grid (created with the native constructor and never bound).</exception>
        public void SyncFromVoxelGrid()
        {
            var voxelGrid = _sourceVoxelGrid
                ?? throw new InvalidOperationException(
                    "This SDF grid has no source voxel grid. Use SDFGrid.FromVoxelGrid or BindToVoxelGrid first.");

            EnsureCompatible(voxelGrid);
            RebuildRegion(voxelGrid, 0, 0, 0, _sizeX - 1, _sizeY - 1, _sizeZ - 1);
        }

        private void OnVoxelGridChanged(int minX, int minY, int minZ, int maxX, int maxY, int maxZ)
        {
            if (_subscribedVoxelGrid == null) return;
            RebuildRegion(_subscribedVoxelGrid, minX, minY, minZ, maxX, maxY, maxZ);
        }

        /// <summary>
        /// Recomputes the SDF in the region affected by voxel changes.
        /// The write region is expanded by the narrow band, because distances up to one narrow
        /// band away from the changed voxels can change as well.
        /// </summary>
        /// <param name="voxelGrid">Source voxel grid.</param>
        /// <param name="minX">Minimum changed voxel index X.</param>
        /// <param name="minY">Minimum changed voxel index Y.</param>
        /// <param name="minZ">Minimum changed voxel index Z.</param>
        /// <param name="maxX">Maximum changed voxel index X.</param>
        /// <param name="maxY">Maximum changed voxel index Y.</param>
        /// <param name="maxZ">Maximum changed voxel index Z.</param>
        public void UpdateRegionFromVoxelGrid(VoxelGrid voxelGrid, int minX, int minY, int minZ, int maxX, int maxY, int maxZ)
        {
            if (voxelGrid == null) throw new ArgumentNullException(nameof(voxelGrid));
            EnsureCompatible(voxelGrid);
            RebuildRegion(voxelGrid, minX, minY, minZ, maxX, maxY, maxZ);
        }

        private void RebuildRegion(VoxelGrid voxelGrid, int minX, int minY, int minZ, int maxX, int maxY, int maxZ)
        {
            int band = Math.Max(1, (int)Math.Ceiling(_narrowBandWidth / _resolution));

            minX = Math.Max(0, minX - band);
            minY = Math.Max(0, minY - band);
            minZ = Math.Max(0, minZ - band);
            maxX = Math.Min(_sizeX - 1, maxX + band);
            maxY = Math.Min(_sizeY - 1, maxY + band);
            maxZ = Math.Min(_sizeZ - 1, maxZ + band);
            if (minX > maxX || minY > maxY || minZ > maxZ) return;

            lock (_sync)
            {
                SignedDistanceFieldBuilder.ComputeRegion(
                    (x, y, z) => voxelGrid.GetVoxel(x, y, z),
                    _sizeX, _sizeY, _sizeZ,
                    _resolution, _narrowBandWidth,
                    _distances,
                    minX, minY, minZ,
                    maxX, maxY, maxZ);
            }
        }

        /// <summary>
        /// Checks whether an index is outside the SDF grid.
        /// </summary>
        private bool IsOutOfBoundsIndex(int x, int y, int z)
        {
            return x < 0 || x >= _sizeX || y < 0 || y >= _sizeY || z < 0 || z >= _sizeZ;
        }

        /// <summary>
        /// Computes the distance from a voxel center to the closest point inside the bounding box.
        /// The result is clamped to the narrow band width and is always positive (outside = empty).
        /// </summary>
        private float DistanceFromVoxelCenterToBounds(int x, int y, int z)
        {
            Vector3 center = VoxelToWorld(x, y, z);
            return DistanceFromPointToBounds(center);
        }

        /// <summary>
        /// Computes the positive distance from a world point to the closest point inside the bounds.
        /// Points inside the bounds return zero.
        /// </summary>
        private float DistanceFromPointToBounds(Vector3 point)
        {
            float dx = 0, dy = 0, dz = 0;
            if (point.X < _bounds.Min.X) dx = _bounds.Min.X - point.X;
            else if (point.X > _bounds.Max.X) dx = point.X - _bounds.Max.X;
            if (point.Y < _bounds.Min.Y) dy = _bounds.Min.Y - point.Y;
            else if (point.Y > _bounds.Max.Y) dy = point.Y - _bounds.Max.Y;
            if (point.Z < _bounds.Min.Z) dz = _bounds.Min.Z - point.Z;
            else if (point.Z > _bounds.Max.Z) dz = point.Z - _bounds.Max.Z;
            float dist = MathF.Sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > _narrowBandWidth) dist = _narrowBandWidth;
            return dist;
        }

        /// <summary>
        /// Gets the signed distance at the specified voxel indices.
        /// </summary>
        /// <param name="x">X index</param>
        /// <param name="y">Y index</param>
        /// <param name="z">Z index</param>
        /// <returns>Signed distance in millimeters. Negative = material, positive = empty.</returns>
        public float GetDistance(int x, int y, int z)
        {
            if (IsOutOfBoundsIndex(x, y, z))
            {
                // Outside the grid is empty space (positive distance).
                return DistanceFromVoxelCenterToBounds(x, y, z);
            }

            return _distances[x, y, z];
        }

        /// <summary>
        /// Converts world coordinates to voxel indices (floor semantics).
        /// </summary>
        private (int x, int y, int z) WorldToVoxel(Vector3 worldPos)
        {
            Vector3 localPos = worldPos - _bounds.Min;
            return (
                (int)MathF.Floor(localPos.X / _resolution),
                (int)MathF.Floor(localPos.Y / _resolution),
                (int)MathF.Floor(localPos.Z / _resolution)
            );
        }

        /// <summary>
        /// Converts voxel indices to world coordinates (center of voxel).
        /// </summary>
        private Vector3 VoxelToWorld(int x, int y, int z)
        {
            return _bounds.Min + new Vector3(
                (x + 0.5f) * _resolution,
                (y + 0.5f) * _resolution,
                (z + 0.5f) * _resolution
            );
        }

        /// <summary>
        /// Gets the signed distance at a world position using trilinear interpolation.
        /// Voxel samples are treated as living at voxel centers (half-voxel offset).
        /// Points on or outside the grid bounds are treated as air (positive distance), which keeps
        /// the outer shell of an SDF-native grid closed and consistent with voxel-derived grids.
        /// </summary>
        /// <param name="worldPos">World position</param>
        /// <returns>Interpolated signed distance value in millimeters</returns>
        public float GetDistance(Vector3 worldPos)
        {
            const float boundaryEpsilon = 1e-6f;
            if (worldPos.X <= _bounds.Min.X + boundaryEpsilon || worldPos.X >= _bounds.Max.X - boundaryEpsilon ||
                worldPos.Y <= _bounds.Min.Y + boundaryEpsilon || worldPos.Y >= _bounds.Max.Y - boundaryEpsilon ||
                worldPos.Z <= _bounds.Min.Z + boundaryEpsilon || worldPos.Z >= _bounds.Max.Z - boundaryEpsilon)
            {
                return DistanceFromPointToBounds(worldPos);
            }

            // Convert to sample space (voxel centers live at integer + 0.5 in world/res units).
            float fx = (worldPos.X - _bounds.Min.X) / _resolution - 0.5f;
            float fy = (worldPos.Y - _bounds.Min.Y) / _resolution - 0.5f;
            float fz = (worldPos.Z - _bounds.Min.Z) / _resolution - 0.5f;

            int x0 = (int)MathF.Floor(fx);
            int y0 = (int)MathF.Floor(fy);
            int z0 = (int)MathF.Floor(fz);
            int x1 = x0 + 1;
            int y1 = y0 + 1;
            int z1 = z0 + 1;

            float tx = fx - x0;
            float ty = fy - y0;
            float tz = fz - z0;

            // Trilinear interpolation
            float c000 = GetDistance(x0, y0, z0);
            float c001 = GetDistance(x0, y0, z1);
            float c010 = GetDistance(x0, y1, z0);
            float c011 = GetDistance(x0, y1, z1);
            float c100 = GetDistance(x1, y0, z0);
            float c101 = GetDistance(x1, y0, z1);
            float c110 = GetDistance(x1, y1, z0);
            float c111 = GetDistance(x1, y1, z1);

            float c00 = c000 * (1 - tx) + c100 * tx;
            float c01 = c001 * (1 - tx) + c101 * tx;
            float c10 = c010 * (1 - tx) + c110 * tx;
            float c11 = c011 * (1 - tx) + c111 * tx;

            float c0 = c00 * (1 - ty) + c10 * ty;
            float c1 = c01 * (1 - ty) + c11 * ty;

            return c0 * (1 - tz) + c1 * tz;
        }

        /// <summary>
        /// Computes the gradient (approximate surface normal) at a world position using central differences.
        /// The gradient points from material toward empty space (outward from the solid).
        /// </summary>
        /// <param name="worldPos">World position</param>
        /// <returns>Normalized gradient vector (approximate surface normal)</returns>
        public Vector3 GetGradient(Vector3 worldPos)
        {
            float h = _resolution; // Step size for finite differences
            float dx = (GetDistance(worldPos + new Vector3(h, 0, 0)) -
                       GetDistance(worldPos - new Vector3(h, 0, 0))) / (2 * h);
            float dy = (GetDistance(worldPos + new Vector3(0, h, 0)) -
                       GetDistance(worldPos - new Vector3(0, h, 0))) / (2 * h);
            float dz = (GetDistance(worldPos + new Vector3(0, 0, h)) -
                       GetDistance(worldPos - new Vector3(0, 0, h))) / (2 * h);

            Vector3 gradient = new Vector3(dx, dy, dz);
            float length = gradient.Length();

            if (length > 1e-6f)
            {
                return Vector3.Normalize(gradient);
            }

            return Vector3.UnitY; // Default normal if gradient is zero
        }

        /// <summary>
        /// Counts the samples that contain material (signed distance below zero).
        /// The count is center-sampled and therefore resolution-limited.
        /// </summary>
        /// <returns>Material sample count.</returns>
        public int CountMaterialSamples()
        {
            int count = 0;
            for (int z = 0; z < _sizeZ; z++)
                for (int y = 0; y < _sizeY; y++)
                    for (int x = 0; x < _sizeX; x++)
                        if (_distances[x, y, z] < 0f) count++;

            return count;
        }

        /// <summary>
        /// Gets the material volume in cubic millimeters (material sample count times the sample
        /// volume). The value is center-sampled and therefore resolution-limited, matching
        /// <see cref="VoxelGrid.GetMaterialVolume"/>.
        /// </summary>
        /// <returns>Material volume in mm^3.</returns>
        public double GetMaterialVolume()
        {
            return CountMaterialSamples() * (double)_resolution * _resolution * _resolution;
        }

        /// <summary>
        /// Gets the air (non-material) volume inside the effective bounds in cubic millimeters.
        /// The value is center-sampled and therefore resolution-limited, matching
        /// <see cref="VoxelGrid.GetRemovedVolume"/>.
        /// </summary>
        /// <returns>Removed volume in mm^3.</returns>
        public double GetRemovedVolume()
        {
            long total = (long)_sizeX * _sizeY * _sizeZ;
            return (total - CountMaterialSamples()) * (double)_resolution * _resolution * _resolution;
        }

        private void ClampRegion(ref int minX, ref int minY, ref int minZ, ref int maxX, ref int maxY, ref int maxZ)
        {
            minX = Math.Max(0, minX);
            minY = Math.Max(0, minY);
            minZ = Math.Max(0, minZ);
            maxX = Math.Min(_sizeX - 1, maxX);
            maxY = Math.Min(_sizeY - 1, maxY);
            maxZ = Math.Min(_sizeZ - 1, maxZ);
        }

        private void Carve(int x, int y, int z, float amount)
        {
            float clamped = amount;
            if (clamped > _narrowBandWidth) clamped = _narrowBandWidth;
            if (clamped > _distances[x, y, z]) _distances[x, y, z] = clamped;
        }

        /// <summary>
        /// Checks whether any material sample inside <paramref name="worldBounds"/> also lies inside
        /// the tool solid described by <paramref name="toolSignedDistance"/> (negative = inside).
        /// Read-only: does not modify the SDF.
        /// </summary>
        internal bool IntersectsToolSolid(BoundingBox worldBounds, Func<Vector3, float> toolSignedDistance)
        {
            if (worldBounds == null) throw new ArgumentNullException(nameof(worldBounds));
            if (toolSignedDistance == null) throw new ArgumentNullException(nameof(toolSignedDistance));

            var (minX, minY, minZ) = WorldToVoxel(worldBounds.Min);
            var (maxX, maxY, maxZ) = WorldToVoxel(worldBounds.Max);
            ClampRegion(ref minX, ref minY, ref minZ, ref maxX, ref maxY, ref maxZ);
            if (minX > maxX || minY > maxY || minZ > maxZ) return false;

            for (int z = minZ; z <= maxZ; z++)
                for (int y = minY; y <= maxY; y++)
                    for (int x = minX; x <= maxX; x++)
                    {
                        if (_distances[x, y, z] >= 0f) continue;
                        if (toolSignedDistance(VoxelToWorld(x, y, z)) < 0f) return true;
                    }

            return false;
        }

        /// <summary>
        /// Repairs the air-side distances in the region using an exact distance transform of the
        /// current sign pattern. CSG updates (max) are exact on the material side but can leave
        /// inflated values where removed volumes overlap (for example at crossing cuts), which
        /// would displace the reconstructed surface. Material-side values are preserved.
        /// </summary>
        private void RepairDistances(int minX, int minY, int minZ, int maxX, int maxY, int maxZ)
        {
            minX = Math.Max(0, minX);
            minY = Math.Max(0, minY);
            minZ = Math.Max(0, minZ);
            maxX = Math.Min(_sizeX - 1, maxX);
            maxY = Math.Min(_sizeY - 1, maxY);
            maxZ = Math.Min(_sizeZ - 1, maxZ);
            if (minX > maxX || minY > maxY || minZ > maxZ) return;

            // Only cells inside the narrow band can change; clamped cells are already final.
            // Restricting the repair to the band keeps the cost proportional to the tool surface
            // instead of the whole tool bounding box (important for long tools / shanks).
            int bandCells = Math.Max(1, (int)Math.Ceiling(_narrowBandWidth / _resolution)) + 2;
            int rMinX = int.MaxValue, rMinY = int.MaxValue, rMinZ = int.MaxValue;
            int rMaxX = int.MinValue, rMaxY = int.MinValue, rMaxZ = int.MinValue;

            for (int z = minZ; z <= maxZ; z++)
                for (int y = minY; y <= maxY; y++)
                    for (int x = minX; x <= maxX; x++)
                    {
                        if (MathF.Abs(_distances[x, y, z]) >= _narrowBandWidth) continue;
                        if (x < rMinX) rMinX = x;
                        if (y < rMinY) rMinY = y;
                        if (z < rMinZ) rMinZ = z;
                        if (x > rMaxX) rMaxX = x;
                        if (y > rMaxY) rMaxY = y;
                        if (z > rMaxZ) rMaxZ = z;
                    }

            if (rMinX > rMaxX) return; // nothing inside the band

            minX = Math.Max(minX, rMinX - bandCells);
            minY = Math.Max(minY, rMinY - bandCells);
            minZ = Math.Max(minZ, rMinZ - bandCells);
            maxX = Math.Min(maxX, rMaxX + bandCells);
            maxY = Math.Min(maxY, rMaxY + bandCells);
            maxZ = Math.Min(maxZ, rMaxZ + bandCells);

            SignedDistanceFieldBuilder.GetWindowBounds(
                _sizeX, _sizeY, _sizeZ, _resolution, _narrowBandWidth,
                minX, minY, minZ, maxX, maxY, maxZ,
                out int padMinX, out int padMinY, out int padMinZ, out int nx, out int ny, out int nz);

            var occupancy = new bool[nx, ny, nz];
            for (int wz = 0; wz < nz; wz++)
            {
                int gz = padMinZ + wz;
                for (int wy = 0; wy < ny; wy++)
                {
                    int gy = padMinY + wy;
                    for (int wx = 0; wx < nx; wx++)
                    {
                        int gx = padMinX + wx;
                        bool inside = gx >= 0 && gx < _sizeX && gy >= 0 && gy < _sizeY && gz >= 0 && gz < _sizeZ;
                        occupancy[wx, wy, wz] = inside && _distances[gx, gy, gz] < 0f;
                    }
                }
            }

            int cellCount = (maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1);
            var savedValues = new float[cellCount];
            var savedMaterial = new bool[cellCount];

            int index = 0;
            for (int z = minZ; z <= maxZ; z++)
                for (int y = minY; y <= maxY; y++)
                    for (int x = minX; x <= maxX; x++)
                    {
                        float value = _distances[x, y, z];
                        savedValues[index] = value;
                        savedMaterial[index] = value < 0f;
                        index++;
                    }

            SignedDistanceFieldBuilder.ComputeRegion(
                occupancy, padMinX, padMinY, padMinZ, _resolution, _narrowBandWidth, _distances,
                minX, minY, minZ, maxX, maxY, maxZ);

            // Keep exact material-side values and air values that were not inflated.
            float threshold = 0.5f * _resolution;
            index = 0;
            for (int z = minZ; z <= maxZ; z++)
                for (int y = minY; y <= maxY; y++)
                    for (int x = minX; x <= maxX; x++)
                    {
                        float original = savedValues[index];
                        bool material = savedMaterial[index];
                        float built = _distances[x, y, z];
                        index++;

                        if (material || original - built <= threshold)
                        {
                            _distances[x, y, z] = original;
                        }
                    }
        }

        /// <summary>
        /// Applies a CSG difference for the tool solid described by <paramref name="toolSignedDistance"/>
        /// (negative inside the tool) over the given world bounds.
        /// </summary>
        internal void CarveRegion(BoundingBox worldBounds, Func<Vector3, float> toolSignedDistance)
        {
            if (worldBounds == null) throw new ArgumentNullException(nameof(worldBounds));
            if (toolSignedDistance == null) throw new ArgumentNullException(nameof(toolSignedDistance));

            // Expand by the narrow band: material samples within the band around the tool must also
            // receive exact distances. Otherwise their values stay at the initial -narrowBand and
            // the zero crossing between the tool and the untouched material is shifted.
            var band = new Vector3(_narrowBandWidth, _narrowBandWidth, _narrowBandWidth);
            var (minX, minY, minZ) = WorldToVoxel(worldBounds.Min - band);
            var (maxX, maxY, maxZ) = WorldToVoxel(worldBounds.Max + band);
            ClampRegion(ref minX, ref minY, ref minZ, ref maxX, ref maxY, ref maxZ);
            if (minX > maxX || minY > maxY || minZ > maxZ) return;

            // Each cell is written independently, so the tool evaluation is parallelized.
            Parallel.For(minZ, maxZ + 1, z =>
            {
                for (int y = minY; y <= maxY; y++)
                {
                    for (int x = minX; x <= maxX; x++)
                    {
                        float distance = toolSignedDistance(VoxelToWorld(x, y, z));
                        Carve(x, y, z, -distance);
                    }
                }
            });

            RepairDistances(minX, minY, minZ, maxX, maxY, maxZ);
        }

        /// <summary>
        /// Removes material in a spherical region using the CSG difference operation
        /// <c>d = max(d, radius - |p - center|)</c>.
        /// </summary>
        /// <param name="center">Center of the sphere in world coordinates.</param>
        /// <param name="radius">Radius of the sphere in millimeters.</param>
        public void RemoveSphere(Vector3 center, float radius)
        {
            if (radius <= 0) return;

            // Expand by the narrow band so the material side receives exact distances as well.
            float reach = radius + _narrowBandWidth;
            var (minX, minY, minZ) = WorldToVoxel(center - new Vector3(reach, reach, reach));
            var (maxX, maxY, maxZ) = WorldToVoxel(center + new Vector3(reach, reach, reach));
            ClampRegion(ref minX, ref minY, ref minZ, ref maxX, ref maxY, ref maxZ);
            if (minX > maxX || minY > maxY || minZ > maxZ) return;

            for (int z = minZ; z <= maxZ; z++)
                for (int y = minY; y <= maxY; y++)
                    for (int x = minX; x <= maxX; x++)
                    {
                        float distToCenter = Vector3.Distance(VoxelToWorld(x, y, z), center);
                        Carve(x, y, z, radius - distToCenter);
                    }

            RepairDistances(minX, minY, minZ, maxX, maxY, maxZ);
        }

        /// <summary>
        /// Removes material in a capsule region (line segment with spherical ends) using the CSG
        /// difference operation <c>d = max(d, radius - distanceToSegment)</c>.
        /// </summary>
        /// <param name="start">Start point of the capsule axis in world coordinates.</param>
        /// <param name="end">End point of the capsule axis in world coordinates.</param>
        /// <param name="radius">Radius of the capsule in millimeters.</param>
        public void RemoveCapsule(Vector3 start, Vector3 end, float radius)
        {
            if (radius <= 0) return;

            Vector3 axis = end - start;
            float length = axis.Length();
            if (length < 1e-6f)
            {
                RemoveSphere(start, radius);
                return;
            }
            Vector3 axisDir = axis / length;

            // Expand by the narrow band so the material side receives exact distances as well.
            float reach = radius + _narrowBandWidth;
            Vector3 regionMin = Vector3.Min(start, end) - new Vector3(reach);
            Vector3 regionMax = Vector3.Max(start, end) + new Vector3(reach);
            var (minX, minY, minZ) = WorldToVoxel(regionMin);
            var (maxX, maxY, maxZ) = WorldToVoxel(regionMax);
            ClampRegion(ref minX, ref minY, ref minZ, ref maxX, ref maxY, ref maxZ);
            if (minX > maxX || minY > maxY || minZ > maxZ) return;

            for (int z = minZ; z <= maxZ; z++)
                for (int y = minY; y <= maxY; y++)
                    for (int x = minX; x <= maxX; x++)
                    {
                        Vector3 toVoxel = VoxelToWorld(x, y, z) - start;
                        float projection = Math.Clamp(Vector3.Dot(toVoxel, axisDir), 0f, length);
                        float distToSegment = (toVoxel - axisDir * projection).Length();
                        Carve(x, y, z, radius - distToSegment);
                    }

            RepairDistances(minX, minY, minZ, maxX, maxY, maxZ);
        }

        /// <summary>
        /// Removes material in a finite flat-ended cylinder using the CSG difference operation.
        /// Unlike <see cref="RemoveCapsule"/>, the end faces are flat.
        /// </summary>
        /// <param name="start">Center of one end face in world coordinates.</param>
        /// <param name="end">Center of the other end face in world coordinates.</param>
        /// <param name="radius">Radius of the cylinder in millimeters.</param>
        public void RemoveFiniteCylinder(Vector3 start, Vector3 end, float radius)
        {
            if (radius <= 0) return;

            Vector3 axis = end - start;
            float length = axis.Length();
            if (length < 1e-6f) return; // Degenerate cylinder has no volume
            Vector3 axisDir = axis / length;
            Vector3 center = (start + end) * 0.5f;
            float halfLength = length * 0.5f;

            // Expand by the narrow band so the material side receives exact distances as well.
            float reach = radius + _narrowBandWidth;
            Vector3 regionMin = Vector3.Min(start, end) - new Vector3(reach);
            Vector3 regionMax = Vector3.Max(start, end) + new Vector3(reach);
            var (minX, minY, minZ) = WorldToVoxel(regionMin);
            var (maxX, maxY, maxZ) = WorldToVoxel(regionMax);
            ClampRegion(ref minX, ref minY, ref minZ, ref maxX, ref maxY, ref maxZ);
            if (minX > maxX || minY > maxY || minZ > maxZ) return;

            for (int z = minZ; z <= maxZ; z++)
                for (int y = minY; y <= maxY; y++)
                    for (int x = minX; x <= maxX; x++)
                    {
                        Vector3 toVoxel = VoxelToWorld(x, y, z) - center;
                        float axial = Vector3.Dot(toVoxel, axisDir);
                        float radial = (toVoxel - axisDir * axial).Length();

                        // Exact capped-cylinder distance (the max() of the two half-space distances
                        // underestimates the distance outside the end-face corners).
                        float radialDistance = radial - radius;
                        float axialDistance = MathF.Abs(axial) - halfLength;
                        float outside = MathF.Sqrt(
                            MathF.Max(radialDistance, 0f) * MathF.Max(radialDistance, 0f) +
                            MathF.Max(axialDistance, 0f) * MathF.Max(axialDistance, 0f));
                        float toolDistance = MathF.Min(MathF.Max(radialDistance, axialDistance), 0f) + outside;

                        Carve(x, y, z, -toolDistance);
                    }

            RepairDistances(minX, minY, minZ, maxX, maxY, maxZ);
        }
    }
}
