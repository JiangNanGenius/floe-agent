using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.Desktop;
using OpenTK.Windowing.GraphicsLibraryFramework;
using MillSimSharp.Geometry;
using MillSimSharp.Viewer.Rendering;
using MillSimSharp.Simulation;
using MillSimSharp.Toolpath;
using System.Diagnostics;
using System.IO;
using SysVector3 = System.Numerics.Vector3;

namespace MillSimSharp.Viewer
{
    public class VoxelViewerWindow : GameWindow
    {
        private AxisRenderer? _axisRenderer;
        private Camera? _camera;
        private Shader? _lineShader;
        private MeshRenderer? _meshRenderer;
        private readonly object _meshLock = new object();
        // Async mesh generation fields
        private MillSimSharp.Geometry.Mesh? _pendingMesh;
        private int _pendingMeshGeneration = -1;
        private bool _meshUpdatePending = false;
        // Serializes mesh generation: queues a follow-up request while a build runs and rejects
        // results from stale generations (see MeshGenerationScheduler).
        private readonly MeshGenerationScheduler _meshScheduler = new MeshGenerationScheduler();
        // Key state helper for toggles
        private bool _rKeyPrev = false;
        private bool _cKeyPrev = false;
        private bool _eKeyPrev = false;
        private MillSimSharp.Geometry.Mesh? _currentMesh;
        private Shader? _meshShader;
        private SDFGrid? _sdfGrid;
        private ToolpathRenderer? _toolpathRenderer;
        private List<IToolpathCommand>? _pendingToolpathCommands;
        private SysVector3 _pendingToolpathStartPos;

        // Step-by-step execution fields
        private bool _stepByStepMode = false;
        private ToolpathExecutor? _stepExecutor;
        private SDFGrid? _stepSdfGrid;
        private bool _tKeyPrev = false;
        private bool _spaceKeyPrev = false;
        private bool _homeKeyPrev = false;
        private bool _pageUpKeyPrev = false;
        private bool _pageDownKeyPrev = false;
        private int[] _stepSizeOptions = new int[] { 1, 5, 10, 50, 100, 1000 };

        private Vector2 _lastMousePos;
        private bool _isMouseDragging;
        private bool _isMousePanning;

        // End mill display model
        private MeshRenderer? _toolRenderer;
        private Tool? _displayTool;
        private SysVector3 _displayToolPosition;
        private ToolOrientation _displayToolOrientation = ToolOrientation.Default;
        private bool _showToolModel = true;
        private bool _mKeyPrev = false;

        // Processing state tracking
        private string _processingStatus = "";
        private volatile bool _meshGenerationInProgress = false;

        public VoxelViewerWindow(GameWindowSettings gameWindowSettings, NativeWindowSettings nativeWindowSettings)
            : base(gameWindowSettings, nativeWindowSettings)
        {
        }

        protected override void OnLoad()
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();

            base.OnLoad();

            // Set clear color
            GL.ClearColor(0.1f, 0.1f, 0.15f, 1.0f);

            // Enable depth testing
            GL.Enable(EnableCap.DepthTest);

            // Enable backface culling
            GL.Enable(EnableCap.CullFace);
            GL.CullFace(TriangleFace.Back);
            GL.FrontFace(FrontFaceDirection.Ccw);  // Standard SDF: CCW winding faces outward from material

            // Load shaders
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            _lineShader = new Shader(
                Path.Combine(baseDir, "Shaders/line.vert"),
                Path.Combine(baseDir, "Shaders/line.frag")
            );

            _meshShader = new Shader(
                Path.Combine(baseDir, "Shaders/mesh.vert"),
                Path.Combine(baseDir, "Shaders/mesh.frag")
            );

            // Initialize camera
            _camera = new Camera
            {
                Target = new OpenTK.Mathematics.Vector3(0, 0, 0),
                Distance = 200.0f,
                Yaw = 45.0f,
                Pitch = 30.0f
            };

            // First try to load gcodes/test.nc, then test2.nc; otherwise fall back to demo scene
            string gcodeFile = Path.Combine(baseDir, "gcodes", "test.nc");
            if (!File.Exists(gcodeFile))
                gcodeFile = Path.Combine(baseDir, "gcodes", "test2.nc");

            if (File.Exists(gcodeFile))
            {
                // Create a work area that covers reasonable size for the demo G-code
                // G-code uses Z=100 for cutting, so place workpiece below that
                var bbox = BoundingBox.FromCenterAndSize(
                    new SysVector3(0, 0, 0),  // Stock centered at the origin (Z spans -50..50)
                    new SysVector3(200, 200, 100)
                );
                var gridStopwatch = new Stopwatch();
                gridStopwatch.Start();
                _sdfGrid = new SDFGrid(bbox, resolution: 1.0f, narrowBandWidth: 2);
                gridStopwatch.Stop();
                Console.WriteLine($"SDF grid creation time: {gridStopwatch.ElapsedMilliseconds} ms");
                Console.WriteLine($"Workpiece bounds: Min=({bbox.Min.X}, {bbox.Min.Y}, {bbox.Min.Z}), Max=({bbox.Max.X}, {bbox.Max.Y}, {bbox.Max.Z})");

                // Fill keeps material; implement removal via executing toolpath
                var startPos = new System.Numerics.Vector3(0, 0, 150);  // Start above workpiece
                List<MillSimSharp.Toolpath.IToolpathCommand>? commands = null;
                var parseStopwatch = new Stopwatch();
                parseStopwatch.Start();
                try
                {
                    commands = GCodeParser.ParseFile(gcodeFile, startPos);
                    parseStopwatch.Stop();
                    Console.WriteLine($"Loaded G-code file: {gcodeFile}. Commands: {commands.Count}. Parse time: {parseStopwatch.ElapsedMilliseconds} ms");
                }
                catch (Exception ex)
                {
                    parseStopwatch.Stop();
                    Console.WriteLine($"Failed to parse G-code: {ex.Message}. Parse time: {parseStopwatch.ElapsedMilliseconds} ms");
                }

                // Execute all commands at once using SDF simulator
                var simulator = new SDFCutterSimulator(_sdfGrid);
                var tool = new EndMill(diameter: 10.0f, length: 50.0f, isBallEnd: true);
                Console.WriteLine($"Tool: Diameter={tool.Diameter}mm, Length={tool.Length}mm, Type={tool.Type}");

                // Remember the tool for the display model
                _displayTool = tool;
                _displayToolPosition = startPos;
                _displayToolOrientation = ToolOrientation.Default;

                var executor = new ToolpathExecutor(simulator, tool, startPos);
                var execStopwatch = new Stopwatch();
                execStopwatch.Start();

                if (commands != null)
                {
                    executor.ExecuteCommands(commands);
                }
                execStopwatch.Stop();

                Console.WriteLine($"Toolpath execution time: {execStopwatch.ElapsedMilliseconds} ms");

                // Store commands for step-by-step execution later
                if (commands != null)
                {
                    _pendingToolpathCommands = commands;
                    _pendingToolpathStartPos = startPos;
                }
            }
            else
            {
                // Create demo voxel scene
                CreateDemoScene();
            }

            // Initialize renderer
            _axisRenderer = new AxisRenderer();
            _toolpathRenderer = new ToolpathRenderer();
            _meshRenderer = new MeshRenderer();
            _toolRenderer = new MeshRenderer();

            // Update toolpath renderer if we have pending commands
            if (_toolpathRenderer != null && _pendingToolpathCommands != null)
            {
                _toolpathRenderer.UpdateFromCommands(_pendingToolpathCommands, _pendingToolpathStartPos);
                Console.WriteLine($"Toolpath segments loaded: {_pendingToolpathCommands.Count}");
            }

            UpdateToolModel();

            if (_sdfGrid != null)
            {
                // SDF grid is already initialized, just generate mesh
                StartMeshGenerationAsync();
            }

            Console.WriteLine($"Voxel Viewer initialized");
            Console.WriteLine($"Controls:");
            Console.WriteLine($"  - Mouse drag: Rotate camera");
            Console.WriteLine($"  - Middle drag: Pan camera");
            Console.WriteLine($"  - Mouse wheel: Zoom in/out");
            Console.WriteLine($"  - M: Toggle end mill model display");
            Console.WriteLine($"  - T: Toggle step-by-step execution mode");
            Console.WriteLine($"  - Space: Execute next step(s) (in step mode)");
            Console.WriteLine($"  - Home: Reset to beginning (in step mode)");
            Console.WriteLine($"  - PageUp/PageDown: Change step size (1, 5, 10, 50, 100, 1000)");
            Console.WriteLine($"  - R: Recompute mesh");
            Console.WriteLine($"  - C: Toggle backface culling");
            Console.WriteLine($"  - E: Export current mesh to STL");
            Console.WriteLine($"  - ESC: Exit");

            stopwatch.Stop();
            Console.WriteLine($"OnLoad took {stopwatch.ElapsedMilliseconds} ms");
        }

        private void CreateDemoScene()
        {
            // Create 100x100x100mm work area with 1mm resolution
            var bbox = BoundingBox.FromCenterAndSize(
                SysVector3.Zero,
                new SysVector3(100, 100, 100)
            );
            _sdfGrid = new SDFGrid(bbox, resolution: 1.0f, narrowBandWidth: 2);

            // Remove a sphere in the center
            _sdfGrid.RemoveSphere(SysVector3.Zero, radius: 50.0f);

            // Remove some cylinders for visual interest
            _sdfGrid.RemoveFiniteCylinder(
                new SysVector3(-40, 0, 50),
                new SysVector3(40, 0, 50),
                radius: 10.0f
            );

            _sdfGrid.RemoveFiniteCylinder(
                new SysVector3(50, -40, 0),
                new SysVector3(50, 40, 0),
                radius: 10.0f
            );

            _sdfGrid.RemoveFiniteCylinder(
                new SysVector3(0, 50, -40),
                new SysVector3(0, 50, 40),
                radius: 10.0f
            );
        }

        protected override void OnRenderFrame(FrameEventArgs args)
        {
            base.OnRenderFrame(args);

            // Clear buffers
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            if (_camera == null || _meshShader == null || _meshRenderer == null)
                return;

            // Set matrices
            Matrix4 view = _camera.GetViewMatrix();
            Matrix4 projection = Matrix4.CreatePerspectiveFieldOfView(
                MathHelper.DegreesToRadians(45.0f),
                (float)Size.X / Size.Y,
                0.1f,
                1000.0f
            );

            // Directional light (toward the light source: from above with a slight tilt)
            Vector3 lightDir = new Vector3(0.3f, 0.3f, 0.8f);
            lightDir.Normalize();

            _meshShader.Use();
            _meshShader.SetMatrix4("uView", view);
            _meshShader.SetMatrix4("uProjection", projection);
            _meshShader.SetVector3("uLightDir", lightDir);

            // Apply pending mesh update if available (do this on render thread)
            lock (_meshLock)
            {
                if (_meshUpdatePending && _pendingMesh != null)
                {
                    // Re-validate at apply time: a newer build may have started (or been queued)
                    // after this result was stored, in which case its mesh is shown instead and the
                    // pending one must not reach the screen.
                    if (_meshScheduler.TryApplyResult(_pendingMeshGeneration))
                    {
                        _meshRenderer.UpdateMesh(_pendingMesh);
                        // Keep a copy of the current active mesh for exports
                        _currentMesh = _pendingMesh;
                    }
                    else
                    {
                        Console.WriteLine("Discarding stale pending mesh (a newer generation is active or queued).");
                    }

                    _meshUpdatePending = false;
                    _pendingMesh = null;
                }
            }
            _meshRenderer.Render();

            // Render the end mill display model (never culled so it is visible from any angle)
            if (_showToolModel && _toolRenderer != null)
            {
                bool cullingEnabled = GL.IsEnabled(EnableCap.CullFace);
                if (cullingEnabled)
                {
                    GL.Disable(EnableCap.CullFace);
                }

                _toolRenderer.Render();

                if (cullingEnabled)
                {
                    GL.Enable(EnableCap.CullFace);
                }
            }

            // Render axes
            _axisRenderer?.Render(view, projection);

            // Render toolpath lines (overlay)
            if (_lineShader != null && _toolpathRenderer != null)
            {
                _lineShader.Use();
                _lineShader.SetMatrix4("uView", view);
                _lineShader.SetMatrix4("uProjection", projection);
                _toolpathRenderer.Render();
            }

            // Swap buffers
            SwapBuffers();

            // Update FPS and Memory in title
            UpdateTitle(args.Time);
        }

        private double _timeSinceLastUpdate = 0.0;
        private int _frameCount = 0;

        private void UpdateTitle(double time)
        {
            _frameCount++;
            _timeSinceLastUpdate += time;

            if (_timeSinceLastUpdate >= 1.0)
            {
                double fps = _frameCount / _timeSinceLastUpdate;
                long memory = GC.GetTotalMemory(false) / (1024 * 1024); // MB

                string statusSuffix = string.IsNullOrEmpty(_processingStatus) ? "" : $" - {_processingStatus}";
                int triangles = _currentMesh?.Indices.Length / 3 ?? 0;

                string meshInfo = triangles > 0 ? $" - Triangles: {triangles}" : "";

                // Add step execution info
                string stepInfo = "";
                if (_stepByStepMode && _stepExecutor != null)
                {
                    stepInfo = $" - Step: {_stepExecutor.CurrentCommandIndex + 1}/{_stepExecutor.TotalCommands} (Size: {_stepExecutor.StepSize})";
                }

                Title = $"MillSimSharp Voxel Viewer - FPS: {fps:0.0} - Mem: {memory} MB{meshInfo}{stepInfo}{statusSuffix}";

                _frameCount = 0;
                _timeSinceLastUpdate = 0.0;
            }
        }

        protected override void OnUpdateFrame(FrameEventArgs args)
        {
            base.OnUpdateFrame(args);

            // Handle ESC to close
            if (KeyboardState.IsKeyDown(Keys.Escape))
            {
                Close();
            }

            // R key -> recompute mesh
            bool rDown = KeyboardState.IsKeyDown(Keys.R);
            if (rDown && !_rKeyPrev)
            {
                Console.WriteLine("Recomputing mesh...");
                StartMeshGenerationAsync();
            }
            _rKeyPrev = rDown;

            // C key -> toggle backface culling (debug)
            bool cDown = KeyboardState.IsKeyDown(Keys.C);
            if (cDown && !_cKeyPrev)
            {
                // Toggle culling
                if (GL.IsEnabled(EnableCap.CullFace))
                {
                    GL.Disable(EnableCap.CullFace);
                    Console.WriteLine("Backface culling disabled (C)");
                }
                else
                {
                    GL.Enable(EnableCap.CullFace);
                    Console.WriteLine("Backface culling enabled (C)");
                }
            }
            _cKeyPrev = cDown;

            // M key -> toggle end mill model display
            bool mDown = KeyboardState.IsKeyDown(Keys.M);
            if (mDown && !_mKeyPrev)
            {
                _showToolModel = !_showToolModel;
                Console.WriteLine($"End mill model: {(_showToolModel ? "ON" : "OFF")}");
                UpdateToolModel();
            }
            _mKeyPrev = mDown;

            // E key -> export current mesh or voxel grid to STL
            bool eDown = KeyboardState.IsKeyDown(Keys.E);
            if (eDown && !_eKeyPrev)
            {
                // choose export target
                string baseDir = AppDomain.CurrentDomain.BaseDirectory;
                string outDir = Path.Combine(baseDir, "exports");
                try
                {
                    if (!Directory.Exists(outDir)) Directory.CreateDirectory(outDir);
                    string filename = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                    string filePath = Path.Combine(outDir, $"export_{filename}.stl");
                    if (_currentMesh != null)
                    {
                        // Run export in background so we don't block the render loop
                        System.Threading.Tasks.Task.Run(() =>
                        {
                            MillSimSharp.IO.StlExporter.Export(_currentMesh, filePath);
                            Console.WriteLine($"Exported current mesh to: {filePath}");
                        });
                    }
                    else if (_sdfGrid != null)
                    {
                        System.Threading.Tasks.Task.Run(() =>
                        {
                            var mesh = MeshConverter.ConvertToMeshFromSDF(_sdfGrid);
                            MillSimSharp.IO.StlExporter.Export(mesh, filePath);
                            Console.WriteLine($"Exported SDF mesh to: {filePath}");
                        });
                    }
                    else
                    {
                        Console.WriteLine("No mesh or SDF grid available to export.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Failed to export STL: {ex}");
                }
            }
            _eKeyPrev = eDown;

            // T key -> toggle step-by-step mode
            bool tDown = KeyboardState.IsKeyDown(Keys.T);
            if (tDown && !_tKeyPrev)
            {
                _stepByStepMode = !_stepByStepMode;
                Console.WriteLine($"Step-by-step mode: {(_stepByStepMode ? "ON" : "OFF")}");

                if (_stepByStepMode && _pendingToolpathCommands != null && _sdfGrid != null)
                {
                    // Initialize step execution
                    var bbox = _sdfGrid.Bounds;
                    _stepSdfGrid = new SDFGrid(bbox, _sdfGrid.Resolution, narrowBandWidth: 2);
                    var simulator = new SDFCutterSimulator(_stepSdfGrid);
                    var tool = new EndMill(diameter: 10.0f, length: 50.0f, isBallEnd: true);
                    _stepExecutor = new ToolpathExecutor(simulator, tool, _pendingToolpathStartPos);
                    _stepExecutor.LoadCommands(_pendingToolpathCommands);

                    Console.WriteLine($"Step executor initialized. Total commands: {_stepExecutor.TotalCommands}, Step size: {_stepExecutor.StepSize}");

                    // Show the initial (all material) step state instead of the previous full-path mesh.
                    StartMeshGenerationAsync();
                }
                else if (!_stepByStepMode)
                {
                    // Restore original grid
                    if (_sdfGrid != null)
                    {
                        StartMeshGenerationAsync();
                    }
                }

                UpdateToolModel();
            }
            _tKeyPrev = tDown;

            // Space key -> execute next step(s) in step-by-step mode
            bool spaceDown = KeyboardState.IsKeyDown(Keys.Space);
            if (spaceDown && !_spaceKeyPrev && _stepByStepMode && _stepExecutor != null)
            {
                int executed = _stepExecutor.ExecuteNextSteps();

                if (executed > 0)
                {
                    Console.WriteLine($"Executed {executed} step(s). Progress: {_stepExecutor.CurrentCommandIndex + 1}/{_stepExecutor.TotalCommands}");
                    // Trigger mesh update
                    StartMeshGenerationAsync();
                    UpdateToolModel();
                }
                else
                {
                    Console.WriteLine("All commands completed.");
                }
            }
            _spaceKeyPrev = spaceDown;

            // Home key -> reset to beginning
            bool homeDown = KeyboardState.IsKeyDown(Keys.Home);
            if (homeDown && !_homeKeyPrev && _stepByStepMode && _stepExecutor != null)
            {
                _stepExecutor.Reset();
                if (_stepSdfGrid != null)
                {
                    // Reset voxel grid
                    var bbox = _stepSdfGrid.Bounds;
                    _stepSdfGrid = new SDFGrid(bbox, _stepSdfGrid.Resolution, narrowBandWidth: 2);
                    var simulator = new SDFCutterSimulator(_stepSdfGrid);
                    var tool = new EndMill(diameter: 10.0f, length: 50.0f, isBallEnd: true);
                    _stepExecutor = new ToolpathExecutor(simulator, tool, _pendingToolpathStartPos);
                    _stepExecutor.LoadCommands(_pendingToolpathCommands!);

                    StartMeshGenerationAsync();
                }
                UpdateToolModel();
                Console.WriteLine("Reset to beginning.");
            }
            _homeKeyPrev = homeDown;

            // PageUp/PageDown -> change step size
            bool pageUpDown = KeyboardState.IsKeyDown(Keys.PageUp);
            bool pageDownDown = KeyboardState.IsKeyDown(Keys.PageDown);
            if ((pageUpDown && !_pageUpKeyPrev) || (pageDownDown && !_pageDownKeyPrev))
            {
                if (_stepExecutor != null)
                {
                    int currentIndex = Array.IndexOf(_stepSizeOptions, _stepExecutor.StepSize);
                    if (currentIndex < 0) currentIndex = 0;

                    if (pageUpDown)
                        currentIndex = (currentIndex + 1) % _stepSizeOptions.Length;
                    else
                        currentIndex = (currentIndex - 1 + _stepSizeOptions.Length) % _stepSizeOptions.Length;

                    _stepExecutor.StepSize = _stepSizeOptions[currentIndex];
                    Console.WriteLine($"Step size changed to: {_stepExecutor.StepSize}");
                }
            }
            _pageUpKeyPrev = pageUpDown;
            _pageDownKeyPrev = pageDownDown;
        }

        protected override void OnResize(ResizeEventArgs e)
        {
            base.OnResize(e);
            GL.Viewport(0, 0, e.Width, e.Height);
        }

        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            base.OnMouseDown(e);

            if (e.Button == MouseButton.Left)
            {
                _isMouseDragging = true;
                _lastMousePos = MousePosition;
            }
            else if (e.Button == MouseButton.Middle)
            {
                _isMousePanning = true;
                _lastMousePos = MousePosition;
            }
        }

        protected override void OnMouseUp(MouseButtonEventArgs e)
        {
            base.OnMouseUp(e);

            if (e.Button == MouseButton.Left)
            {
                _isMouseDragging = false;
            }
            else if (e.Button == MouseButton.Middle)
            {
                _isMousePanning = false;
            }
        }

        protected override void OnMouseMove(MouseMoveEventArgs e)
        {
            base.OnMouseMove(e);

            if (_camera == null)
            {
                return;
            }

            if (_isMouseDragging)
            {
                Vector2 delta = MousePosition - _lastMousePos;
                _camera.ProcessMouseMove(delta.X, delta.Y);
                _lastMousePos = MousePosition;
            }
            else if (_isMousePanning)
            {
                Vector2 delta = MousePosition - _lastMousePos;
                _camera.ProcessMousePan(delta.X, delta.Y);
                _lastMousePos = MousePosition;
            }
        }

        protected override void OnMouseWheel(MouseWheelEventArgs e)
        {
            base.OnMouseWheel(e);

            if (_camera != null)
            {
                _camera.ProcessMouseWheel(e.OffsetY);
            }
        }

        protected override void OnUnload()
        {
            base.OnUnload();

            _axisRenderer?.Dispose();
            _lineShader?.Dispose();
            _meshShader?.Dispose();
            _toolpathRenderer?.Dispose();
            _meshRenderer?.Dispose();
            _toolRenderer?.Dispose();
        }

        /// <summary>
        /// Rebuild the display-only end mill model at the current tool pose.
        /// In step mode the pose follows the executor; otherwise the tool sits at the toolpath start.
        /// </summary>
        private void UpdateToolModel()
        {
            if (_toolRenderer == null)
            {
                return;
            }

            if (!_showToolModel || _displayTool == null)
            {
                _toolRenderer.Clear();
                return;
            }

            SysVector3 position = _displayToolPosition;
            ToolOrientation orientation = _displayToolOrientation;

            if (_stepByStepMode && _stepExecutor != null)
            {
                position = _stepExecutor.CurrentPosition;
                orientation = _stepExecutor.CurrentOrientation;
            }

            _toolRenderer.UpdateMesh(ToolModelBuilder.BuildEndMill(_displayTool, position, orientation));
        }

        /// <summary>
        /// Start mesh generation on a background thread and apply it on the render thread once ready.
        /// If a generation is already running, a follow-up run is queued instead of dropping the
        /// request, and results of older generations are discarded, so the display always converges
        /// to the current state.
        /// </summary>
        private void StartMeshGenerationAsync()
        {
            if (_sdfGrid == null) return;

            int? requestedGeneration = _meshScheduler.TryBegin();
            if (requestedGeneration == null)
            {
                Console.WriteLine("Mesh generation already in progress; a follow-up run is queued.");
                return;
            }

            int generation = requestedGeneration.Value;

            // Use step grid if in step mode, otherwise use original grid
            var gridCopy = _stepByStepMode ? _stepSdfGrid : _sdfGrid;
            if (gridCopy == null)
            {
                Console.WriteLine("No SDF grid available for mesh generation.");
                if (_meshScheduler.Complete())
                {
                    StartMeshGenerationAsync();
                }
                return;
            }

            _meshGenerationInProgress = true;
            _processingStatus = "Generating mesh...";
            Console.WriteLine("Starting mesh generation...");

            var meshGenStopwatch = new Stopwatch();
            meshGenStopwatch.Start();

            // Progress reporting for mesh generation
            var meshProgressTask = System.Threading.Tasks.Task.Run(async () =>
            {
                while (_meshGenerationInProgress)
                {
                    await System.Threading.Tasks.Task.Delay(5000); // Every 5 seconds
                    if (_meshGenerationInProgress)
                    {
                        Console.WriteLine($"Mesh generation in progress... ({meshGenStopwatch.ElapsedMilliseconds / 1000}s elapsed)");
                    }
                }
            });

            var meshComputeTask = System.Threading.Tasks.Task.Run(() =>
            {
                // Generate mesh directly from SDF
                return MillSimSharp.Geometry.MeshConverter.ConvertToMeshFromSDF(gridCopy);
            });

            meshComputeTask.ContinueWith((t) =>
            {
                meshGenStopwatch.Stop();
                _meshGenerationInProgress = false;

                if (t.IsCompletedSuccessfully)
                {
                    var mesh = t.Result;

                    // Store the result with its generation; the render thread re-validates it
                    // (TryApplyResult) when it is actually drawn, so a result superseded by a newer
                    // request never reaches the screen.
                    lock (_meshLock)
                    {
                        _pendingMesh = mesh;
                        _pendingMeshGeneration = generation;
                        _meshUpdatePending = true;
                    }

                    _processingStatus = "";
                    Console.WriteLine($"Mesh generation finished: vertices={mesh.Vertices.Length}, triangles={mesh.Indices.Length / 3}, time={meshGenStopwatch.ElapsedMilliseconds} ms ({meshGenStopwatch.ElapsedMilliseconds / 1000.0:F1}s)");
                }
                else if (t.IsFaulted)
                {
                    if (_meshScheduler.IsCurrent(generation))
                    {
                        _processingStatus = "Mesh generation failed";
                        // Print full exception details to help diagnose failures
                        Console.WriteLine($"Mesh generation failed after {meshGenStopwatch.ElapsedMilliseconds} ms: {t.Exception?.ToString()}");
                    }
                }

                // Start the queued follow-up request now (the state / mode may have changed while
                // the previous generation was running).
                if (_meshScheduler.Complete())
                {
                    StartMeshGenerationAsync();
                }
            }, System.Threading.Tasks.TaskScheduler.Default);
        }
    }
}
