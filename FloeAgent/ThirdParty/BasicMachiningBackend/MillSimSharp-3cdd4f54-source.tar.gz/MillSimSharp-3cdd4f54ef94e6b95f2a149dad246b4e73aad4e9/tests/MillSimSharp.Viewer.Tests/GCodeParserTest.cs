using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using MillSimSharp.Toolpath;
using MillSimSharp.Viewer;
using NUnit.Framework;

namespace MillSimSharp.Tests.Viewer
{
    /// <summary>
    /// Tests for the core G-code parser.
    /// </summary>
    [TestFixture]
    public class GCodeParserTest
    {
        [Test]
        public void Parse_StraightMoves_AndFeed()
        {
            var commands = GCodeParser.ParseText("G0 Z10\nG0 X0 Y0\nG1 Z0 F300\nG1 X10 Y0\n", Vector3.Zero);

            Assert.That(commands.Count, Is.EqualTo(4));
            Assert.That(commands[0], Is.InstanceOf<G0Move>());
            Assert.That(((G0Move)commands[0]).Target, Is.EqualTo(new Vector3(0, 0, 10)));

            Assert.That(commands[3], Is.InstanceOf<G1Move>());
            Assert.That(((G1Move)commands[3]).Target, Is.EqualTo(new Vector3(10, 0, 0)));
            Assert.That(((G1Move)commands[3]).FeedRate, Is.EqualTo(300f).Within(1e-4f));
        }

        [Test]
        public void Parse_InchUnits_ConvertsToMillimeters()
        {
            var commands = GCodeParser.ParseText("G20\nG1 X1 Y0.5 F10\n", Vector3.Zero);

            var move = (G1Move)commands[commands.Count - 1];
            Assert.That(move.Target.X, Is.EqualTo(25.4f).Within(1e-3f));
            Assert.That(move.Target.Y, Is.EqualTo(12.7f).Within(1e-3f));
        }

        [Test]
        public void Parse_IncrementalMode_AccumulatesPosition()
        {
            var commands = GCodeParser.ParseText("G91\nG1 X1 Y2\nG1 X1 Z1\n", Vector3.Zero);

            Assert.That(((G1Move)commands[0]).Target, Is.EqualTo(new Vector3(1, 2, 0)));
            Assert.That(((G1Move)commands[1]).Target, Is.EqualTo(new Vector3(2, 2, 1)));
        }

        [Test]
        public void Parse_Arc_EmitsChords()
        {
            // CCW half circle from (0,0) to (10,0) with center (5,0)
            var commands = GCodeParser.ParseText("G1 X0 Y0 F100\nG3 X10 Y0 I5 J0\n", Vector3.Zero, arcSegmentAngleDegrees: 5f);

            Assert.That(commands.Count, Is.GreaterThan(10));

            var last = (G1Move)commands[commands.Count - 1];
            Assert.That(last.Target.X, Is.EqualTo(10f).Within(1e-3f));
            Assert.That(last.Target.Y, Is.EqualTo(0f).Within(1e-3f));

            bool foundMidpoint = commands.OfType<G1Move>().Any(
                m => Math.Abs(m.Target.X - 5f) < 0.5f && Math.Abs(m.Target.Y + 5f) < 0.5f);
            Assert.That(foundMidpoint, Is.True, "The arc must pass through (5,-5)");
        }

        [Test]
        public void Parse_CommentsAndBlankLines_AreIgnored()
        {
            var commands = GCodeParser.ParseText("; header\n\nG1 X5 (inline comment)\n", Vector3.Zero);

            Assert.That(commands.Count, Is.EqualTo(1));
            Assert.That(((G1Move)commands[0]).Target, Is.EqualTo(new Vector3(5, 0, 0)));
        }

        // ---------------------------------------------------------------------
        // I/J-format arcs: the commanded end must lie on the start-radius circle
        // (within the G-code rounding tolerance); the last chord snaps to the end
        // ---------------------------------------------------------------------

        [Test]
        public void Parse_Arc_IJ_MismatchedEndRadius_IsIgnored()
        {
            // Center (0,4): start radius 4, the commanded end (10,0) has radius ~10.8.
            var commands = GCodeParser.ParseText("G2 X10 Y0 I0 J4\n", Vector3.Zero);
            Assert.That(commands, Is.Empty, "A mismatched I/J arc must not emit moves");

            var relative = GCodeParser.ParseText("G91\nG2 X10 Y0 I0 J4\nG1 X1 Y0 F100\n", Vector3.Zero);
            Assert.That(relative.Count, Is.EqualTo(1));
            Assert.That(((G1Move)relative[0]).Target, Is.EqualTo(new Vector3(1, 0, 0)),
                "The ignored arc must leave the position unchanged");
        }

        [Test]
        public void Parse_Arc_IJ_SmallMismatchWithinTolerance_SnapsLastPointToEnd()
        {
            // Center (0,10): start radius 10, tolerance 0.01. The commanded end (7.0774, 2.9226)
            // has radius ~10.009 (consistent within tolerance) but is not exactly on the circle,
            // so the last chord must land on the commanded end point.
            var points = ParseArcTargets("G3 X7.0774 Y2.9226 I0 J10\n", Vector3.Zero, segmentAngleDegrees: 5f);

            Assert.That(points, Is.Not.Empty);
            Assert.That(points[^1], Is.EqualTo(new Vector3(7.0774f, 2.9226f, 0f)));
        }

        [Test]
        public void Parse_Arc_IJ_ConsistentRadius_LastPointEqualsEnd()
        {
            var points = ParseArcTargets("G3 X10 Y0 I5 J0\n", Vector3.Zero);

            Assert.That(points, Is.Not.Empty);
            Assert.That(points[^1], Is.EqualTo(new Vector3(10, 0, 0)));
        }

        [Test]
        public void Parse_Arc_IJ_EndPointAtCenter_IsIgnored()
        {
            // End == center (5,0): the end radius is 0, far outside the tolerance.
            var commands = GCodeParser.ParseText("G3 X5 Y0 I5 J0\n", Vector3.Zero);
            Assert.That(commands, Is.Empty, "An arc ending at the center must not emit moves");

            var relative = GCodeParser.ParseText("G91\nG3 X5 Y0 I5 J0\nG1 X1 Y0 F100\n", Vector3.Zero);
            Assert.That(relative.Count, Is.EqualTo(1));
            Assert.That(((G1Move)relative[0]).Target, Is.EqualTo(new Vector3(1, 0, 0)),
                "The ignored arc must leave the position unchanged");
        }

        [Test]
        public void Parse_Arc_IJ_ZeroRadius_IsIgnored()
        {
            // I=J=0: the start coincides with the center.
            var commands = GCodeParser.ParseText("G2 X10 Y0 I0 J0\n", Vector3.Zero);
            Assert.That(commands, Is.Empty, "A zero-radius arc must not emit moves");

            var relative = GCodeParser.ParseText("G91\nG2 X10 Y0 I0 J0\nG1 X1 Y0 F100\n", Vector3.Zero);
            Assert.That(relative.Count, Is.EqualTo(1));
            Assert.That(((G1Move)relative[0]).Target, Is.EqualTo(new Vector3(1, 0, 0)),
                "The ignored arc must leave the position unchanged");
        }

        [Test]
        public void Parse_Arc_IJ_HalfCircle()
        {
            var points = ParseArcTargets("G3 X10 Y0 I5 J0\n", Vector3.Zero, segmentAngleDegrees: 5f);

            Assert.That(points, Is.Not.Empty);
            Assert.That(points[^1], Is.EqualTo(new Vector3(10, 0, 0)));
            Assert.That(HasPointNear(points, 5f, -5f), Is.True,
                "The CCW half circle must pass through (5,-5)");
            Assert.That(HasPointNear(points, 5f, 5f), Is.False,
                "The CCW half circle must not take the (5,5) route");
        }

        [Test]
        public void Parse_Arc_IJ_LargeCoordinates_ConsistentRadius_IsAccepted()
        {
            // Review regression: a valid half circle far from the origin was ignored because the
            // radius check ran on float-converted endpoints (the rounding exceeded the tolerance).
            // Center (10000.01, 0), radius 0.01.
            var points = ParseArcTargets("G3 X10000.02 Y0 I0.01 J0\n",
                new Vector3(10000, 0, 0), segmentAngleDegrees: 5f);

            Assert.That(points, Is.Not.Empty, "a valid I/J arc far from the origin must not be ignored");
            Assert.That(points[^1].X, Is.EqualTo(10000.02f).Within(0.001f));
            Assert.That(points[^1].Y, Is.EqualTo(0f).Within(0.001f));
        }

        // ---------------------------------------------------------------------
        // Unsupported G codes: the whole block is ignored (no motion)
        // ---------------------------------------------------------------------

        [Test]
        public void Parse_UnsupportedGCodeBlock_DoesNotMove()
        {
            // Review regression: G28 on the same line was treated as a modal G1 cut to the origin.
            var commands = GCodeParser.ParseText("G1 X10\nG28 X0\n", Vector3.Zero);
            Assert.That(commands.Count, Is.EqualTo(1), "the G28 block must not emit a move");
            Assert.That(((G1Move)commands[0]).Target, Is.EqualTo(new Vector3(10, 0, 0)));

            // The ignored block must also leave the position unchanged for following moves.
            var relative = GCodeParser.ParseText("G1 X10\nG91\nG28 X0\nG1 X5\n", Vector3.Zero);
            Assert.That(relative.Count, Is.EqualTo(2));
            Assert.That(((G1Move)relative[1]).Target, Is.EqualTo(new Vector3(15, 0, 0)),
                "the ignored block must not move the position");

            // G18/G19 arc planes are unsupported: the block must not run as a G17 arc.
            var plane = GCodeParser.ParseText("G18 G3 X10 Y0 I5 J0\n", Vector3.Zero);
            Assert.That(plane, Is.Empty, "an unsupported arc plane must not emit chords");
        }

        [Test]
        public void Parse_ModalWordsInUnsupportedBlock_StillApply()
        {
            // Only the motion of an unsupported block is dropped; its modal words still apply.
            var commands = GCodeParser.ParseText("G28 G91\nG1 X5\n", Vector3.Zero);

            Assert.That(commands.Count, Is.EqualTo(1));
            Assert.That(((G1Move)commands[0]).Target, Is.EqualTo(new Vector3(5, 0, 0)),
                "the relative mode from the G28 block must still apply");
        }

        [Test]
        public void Parse_PlaneSelection_DoesNotSuppressTheMove()
        {
            // G17 is the supported XY plane: it must not turn its block into an unsupported one.
            var commands = GCodeParser.ParseText("G17 G1 X10\n", Vector3.Zero);

            Assert.That(commands.Count, Is.EqualTo(1));
            Assert.That(((G1Move)commands[0]).Target, Is.EqualTo(new Vector3(10, 0, 0)));
        }

        [Test]
        public void Parse_ArcPlaneSelection_PersistsAcrossBlocks()
        {
            // Review regression: G18 on its own line must disable XY arcs for following modal arcs.
            var commands = GCodeParser.ParseText("G18\nG2 X10 Z0 R5\n", Vector3.Zero);
            Assert.That(commands, Is.Empty, "arcs in the XZ plane are unsupported");

            // The ignored arc keeps the position for following moves.
            var relative = GCodeParser.ParseText("G18\nG2 X10 Z0 R5\nG91\nG1 X5\n", Vector3.Zero);
            Assert.That(relative.Count, Is.EqualTo(1));
            Assert.That(((G1Move)relative[0]).Target, Is.EqualTo(new Vector3(5, 0, 0)),
                "the ignored arc must not move the position");

            // Selecting G17 again re-enables XY arcs.
            var xy = GCodeParser.ParseText("G18\nG17\nG3 X10 Y0 I5 J0\n", Vector3.Zero, arcSegmentAngleDegrees: 5f);
            Assert.That(xy, Is.Not.Empty, "G17 must re-enable XY arcs");
        }

        [Test]
        public void Parse_FractionalGCode_IsNotRoundedToAnotherCommand()
        {
            // Review regression: G90.1 used to round to G90 (absolute mode) and G0.1 to G0 (rapid).
            var absoluteAttempt = GCodeParser.ParseText("G91\nG1 X10\nG90.1\nG1 X0\n", Vector3.Zero);
            Assert.That(absoluteAttempt.Count, Is.EqualTo(2));
            Assert.That(((G1Move)absoluteAttempt[1]).Target, Is.EqualTo(new Vector3(10, 0, 0)),
                "G90.1 must not switch to absolute mode");

            var rapidAttempt = GCodeParser.ParseText("G1 X10\nG0.1 X0\n", Vector3.Zero);
            Assert.That(rapidAttempt.Count, Is.EqualTo(1), "G0.1 must not emit a rapid move");
            Assert.That(((G1Move)rapidAttempt[0]).Target, Is.EqualTo(new Vector3(10, 0, 0)));
        }

        // ---------------------------------------------------------------------
        // R-format arcs: positive R = minor arc, negative R = major arc
        // ---------------------------------------------------------------------

        private static List<Vector3> ParseArcTargets(string gcode, Vector3 start, float segmentAngleDegrees = 1f)
        {
            return GCodeParser.ParseText(gcode, start, segmentAngleDegrees)
                .OfType<G1Move>()
                .Select(m => m.Target)
                .ToList();
        }

        private static bool HasPointNear(List<Vector3> points, float x, float y, float tolerance = 0.05f)
        {
            return points.Any(p => Math.Abs(p.X - x) <= tolerance && Math.Abs(p.Y - y) <= tolerance);
        }

        [Test]
        public void Parse_G3_PositiveR_MinorArc()
        {
            // CCW minor arc from (1,0) to (0,1) is centered at (0,0).
            var points = ParseArcTargets("G3 X0 Y1 R1\n", new Vector3(1, 0, 0));

            Assert.That(points, Is.Not.Empty);
            Assert.That(points[^1].X, Is.EqualTo(0f).Within(1e-3f));
            Assert.That(points[^1].Y, Is.EqualTo(1f).Within(1e-3f));
            Assert.That(HasPointNear(points, 0.7071f, 0.7071f), Is.True,
                "The minor arc must pass through (0.707, 0.707)");
            Assert.That(HasPointNear(points, 1.7071f, 1.7071f), Is.False,
                "The minor arc must not take the major route");
        }

        [Test]
        public void Parse_G2_PositiveR_MinorArc()
        {
            // CW minor arc from (0,1) to (1,0) is centered at (0,0).
            var points = ParseArcTargets("G2 X1 Y0 R1\n", new Vector3(0, 1, 0));

            Assert.That(points, Is.Not.Empty);
            Assert.That(points[^1].X, Is.EqualTo(1f).Within(1e-3f));
            Assert.That(points[^1].Y, Is.EqualTo(0f).Within(1e-3f));
            Assert.That(HasPointNear(points, 0.7071f, 0.7071f), Is.True,
                "The minor arc must pass through (0.707, 0.707)");
            Assert.That(HasPointNear(points, 1.7071f, 1.7071f), Is.False,
                "The minor arc must not take the major route");
        }

        [Test]
        public void Parse_G3_NegativeR_MajorArc()
        {
            // Negative R: CCW major arc from (1,0) to (0,1), centered at (1,1).
            var points = ParseArcTargets("G3 X0 Y1 R-1\n", new Vector3(1, 0, 0));

            Assert.That(points, Is.Not.Empty);
            Assert.That(points[^1].X, Is.EqualTo(0f).Within(1e-3f));
            Assert.That(points[^1].Y, Is.EqualTo(1f).Within(1e-3f));
            Assert.That(HasPointNear(points, 1.7071f, 1.7071f), Is.True,
                "The major arc must pass through (1.707, 1.707)");
        }

        [Test]
        public void Parse_G2_NegativeR_MajorArc()
        {
            // Negative R: CW major arc from (0,1) to (1,0), centered at (1,1).
            var points = ParseArcTargets("G2 X1 Y0 R-1\n", new Vector3(0, 1, 0));

            Assert.That(points, Is.Not.Empty);
            Assert.That(points[^1].X, Is.EqualTo(1f).Within(1e-3f));
            Assert.That(points[^1].Y, Is.EqualTo(0f).Within(1e-3f));
            Assert.That(HasPointNear(points, 1.7071f, 1.7071f), Is.True,
                "The major arc must pass through (1.707, 1.707)");
        }

        [Test]
        public void Parse_ImpossibleRadius_IsHandledClearly()
        {
            // |R| < chord / 2: the line must not be turned into a circle.
            var commands = GCodeParser.ParseText("G3 X1 Y0 R0.4\n", Vector3.Zero);
            Assert.That(commands, Is.Empty, "An impossible radius must not emit moves");

            // The ignored line must not move the tool.
            var relative = GCodeParser.ParseText("G91\nG3 X1 Y0 R0.4\nG1 X1 Y0 F100\n", Vector3.Zero);
            Assert.That(relative.Count, Is.EqualTo(1));
            Assert.That(((G1Move)relative[0]).Target, Is.EqualTo(new Vector3(1, 0, 0)),
                "The ignored arc must leave the position unchanged");
        }

        [Test]
        public void Parse_ArcWithoutCenter_IsNotTreatedAsG1()
        {
            var commands = GCodeParser.ParseText("G3 X10 Y0\n", Vector3.Zero);
            Assert.That(commands, Is.Empty, "An arc without I/J/R must not be emitted as a linear move");

            var relative = GCodeParser.ParseText("G91\nG3 X10 Y0\nG1 X1 Y0 F100\n", Vector3.Zero);
            Assert.That(relative.Count, Is.EqualTo(1));
            Assert.That(((G1Move)relative[0]).Target, Is.EqualTo(new Vector3(1, 0, 0)),
                "The ignored arc must leave the position unchanged");
        }

        [Test]
        public void Parse_ModalWords_OrderIndependent()
        {
            // G91 before or after the axis word must produce the same target.
            var relativeFirst = GCodeParser.ParseText("G90\nG1 X5\nG91 G1 X1\n", Vector3.Zero);
            var relativeLast = GCodeParser.ParseText("G90\nG1 X5\nX1 G91 G1\n", Vector3.Zero);

            Assert.That(((G1Move)relativeLast[^1]).Target, Is.EqualTo(new Vector3(6, 0, 0)));
            Assert.That(((G1Move)relativeLast[^1]).Target, Is.EqualTo(((G1Move)relativeFirst[^1]).Target),
                "Relative mode must apply regardless of the word order in the block");

            // G20 before or after the axis word must produce the same (inch-scaled) target.
            var inchFirst = GCodeParser.ParseText("G21\nG20 G1 X1\n", Vector3.Zero);
            var inchLast = GCodeParser.ParseText("G21\nX1 G20 G1\n", Vector3.Zero);

            Assert.That(((G1Move)inchLast[^1]).Target.X, Is.EqualTo(25.4f).Within(1e-3f));
            Assert.That(((G1Move)inchLast[^1]).Target.X, Is.EqualTo(((G1Move)inchFirst[^1]).Target.X).Within(1e-3f),
                "Unit mode must apply regardless of the word order in the block");
        }

        [Test]
        public void Parse_ArcMode_IsModal()
        {
            // The second line continues the G3 arc without repeating the G code.
            var points = ParseArcTargets("G3 X0 Y1 R1\nX-1 Y0 R1\n", new Vector3(1, 0, 0));

            Assert.That(points, Is.Not.Empty);
            Assert.That(points[^1].X, Is.EqualTo(-1f).Within(1e-3f));
            Assert.That(points[^1].Y, Is.EqualTo(0f).Within(1e-3f));
            Assert.That(HasPointNear(points, -0.7071f, 0.7071f), Is.True,
                "The second arc (modal G3 from (0,1) to (-1,0)) must pass through (-0.707, 0.707)");
        }

        [Test]
        public void Parse_RArc_InterpolatesHelicalZ()
        {
            var points = ParseArcTargets("G3 X0 Y1 Z5 R1\n", new Vector3(1, 0, 0));

            Assert.That(points, Is.Not.Empty);
            Assert.That(points[^1].Z, Is.EqualTo(5f).Within(1e-3f));
            Assert.That(points.Any(p => p.Z > 0.1f && p.Z < 4.9f), Is.True,
                "Z must be interpolated along the helical arc");
        }

        [Test]
        public void Parse_G3_NegativeR_MajorArc_OtherQuadrant()
        {
            // CCW major arc from (0,1) to (-1,0), centered at (-1,1).
            var points = ParseArcTargets("G3 X-1 Y0 R-1\n", new Vector3(0, 1, 0));

            Assert.That(points, Is.Not.Empty);
            Assert.That(points[^1].X, Is.EqualTo(-1f).Within(1e-3f));
            Assert.That(points[^1].Y, Is.EqualTo(0f).Within(1e-3f));
            Assert.That(HasPointNear(points, -0.2929f, 1.7071f), Is.True,
                "The major arc must pass through (-0.293, 1.707)");
        }

        [Test]
        public void Parse_InchAbsoluteRArc_ScalesCoordinatesAndRadius()
        {
            // Start is at 1 inch in mm; G20 scales the arc words to inches (1in = 25.4mm).
            var points = ParseArcTargets("G20 G3 X0 Y1 R1\n", new Vector3(25.4f, 0, 0));

            Assert.That(points, Is.Not.Empty);
            Assert.That(points[^1].X, Is.EqualTo(0f).Within(1e-2f));
            Assert.That(points[^1].Y, Is.EqualTo(25.4f).Within(1e-2f));
            Assert.That(HasPointNear(points, 17.96f, 17.96f, 0.1f), Is.True,
                "The 90 degree arc centered at the origin must pass through (25.4/sqrt(2), 25.4/sqrt(2))");
        }

        [Test]
        public void Parse_RelativeRArc_ProducesSameGeometryAsAbsolute()
        {
            var absolute = ParseArcTargets("G3 X0 Y1 R1\n", new Vector3(1, 0, 0));
            var relative = ParseArcTargets("G91 G3 X-1 Y1 R1\n", new Vector3(1, 0, 0));

            Assert.That(relative.Count, Is.EqualTo(absolute.Count));
            for (int i = 0; i < absolute.Count; i++)
            {
                Assert.That(relative[i].X, Is.EqualTo(absolute[i].X).Within(1e-3f), $"point {i} X");
                Assert.That(relative[i].Y, Is.EqualTo(absolute[i].Y).Within(1e-3f), $"point {i} Y");
            }
        }
    }
}
