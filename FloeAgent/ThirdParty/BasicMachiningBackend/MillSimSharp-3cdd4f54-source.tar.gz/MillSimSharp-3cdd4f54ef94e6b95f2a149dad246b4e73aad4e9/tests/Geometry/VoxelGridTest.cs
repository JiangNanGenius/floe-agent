using NUnit.Framework;
using MillSimSharp.Geometry;
using System.Numerics;

namespace MillSimSharp.Tests.Geometry
{
    [TestFixture]
    public class VoxelGridTest
    {
        [Test]
        public void TestConstruction()
        {
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(10, 10, 10));
            var grid = new VoxelGrid(bbox, 1.0f);

            Assert.That(grid.Resolution, Is.EqualTo(1.0f));
            var (x, y, z) = grid.Dimensions;
            Assert.That(x, Is.EqualTo(10));
            Assert.That(y, Is.EqualTo(10));
            Assert.That(z, Is.EqualTo(10));
        }

        [Test]
        public void TestNonFiniteResolution_IsRejected()
        {
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(10, 10, 10));

            Assert.Throws<ArgumentException>(() => new VoxelGrid(bbox, float.NaN));
            Assert.Throws<ArgumentException>(() => new VoxelGrid(bbox, float.PositiveInfinity));
            Assert.Throws<ArgumentException>(() => new SDFGrid(bbox, float.NaN));
            Assert.Throws<ArgumentException>(() => new SDFGrid(bbox, float.PositiveInfinity));
        }

        [Test]
        public void TestInitialState()
        {
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(10, 10, 10));
            var grid = new VoxelGrid(bbox, 1.0f);

            // All voxels should be initialized as material (true)
            for (int z = 0; z < 10; z++)
            {
                for (int y = 0; y < 10; y++)
                {
                    for (int x = 0; x < 10; x++)
                    {
                        Assert.That(grid.GetVoxel(x, y, z), Is.True, $"Voxel at ({x},{y},{z}) should be material");
                    }
                }
            }
        }

        [Test]
        public void TestSetAndGetVoxel()
        {
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(10, 10, 10));
            var grid = new VoxelGrid(bbox, 1.0f);

            grid.SetVoxel(5, 5, 5, false);
            Assert.That(grid.GetVoxel(5, 5, 5), Is.False);
            Assert.That(grid.GetVoxel(4, 5, 5), Is.True);
        }

        [Test]
        public void TestOutOfBounds()
        {
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(10, 10, 10));
            var grid = new VoxelGrid(bbox, 1.0f);

            // Out of bounds should return false
            Assert.That(grid.GetVoxel(-1, 5, 5), Is.False);
            Assert.That(grid.GetVoxel(100, 5, 5), Is.False);
        }

        [Test]
        public void TestRemoveVoxelsInSphere()
        {
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(10, 10, 10));
            var grid = new VoxelGrid(bbox, 0.5f);

            // Remove sphere at center with radius 1.0
            grid.RemoveVoxelsInSphere(Vector3.Zero, 1.0f);

            // Check that voxels near center are removed
            Assert.That(grid.GetVoxelAtWorld(Vector3.Zero), Is.False);
            Assert.That(grid.GetVoxelAtWorld(new Vector3(0.5f, 0, 0)), Is.False);

            // Check that voxels far from center remain
            Assert.That(grid.GetVoxelAtWorld(new Vector3(3, 3, 3)), Is.True);
        }

        [Test]
        public void TestRemoveVoxelsInCylinder()
        {
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(10, 10, 10));
            var grid = new VoxelGrid(bbox, 0.5f);

            // Remove cylinder along X-axis
            var start = new Vector3(-2, 0, 0);
            var end = new Vector3(2, 0, 0);
            grid.RemoveVoxelsInCylinder(start, end, 0.5f);

            // Check that voxels along axis are removed
            Assert.That(grid.GetVoxelAtWorld(Vector3.Zero), Is.False);
            Assert.That(grid.GetVoxelAtWorld(new Vector3(1, 0, 0)), Is.False);
            Assert.That(grid.GetVoxelAtWorld(new Vector3(-1, 0, 0)), Is.False);

            // Check that voxels away from axis remain
            Assert.That(grid.GetVoxelAtWorld(new Vector3(0, 2, 0)), Is.True);
        }

        [Test]
        public void TestCountMaterialVoxels()
        {
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(10, 10, 10));
            var grid = new VoxelGrid(bbox, 1.0f);

            int initialCount = grid.CountMaterialVoxels();
            Assert.That(initialCount, Is.EqualTo(1000)); // 10x10x10

            // Remove one voxel
            grid.SetVoxel(0, 0, 0, false);
            Assert.That(grid.CountMaterialVoxels(), Is.EqualTo(999));
        }

        [Test]
        public void TestClear()
        {
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(10, 10, 10));
            var grid = new VoxelGrid(bbox, 1.0f);

            // Remove some voxels
            grid.SetVoxel(0, 0, 0, false);
            grid.SetVoxel(5, 5, 5, false);

            // Clear should restore all to material
            grid.Clear();
            Assert.That(grid.CountMaterialVoxels(), Is.EqualTo(1000));
        }

        [Test]
        public void GetOccupiedVoxels_NonPowerOfTwoDimensions_StaysWithinGrid()
        {
            // The SVO is padded to the next power of two (10x7x5 -> 16x16x16), so the padding
            // region must never be listed as occupied voxels.
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(10, 7, 5));
            var grid = new VoxelGrid(bbox, 1.0f);

            // Force the SVO root to exist so the traversal path (not the empty-grid shortcut) is used.
            grid.SetVoxel(0, 0, 0, false);
            grid.SetVoxel(9, 6, 4, false);

            var occupied = grid.GetOccupiedVoxels();

            foreach (var (x, y, z) in occupied)
            {
                Assert.That(x, Is.InRange(0, 9), $"occupied voxel X out of range: ({x},{y},{z})");
                Assert.That(y, Is.InRange(0, 6), $"occupied voxel Y out of range: ({x},{y},{z})");
                Assert.That(z, Is.InRange(0, 4), $"occupied voxel Z out of range: ({x},{y},{z})");
            }

            Assert.That(occupied.Count, Is.EqualTo(grid.CountMaterialVoxels()),
                "GetOccupiedVoxels must count exactly the material voxels inside the real grid");
        }

        [Test]
        public void GetOccupiedVoxels_MatchesMaterialCount_ForPowerOfTwoDimensions()
        {
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(8, 8, 8));
            var grid = new VoxelGrid(bbox, 1.0f);
            grid.RemoveVoxelsInSphere(Vector3.Zero, 2f);

            Assert.That(grid.GetOccupiedVoxels().Count, Is.EqualTo(grid.CountMaterialVoxels()));
        }

        [Test]
        public void RemoveVoxelsInSphere_SurfaceSample_IsNotRemoved()
        {
            // Bounds chosen so that voxel centers land exactly on the sphere surface.
            var bbox = new BoundingBox(new Vector3(-3.5f, -4.5f, -0.5f), new Vector3(3.5f, 4.5f, 0.5f));
            var grid = new VoxelGrid(bbox, 1.0f);

            // (3,4,0) is exactly 5mm from the origin; (2,3,0) is strictly inside.
            grid.RemoveVoxelsInSphere(Vector3.Zero, 5f);

            Assert.That(grid.GetVoxelAtWorld(new Vector3(3, 4, 0)), Is.True,
                "A voxel center exactly on the sphere surface must be preserved");
            Assert.That(grid.GetVoxelAtWorld(new Vector3(2, 3, 0)), Is.False,
                "A voxel center strictly inside the sphere must be removed");
        }

        [Test]
        public void RemoveVoxelsInCylinder_SurfaceSample_IsNotRemoved()
        {
            var bbox = new BoundingBox(new Vector3(-3.5f, -4.5f, -0.5f), new Vector3(3.5f, 4.5f, 0.5f));
            var grid = new VoxelGrid(bbox, 1.0f);

            // Cylinder along +Z through the origin, radius 5: (3,4,0) is exactly on the side surface.
            grid.RemoveVoxelsInCylinder(new Vector3(0, 0, -10), new Vector3(0, 0, 10), 5f, flatEnds: true);

            Assert.That(grid.GetVoxelAtWorld(new Vector3(3, 4, 0)), Is.True,
                "A voxel center exactly on the cylinder surface must be preserved");
            Assert.That(grid.GetVoxelAtWorld(new Vector3(2, 3, 0)), Is.False,
                "A voxel center strictly inside the cylinder must be removed");
        }

        [Test]
        public void VoxelGrid_ZeroSizeBounds_Throws()
        {
            var bbox = new BoundingBox(Vector3.Zero, Vector3.Zero);

            Assert.Throws<ArgumentException>(() => new VoxelGrid(bbox, 1.0f));
        }

        [Test]
        public void VoxelGrid_SingleAxisZeroBounds_Throws()
        {
            var flatX = new BoundingBox(Vector3.Zero, new Vector3(0, 10, 10));
            var flatY = new BoundingBox(Vector3.Zero, new Vector3(10, 0, 10));
            var flatZ = new BoundingBox(Vector3.Zero, new Vector3(10, 10, 0));

            Assert.Throws<ArgumentException>(() => new VoxelGrid(flatX, 1.0f));
            Assert.Throws<ArgumentException>(() => new VoxelGrid(flatY, 1.0f));
            Assert.Throws<ArgumentException>(() => new VoxelGrid(flatZ, 1.0f));
        }

        [Test]
        public void VoxelGrid_TinyButPositiveBounds_UsesOneVoxelPerAxis()
        {
            // A positive size below the resolution rounds up to exactly one voxel per axis.
            var bbox = new BoundingBox(Vector3.Zero, new Vector3(1e-4f, 5e-5f, 1e-6f));

            var grid = new VoxelGrid(bbox, 1.0f);

            Assert.That(grid.Dimensions, Is.EqualTo((1, 1, 1)));
            Assert.That(grid.Bounds.Max, Is.EqualTo(new Vector3(1f, 1f, 1f)));
            Assert.That(grid.GetVoxel(0, 0, 0), Is.True);
        }

        [Test]
        public void VoxelGrid_ExcessiveVoxelCount_Throws()
        {
            // Review regression: 200 mm at 0.1 mm resolution is 2000^3 = 8e9 voxels, which overflowed
            // the int-based public counts. Unrepresentable grids are rejected at construction.
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(200, 200, 200));

            var exception = Assert.Throws<ArgumentException>(() => new VoxelGrid(bbox, 0.1f));
            Assert.That(exception!.Message, Does.Contain("voxels"));
        }

        [Test]
        public void VoxelGrid_VoxelCountOverflowingLong_Throws()
        {
            // Review regression: 2e6 x 2e6 x 3e6 = 1.2e19 cells exceeds long.MaxValue; the product
            // must be bounded per axis so it cannot wrap into a negative value and pass the check.
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(200000, 200000, 300000));

            var exception = Assert.Throws<ArgumentException>(() => new VoxelGrid(bbox, 0.1f));
            Assert.That(exception!.Message, Does.Contain("voxels"));
        }

        [Test]
        public void VoxelGrid_MaxCountBoundary_IsAccepted()
        {
            // 1290^3 = 2,146,689,000 voxels is below int.MaxValue and must be constructible. The SVO
            // is sparse, so an all-material grid of this size costs no volume allocation.
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(1290, 1290, 1290));

            var grid = new VoxelGrid(bbox, 1.0f);

            Assert.That(grid.Dimensions, Is.EqualTo((1290, 1290, 1290)));
            Assert.That(grid.CountMaterialVoxels(), Is.EqualTo(2146689000));
        }

        [Test]
        public void VolumeHelpers_MatchVoxelCounts()
        {
            var bbox = BoundingBox.FromCenterAndSize(Vector3.Zero, new Vector3(10, 10, 10));
            var grid = new VoxelGrid(bbox, 1.0f);
            grid.RemoveVoxelsInSphere(Vector3.Zero, 3f);

            int material = grid.CountMaterialVoxels();
            Assert.That(grid.GetMaterialVolume(), Is.EqualTo(material).Within(1e-9),
                "at resolution 1 the volume equals the material voxel count");
            Assert.That(grid.GetRemovedVolume(), Is.EqualTo(1000 - material).Within(1e-9));
            Assert.That(grid.GetMaterialVolume() + grid.GetRemovedVolume(), Is.EqualTo(1000.0).Within(1e-9),
                "material and removed volumes must cover the effective bounds");

            var fine = new VoxelGrid(bbox, 0.5f);
            fine.RemoveVoxelsInSphere(Vector3.Zero, 3f);
            Assert.That(fine.GetMaterialVolume(),
                Is.EqualTo(fine.CountMaterialVoxels() * 0.125).Within(1e-9),
                "each voxel has a volume of resolution^3");
        }
    }
}
