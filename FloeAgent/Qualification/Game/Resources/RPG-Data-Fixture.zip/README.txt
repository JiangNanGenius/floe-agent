Synthetic RPG Maker MZ data fixture for native editor qualification. No RPG Maker engine scripts or RTP assets included. It is not a playable MZ runtime. All original fixture data is MIT licensed.
