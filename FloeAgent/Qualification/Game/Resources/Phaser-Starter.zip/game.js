// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Floe contributors. See licenses/FLOE-STARTER-MIT.txt.
(async function(){'use strict';
const config=await (await fetch('game-config.json')).json();
const state={x:80,y:200,score:0,frames:0};const input={left:false,right:false,up:false,down:false};let player,label,goal=null;
function publish(kind,payload){if(window.floeGameHost)window.floeGameHost[kind](payload)}
const scene={create:function(){
  this.add.rectangle(400,240,800,480,0x244d3c);for(let y=32;y<480;y+=64)for(let x=32;x<800;x+=64)this.add.rectangle(x,y,58,58,(x+y)%128?0x2c5944:0x315f48);
  this.add.rectangle(600,150,200,130,0x976c43);this.add.triangle(600,48,0,80,100,0,200,80,0xc25640).setOrigin(.5,0);
  this.add.text(600,150,config.title,{fontSize:'18px',color:'#fff4d0'}).setOrigin(.5);
  player=this.add.circle(state.x,state.y,14,0x8ed6ff).setStrokeStyle(3,0xf2fbff);
  this.coins=[160,300,440].map(x=>this.add.circle(x,200,9,0xffcf55));label=this.add.text(22,20,'',{fontSize:'22px',color:'#fff'});
  this.keys=this.input.keyboard.createCursorKeys();this.input.on('pointerdown',p=>{goal={x:p.x,y:p.y}});
  window.FloeGame=Object.freeze({
    input:(direction,pressed)=>{if(Object.hasOwn(input,direction)){input[direction]=!!pressed;goal=null;return true}return false},
    snapshot:()=>({...state,engineVersion:Phaser.VERSION}),
    restore:s=>{if(!s||!Number.isFinite(s.x)||!Number.isFinite(s.y)||!Number.isFinite(s.score))throw Error('Invalid save');state.x=Phaser.Math.Clamp(s.x,16,784);state.y=Phaser.Math.Clamp(s.y,16,464);state.score=Phaser.Math.Clamp(Math.floor(s.score),0,3);this.coins.forEach((c,i)=>c.setVisible(i>=state.score));player.setPosition(state.x,state.y);return true}
  });publish('ready',{engine:'phaser',version:Phaser.VERSION,input:true,state:true});
},update:function(time,delta){
  state.frames++;let dx=(input.right||this.keys.right.isDown?1:0)-(input.left||this.keys.left.isDown?1:0),dy=(input.down||this.keys.down.isDown?1:0)-(input.up||this.keys.up.isDown?1:0);
  if(goal){dx=Math.sign(goal.x-state.x);dy=Math.sign(goal.y-state.y);if(Math.abs(goal.x-state.x)<4)dx=0;if(Math.abs(goal.y-state.y)<4)dy=0}
  const length=Math.hypot(dx,dy)||1;const speed=Number.isFinite(config.speed)?Phaser.Math.Clamp(config.speed,20,600):180;
  state.x=Phaser.Math.Clamp(state.x+dx/length*speed*Math.min(delta,50)/1000,16,784);state.y=Phaser.Math.Clamp(state.y+dy/length*speed*Math.min(delta,50)/1000,16,464);player.setPosition(state.x,state.y);
  this.coins.forEach(c=>{if(c.visible&&Phaser.Math.Distance.Between(state.x,state.y,c.x,c.y)<24){c.setVisible(false);state.score++;publish('log','Collected '+state.score)}});label.setText('✉ '+state.score+' / 3');
}};
new Phaser.Game({type:Phaser.CANVAS,parent:'game',width:800,height:480,backgroundColor:'#244d3c',audio:{noAudio:true},banner:false,scale:{mode:Phaser.Scale.FIT,autoCenter:Phaser.Scale.CENTER_HORIZONTALLY},scene:scene});
})().catch(e=>{if(window.floeGameHost)window.floeGameHost.log(String(e));throw e});